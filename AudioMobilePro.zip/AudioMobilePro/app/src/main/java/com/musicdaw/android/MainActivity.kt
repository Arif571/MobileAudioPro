package com.musicdaw.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.musicdaw.android.audio.AudioEngine
import com.musicdaw.android.model.Project
import com.musicdaw.android.ui.screens.*
import com.musicdaw.android.ui.theme.MusicDAWTheme

class MainActivity : ComponentActivity() {
    
    private lateinit var audioEngine: AudioEngine
    private var currentProject: Project? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize audio engine
        audioEngine = AudioEngine(this)
        audioEngine.initialize()
        
        // Load or create a project
        createDemoProject()
        
        setContent {
            MusicDAWTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    MainScreen(audioEngine, currentProject)
                }
            }
        }
    }
    
    private fun createDemoProject() {
        // Create a simple demo project
        currentProject = Project.createDemoProject("Demo Project")
        
        // Set it in the audio engine
        currentProject?.let {
            audioEngine.setProject(it)
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        audioEngine.release()
    }
}

sealed class Screen(val route: String, val resourceId: Int, val icon: ImageVector) {
    object Home : Screen("home", R.string.nav_home, Icons.Filled.Home)
    object Editor : Screen("editor", R.string.nav_editor, Icons.Filled.Edit)
    object Mixer : Screen("mixer", R.string.nav_mixer, Icons.Filled.Settings)
    object Samples : Screen("samples", R.string.nav_samples, Icons.Filled.List)
    object AI : Screen("ai", R.string.nav_ai, Icons.Filled.Star)
    object Recommendations : Screen("recommendations", R.string.nav_recommendations, Icons.Filled.Recommend)
    object Settings : Screen("settings", R.string.nav_settings, Icons.Filled.Settings)
}

@Composable
fun MainScreen(audioEngine: AudioEngine, currentProject: Project?) {
    val navController = rememberNavController()
    val items = listOf(
        Screen.Home,
        Screen.Editor,
        Screen.Mixer,
        Screen.Samples,
        Screen.AI,
        Screen.Recommendations
    )
    
    Scaffold(
        bottomBar = {
            BottomNavigation {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination
                
                items.forEach { screen ->
                    BottomNavigationItem(
                        icon = { Icon(screen.icon, contentDescription = null) },
                        label = { Text(stringResource(screen.resourceId)) },
                        selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController, 
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { 
                HomeScreen(
                    currentProject = currentProject,
                    navController = navController
                )
            }
            composable(Screen.Editor.route) { 
                EditorScreen(
                    currentProject = currentProject,
                    audioEngine = audioEngine
                )
            }
            composable(Screen.Mixer.route) { 
                MixerScreen(
                    currentProject = currentProject,
                    audioEngine = audioEngine
                )
            }
            composable(Screen.Samples.route) { 
                SamplesScreen()
            }
            composable(Screen.AI.route) { 
                AIProcessingScreen(
                    currentProject = currentProject
                )
            }
            composable(Screen.Recommendations.route) { 
                RecommendationScreen(
                    currentProject = currentProject
                )
            }
            composable(Screen.Settings.route) { 
                SettingsScreen()
            }
        }
    }
}