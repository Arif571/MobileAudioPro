package com.musicdaw.android.model

import java.util.*

/**
 * Represents a track in a music project
 */
data class Track(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: TrackType,
    val color: Int = 0xFFE91E63.toInt(), // Default pink color
    val isMuted: Boolean = false,
    val isSolo: Boolean = false,
    val isArmed: Boolean = false,
    val volume: Float = 1.0f, // 0.0 to 1.0
    val pan: Float = 0f, // -1.0 (left) to 1.0 (right)
    val audioClips: List<AudioClip> = emptyList(),
    val midiPatterns: List<MidiPattern> = emptyList(),
    val effects: List<Effect> = emptyList(),
    val automation: Map<String, List<AutomationPoint>> = emptyMap(),
    val inputSource: String? = null,
    val outputDestination: String? = null,
    val isMonitored: Boolean = false,
    val isDrumTrack: Boolean = false,
    val instrument: Instrument? = null,
    val isVisible: Boolean = true,
    val isLocked: Boolean = false,
    val order: Int = 0
) {

    /**
     * Adds an audio clip to the track
     */
    fun addAudioClip(clip: AudioClip): Track {
        val newClips = audioClips.toMutableList().apply {
            add(clip)
        }
        return this.copy(audioClips = newClips)
    }

    /**
     * Removes an audio clip from the track
     */
    fun removeAudioClip(clipId: String): Track {
        val newClips = audioClips.filter { it.id != clipId }
        return this.copy(audioClips = newClips)
    }

    /**
     * Updates an audio clip in the track
     */
    fun updateAudioClip(clipId: String, updatedClip: AudioClip): Track {
        val clipIndex = audioClips.indexOfFirst { it.id == clipId }
        if (clipIndex == -1) return this

        val newClips = audioClips.toMutableList().apply {
            set(clipIndex, updatedClip)
        }
        return this.copy(audioClips = newClips)
    }

    /**
     * Adds a MIDI pattern to the track
     */
    fun addMidiPattern(pattern: MidiPattern): Track {
        val newPatterns = midiPatterns.toMutableList().apply {
            add(pattern)
        }
        return this.copy(midiPatterns = newPatterns)
    }

    /**
     * Removes a MIDI pattern from the track
     */
    fun removeMidiPattern(patternId: String): Track {
        val newPatterns = midiPatterns.filter { it.id != patternId }
        return this.copy(midiPatterns = newPatterns)
    }

    /**
     * Updates a MIDI pattern in the track
     */
    fun updateMidiPattern(patternId: String, updatedPattern: MidiPattern): Track {
        val patternIndex = midiPatterns.indexOfFirst { it.id == patternId }
        if (patternIndex == -1) return this

        val newPatterns = midiPatterns.toMutableList().apply {
            set(patternIndex, updatedPattern)
        }
        return this.copy(midiPatterns = newPatterns)
    }

    /**
     * Adds an effect to the track's effect chain
     */
    fun addEffect(effect: Effect): Track {
        val newEffects = effects.toMutableList().apply {
            add(effect)
        }
        return this.copy(effects = newEffects)
    }

    /**
     * Removes an effect from the track's effect chain
     */
    fun removeEffect(effectId: String): Track {
        val newEffects = effects.filter { it.id != effectId }
        return this.copy(effects = newEffects)
    }

    /**
     * Updates an effect in the track's effect chain
     */
    fun updateEffect(effectId: String, updatedEffect: Effect): Track {
        val effectIndex = effects.indexOfFirst { it.id == effectId }
        if (effectIndex == -1) return this

        val newEffects = effects.toMutableList().apply {
            set(effectIndex, updatedEffect)
        }
        return this.copy(effects = newEffects)
    }

    /**
     * Toggles the mute state of the track
     */
    fun toggleMute(): Track {
        return this.copy(isMuted = !isMuted)
    }

    /**
     * Toggles the solo state of the track
     */
    fun toggleSolo(): Track {
        return this.copy(isSolo = !isSolo)
    }

    /**
     * Toggles the armed (record-ready) state of the track
     */
    fun toggleArmed(): Track {
        return this.copy(isArmed = !isArmed)
    }

    /**
     * Updates the track's volume
     */
    fun withVolume(newVolume: Float): Track {
        return this.copy(volume = newVolume.coerceIn(0f, 1f))
    }

    /**
     * Updates the track's panning
     */
    fun withPan(newPan: Float): Track {
        return this.copy(pan = newPan.coerceIn(-1f, 1f))
    }

    /**
     * Calculate the end time of the track (latest clip or pattern end)
     */
    fun getEndTime(): Float {
        val latestAudioClipEnd = audioClips.maxOfOrNull { it.startTime + it.duration } ?: 0f
        val latestMidiPatternEnd = midiPatterns.maxOfOrNull { it.startTime + it.duration } ?: 0f
        
        return maxOf(latestAudioClipEnd, latestMidiPatternEnd)
    }
}

/**
 * Represents the types of tracks
 */
enum class TrackType {
    AUDIO,
    MIDI,
    INSTRUMENT,
    AUX,
    MASTER
}

/**
 * Represents an automation point for track parameters
 */
data class AutomationPoint(
    val position: Float, // Time position in seconds
    val value: Float, // Parameter value (usually 0.0 to 1.0)
    val curveType: CurveType = CurveType.LINEAR // Curve to the next point
)

/**
 * Represents the curve type for automation
 */
enum class CurveType {
    LINEAR,
    EXPONENTIAL,
    LOGARITHMIC,
    SINE,
    STEP
}

/**
 * Represents a virtual instrument that can be assigned to a track
 */
data class Instrument(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: String, // synth, sampler, etc.
    val presetName: String? = null,
    val parameters: Map<String, Float> = emptyMap(),
    val isEnabled: Boolean = true
)