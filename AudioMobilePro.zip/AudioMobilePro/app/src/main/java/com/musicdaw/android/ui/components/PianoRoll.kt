package com.musicdaw.android.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.musicdaw.android.model.MidiNote
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun PianoRoll(
    noteData: List<MidiNote>,
    pixelsPerSecond: Float,
    onNoteAdd: (note: Int, startTime: Float, duration: Float) -> Unit,
    onNoteDelete: (noteIndex: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val horizontalScrollState = rememberScrollState()
    val verticalScrollState = rememberScrollState()
    
    // Piano roll dimensions
    val totalNotes = 88 // 88 keys on a piano
    val noteHeight = 16.dp
    val pianoKeyWidth = 60.dp
    val totalDuration = 180f // 3 minutes
    
    // Note editing state
    var currentCreationNote by remember { mutableStateOf<Int?>(null) }
    var currentCreationStartTime by remember { mutableStateOf(0f) }
    var currentCreationEndTime by remember { mutableStateOf(0f) }
    var isCreatingNote by remember { mutableStateOf(false) }
    
    var selectedNoteIndex by remember { mutableStateOf<Int?>(null) }
    
    // Convert noteHeight to pixels
    val noteHeightPx = with(LocalDensity.current) { noteHeight.toPx() }
    val pianoKeyWidthPx = with(LocalDensity.current) { pianoKeyWidth.toPx() }
    
    Box(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxSize()
        ) {
            // Piano keyboard on the left
            PianoKeyboard(
                totalNotes = totalNotes,
                noteHeight = noteHeight,
                modifier = Modifier
                    .width(pianoKeyWidth)
                    .verticalScroll(verticalScrollState)
            )
            
            // Note grid on the right
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    .verticalScroll(verticalScrollState)
                    .horizontalScroll(horizontalScrollState)
                    .clipToBounds()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { offset ->
                                // Convert tap position to note and time
                                val note = totalNotes - (offset.y / noteHeightPx).toInt()
                                val time = offset.x / pixelsPerSecond
                                
                                // Check if we tapped on an existing note
                                val tappedNoteIndex = noteData.indexOfFirst { midiNote ->
                                    val noteRect = Rect(
                                        left = midiNote.startTime * pixelsPerSecond,
                                        top = (totalNotes - midiNote.note - 1) * noteHeightPx,
                                        right = (midiNote.startTime + midiNote.duration) * pixelsPerSecond,
                                        bottom = (totalNotes - midiNote.note) * noteHeightPx
                                    )
                                    noteRect.contains(offset)
                                }
                                
                                if (tappedNoteIndex >= 0) {
                                    // Select the note
                                    selectedNoteIndex = tappedNoteIndex
                                } else {
                                    // Add a new note
                                    if (note in 0 until totalNotes) {
                                        onNoteAdd(note, time, 0.5f) // Default duration 0.5 seconds
                                        selectedNoteIndex = null
                                    }
                                }
                            },
                            onDoubleTap = { offset ->
                                // Check if we double-tapped on an existing note
                                val tappedNoteIndex = noteData.indexOfFirst { midiNote ->
                                    val noteRect = Rect(
                                        left = midiNote.startTime * pixelsPerSecond,
                                        top = (totalNotes - midiNote.note - 1) * noteHeightPx,
                                        right = (midiNote.startTime + midiNote.duration) * pixelsPerSecond,
                                        bottom = (totalNotes - midiNote.note) * noteHeightPx
                                    )
                                    noteRect.contains(offset)
                                }
                                
                                if (tappedNoteIndex >= 0) {
                                    // Delete the note
                                    onNoteDelete(tappedNoteIndex)
                                    selectedNoteIndex = null
                                }
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                isCreatingNote = true
                                
                                // Convert drag start position to note and time
                                val note = totalNotes - (offset.y / noteHeightPx).toInt()
                                val time = offset.x / pixelsPerSecond
                                
                                if (note in 0 until totalNotes) {
                                    currentCreationNote = note
                                    currentCreationStartTime = time
                                    currentCreationEndTime = time
                                }
                            },
                            onDrag = { change, _ ->
                                if (isCreatingNote && currentCreationNote != null) {
                                    val time = max(0f, change.position.x / pixelsPerSecond)
                                    currentCreationEndTime = time
                                }
                            },
                            onDragEnd = {
                                if (isCreatingNote && currentCreationNote != null) {
                                    val startTime = min(currentCreationStartTime, currentCreationEndTime)
                                    val endTime = max(currentCreationStartTime, currentCreationEndTime)
                                    
                                    if (endTime > startTime) {
                                        onNoteAdd(
                                            currentCreationNote!!,
                                            startTime,
                                            endTime - startTime
                                        )
                                    }
                                    
                                    isCreatingNote = false
                                    currentCreationNote = null
                                }
                            },
                            onDragCancel = {
                                isCreatingNote = false
                                currentCreationNote = null
                            }
                        )
                    }
            ) {
                val canvasModifier = Modifier
                    .width(with(LocalDensity.current) { (pixelsPerSecond * totalDuration).toDp() })
                    .height(with(LocalDensity.current) { (noteHeightPx * totalNotes).toDp() })
                
                Canvas(modifier = canvasModifier) {
                    // Draw the piano roll grid
                    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                    val beatColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                    val barColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                    
                    // Draw horizontal grid lines (one per note)
                    for (i in 0..totalNotes) {
                        val y = i * noteHeightPx
                        
                        // Draw note line
                        drawLine(
                            color = gridColor,
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 1f
                        )
                        
                        // Highlight C notes (every 12 notes, with 0 being C0)
                        if ((totalNotes - i) % 12 == 0) {
                            drawRect(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f),
                                topLeft = Offset(0f, y),
                                size = Size(size.width, noteHeightPx)
                            )
                        }
                    }
                    
                    // Draw vertical grid lines (one per beat/bar)
                    val beatsPerBar = 4 // 4/4 time signature
                    val pixelsPerBeat = pixelsPerSecond * 0.5f // Assuming 120 BPM (2 beats per second)
                    
                    val totalBeats = (totalDuration * 2).toInt() // 2 beats per second
                    
                    for (i in 0..totalBeats) {
                        val x = i * pixelsPerBeat
                        
                        if (i % beatsPerBar == 0) {
                            // Bar line
                            drawLine(
                                color = barColor,
                                start = Offset(x, 0f),
                                end = Offset(x, size.height),
                                strokeWidth = 1f
                            )
                        } else {
                            // Beat line
                            drawLine(
                                color = beatColor,
                                start = Offset(x, 0f),
                                end = Offset(x, size.height),
                                strokeWidth = 1f
                            )
                        }
                    }
                    
                    // Draw existing notes
                    noteData.forEachIndexed { index, note ->
                        val isSelected = index == selectedNoteIndex
                        
                        val noteX = note.startTime * pixelsPerSecond
                        val noteY = (totalNotes - note.note - 1) * noteHeightPx
                        val noteWidth = note.duration * pixelsPerSecond
                        
                        // Choose color based on note velocity/type
                        val noteColor = MaterialTheme.colorScheme.primary
                        val strokeColor = MaterialTheme.colorScheme.onPrimary
                        
                        // Draw note rectangle
                        drawRect(
                            color = if (isSelected) noteColor else noteColor.copy(alpha = 0.7f),
                            topLeft = Offset(noteX, noteY),
                            size = Size(noteWidth, noteHeightPx)
                        )
                        
                        // Draw outline
                        drawRect(
                            color = strokeColor.copy(alpha = if (isSelected) 0.9f else 0.4f),
                            topLeft = Offset(noteX, noteY),
                            size = Size(noteWidth, noteHeightPx),
                            style = Stroke(width = if (isSelected) 2f else 1f)
                        )
                    }
                    
                    // Draw currently creating note (if in creation process)
                    if (isCreatingNote && currentCreationNote != null) {
                        val startTime = min(currentCreationStartTime, currentCreationEndTime)
                        val endTime = max(currentCreationStartTime, currentCreationEndTime)
                        
                        val noteX = startTime * pixelsPerSecond
                        val noteY = (totalNotes - currentCreationNote!! - 1) * noteHeightPx
                        val noteWidth = (endTime - startTime) * pixelsPerSecond
                        
                        // Draw note rectangle
                        drawRect(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                            topLeft = Offset(noteX, noteY),
                            size = Size(noteWidth, noteHeightPx)
                        )
                        
                        // Draw outline
                        drawRect(
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f),
                            topLeft = Offset(noteX, noteY),
                            size = Size(noteWidth, noteHeightPx),
                            style = Stroke(width = 2f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PianoKeyboard(
    totalNotes: Int,
    noteHeight: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    val noteHeightPx = with(LocalDensity.current) { noteHeight.toPx() }
    
    Canvas(
        modifier = modifier
            .fillMaxHeight()
            .width(60.dp)
    ) {
        // Draw piano keys from bottom to top (lowest note at the bottom)
        for (i in 0 until totalNotes) {
            val note = totalNotes - i - 1 // Reverse index (highest note at the top)
            val octave = note / 12
            val noteInOctave = note % 12
            
            val isBlackKey = when (noteInOctave) {
                1, 3, 6, 8, 10 -> true
                else -> false
            }
            
            val keyTop = i * noteHeightPx
            val keyColor = if (isBlackKey) Color.Black else Color.White
            val textColor = if (isBlackKey) Color.White else Color.Black
            
            // Draw key background
            drawRect(
                color = keyColor,
                topLeft = Offset(0f, keyTop),
                size = Size(
                    width = if (isBlackKey) size.width * 0.6f else size.width,
                    height = noteHeightPx
                )
            )
            
            // Draw outline
            drawRect(
                color = Color.Gray,
                topLeft = Offset(0f, keyTop),
                size = Size(
                    width = if (isBlackKey) size.width * 0.6f else size.width,
                    height = noteHeightPx
                ),
                style = Stroke(width = 1f)
            )
            
            // Draw note label (C notes only)
            if (noteInOctave == 0) {
                drawContext.canvas.nativeCanvas.drawText(
                    "C$octave",
                    10f,
                    keyTop + noteHeightPx * 0.7f,
                    android.graphics.Paint().apply {
                        color = textColor.toArgb()
                        textSize = 12.sp.toPx()
                    }
                )
            }
        }
    }
}
