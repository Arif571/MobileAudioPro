package com.musicdaw.android.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.musicdaw.android.model.AppSettings
import com.musicdaw.android.model.SoloMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// DataStore extension for Context
private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

/**
 * Repository for managing application settings
 */
class SettingsRepository(private val context: Context) {

    // Preference keys
    private val themeKey = intPreferencesKey("theme_mode")
    private val accentColorKey = intPreferencesKey("accent_color")
    private val useDynamicColorKey = booleanPreferencesKey("use_dynamic_color")
    
    private val audioQualityKey = intPreferencesKey("audio_quality")
    private val sampleRateKey = intPreferencesKey("sample_rate")
    private val bitDepthKey = intPreferencesKey("bit_depth")
    private val bufferSizeKey = intPreferencesKey("buffer_size")
    
    private val autoSaveIntervalKey = intPreferencesKey("auto_save_interval")
    private val maxProjectCacheMbKey = intPreferencesKey("max_project_cache_mb")
    private val storagePathKey = stringPreferencesKey("storage_path")
    
    private val cloudServiceKey = stringPreferencesKey("cloud_service")
    private val autoDownloadResultsKey = booleanPreferencesKey("auto_download_results")
    private val highQualityAiKey = booleanPreferencesKey("high_quality_ai")
    
    private val maxCpuCoresKey = intPreferencesKey("max_cpu_cores")
    private val enableLowLatencyModeKey = booleanPreferencesKey("enable_low_latency_mode")
    private val enableBackgroundProcessingKey = booleanPreferencesKey("enable_background_processing")
    
    private val showWaveformsKey = booleanPreferencesKey("show_waveforms")
    private val touchSensitivityKey = floatPreferencesKey("touch_sensitivity")
    private val enableGesturesKey = booleanPreferencesKey("enable_gestures")
    
    private val defaultProjectTemplateKey = stringPreferencesKey("default_project_template")
    private val snapToGridKey = booleanPreferencesKey("snap_to_grid")
    private val gridDivisionKey = intPreferencesKey("grid_division")
    private val showMeasureNumbersKey = booleanPreferencesKey("show_measure_numbers")
    private val autoscrollDuringPlaybackKey = booleanPreferencesKey("autoscroll_during_playback")
    
    private val showPeakMetersKey = booleanPreferencesKey("show_peak_meters")
    private val meterRefreshRateKey = intPreferencesKey("meter_refresh_rate")
    private val soloModeKey = intPreferencesKey("solo_mode")
    
    private val countInMeasuresKey = intPreferencesKey("count_in_measures")
    private val monitorInputWhileRecordingKey = booleanPreferencesKey("monitor_input_while_recording")
    private val automaticallyCreateNewTakeKey = booleanPreferencesKey("automatically_create_new_take")
    
    private val defaultExportFormatKey = stringPreferencesKey("default_export_format")
    private val defaultExportBitDepthKey = intPreferencesKey("default_export_bit_depth")
    private val defaultExportSampleRateKey = intPreferencesKey("default_export_sample_rate")
    private val normalizeOnExportKey = booleanPreferencesKey("normalize_on_export")
    private val addDitheringKey = booleanPreferencesKey("add_dithering")
    
    private val firstLaunchKey = booleanPreferencesKey("first_launch")
    private val onboardingCompletedKey = booleanPreferencesKey("onboarding_completed")
    private val lastUsedVersionKey = stringPreferencesKey("last_used_version")

    /**
     * Gets the current settings as a Flow
     */
    fun getSettings(): Flow<AppSettings> = context.settingsDataStore.data.map { preferences ->
        AppSettings(
            // Theme settings
            themeMode = preferences[themeKey] ?: 0,
            accentColor = preferences[accentColorKey] ?: 0,
            useDynamicColor = preferences[useDynamicColorKey] ?: true,
            
            // Audio settings
            audioQuality = preferences[audioQualityKey] ?: 1,
            sampleRate = preferences[sampleRateKey] ?: 48000,
            bitDepth = preferences[bitDepthKey] ?: 24,
            bufferSize = preferences[bufferSizeKey] ?: 512,
            
            // Project settings
            autoSaveInterval = preferences[autoSaveIntervalKey] ?: 5,
            maxProjectCacheMB = preferences[maxProjectCacheMbKey] ?: 1000,
            storagePath = preferences[storagePathKey] ?: "Music/MusicDAW",
            
            // AI settings
            cloudService = preferences[cloudServiceKey] ?: "automatic",
            autoDownloadResults = preferences[autoDownloadResultsKey] ?: true,
            highQualityAI = preferences[highQualityAiKey] ?: true,
            
            // Performance settings
            maxCpuCores = preferences[maxCpuCoresKey] ?: 0,
            enableLowLatencyMode = preferences[enableLowLatencyModeKey] ?: false,
            enableBackgroundProcessing = preferences[enableBackgroundProcessingKey] ?: true,
            
            // UI settings
            showWaveforms = preferences[showWaveformsKey] ?: true,
            touchSensitivity = preferences[touchSensitivityKey] ?: 1.0f,
            enableGestures = preferences[enableGesturesKey] ?: true,
            
            // Editor settings
            defaultProjectTemplate = preferences[defaultProjectTemplateKey] ?: "Empty",
            snapToGrid = preferences[snapToGridKey] ?: true,
            gridDivision = preferences[gridDivisionKey] ?: 16,
            showMeasureNumbers = preferences[showMeasureNumbersKey] ?: true,
            autoscrollDuringPlayback = preferences[autoscrollDuringPlaybackKey] ?: true,
            
            // Mixer settings
            showPeakMeters = preferences[showPeakMetersKey] ?: true,
            meterRefreshRate = preferences[meterRefreshRateKey] ?: 30,
            soloMode = preferences[soloModeKey]?.let { if (it == 1) SoloMode.SOLO_SAFE else SoloMode.SOLO_IN_PLACE } ?: SoloMode.SOLO_IN_PLACE,
            
            // Recording settings
            countInMeasures = preferences[countInMeasuresKey] ?: 1,
            monitorInputWhileRecording = preferences[monitorInputWhileRecordingKey] ?: true,
            automaticallyCreateNewTake = preferences[automaticallyCreateNewTakeKey] ?: true,
            
            // Export settings
            defaultExportFormat = preferences[defaultExportFormatKey] ?: "wav",
            defaultExportBitDepth = preferences[defaultExportBitDepthKey] ?: 24,
            defaultExportSampleRate = preferences[defaultExportSampleRateKey] ?: 48000,
            normalizeOnExport = preferences[normalizeOnExportKey] ?: false,
            addDithering = preferences[addDitheringKey] ?: true,
            
            // Other settings
            firstLaunch = preferences[firstLaunchKey] ?: true,
            onboardingCompleted = preferences[onboardingCompletedKey] ?: false,
            lastUsedVersion = preferences[lastUsedVersionKey] ?: "1.0.0"
        )
    }

    /**
     * Updates the settings
     */
    suspend fun updateSettings(settings: AppSettings) {
        context.settingsDataStore.edit { preferences ->
            // Theme settings
            preferences[themeKey] = settings.themeMode
            preferences[accentColorKey] = settings.accentColor
            preferences[useDynamicColorKey] = settings.useDynamicColor
            
            // Audio settings
            preferences[audioQualityKey] = settings.audioQuality
            preferences[sampleRateKey] = settings.sampleRate
            preferences[bitDepthKey] = settings.bitDepth
            preferences[bufferSizeKey] = settings.bufferSize
            
            // Project settings
            preferences[autoSaveIntervalKey] = settings.autoSaveInterval
            preferences[maxProjectCacheMbKey] = settings.maxProjectCacheMB
            preferences[storagePathKey] = settings.storagePath
            
            // AI settings
            preferences[cloudServiceKey] = settings.cloudService
            preferences[autoDownloadResultsKey] = settings.autoDownloadResults
            preferences[highQualityAiKey] = settings.highQualityAI
            
            // Performance settings
            preferences[maxCpuCoresKey] = settings.maxCpuCores
            preferences[enableLowLatencyModeKey] = settings.enableLowLatencyMode
            preferences[enableBackgroundProcessingKey] = settings.enableBackgroundProcessing
            
            // UI settings
            preferences[showWaveformsKey] = settings.showWaveforms
            preferences[touchSensitivityKey] = settings.touchSensitivity
            preferences[enableGesturesKey] = settings.enableGestures
            
            // Editor settings
            preferences[defaultProjectTemplateKey] = settings.defaultProjectTemplate
            preferences[snapToGridKey] = settings.snapToGrid
            preferences[gridDivisionKey] = settings.gridDivision
            preferences[showMeasureNumbersKey] = settings.showMeasureNumbers
            preferences[autoscrollDuringPlaybackKey] = settings.autoscrollDuringPlayback
            
            // Mixer settings
            preferences[showPeakMetersKey] = settings.showPeakMeters
            preferences[meterRefreshRateKey] = settings.meterRefreshRate
            preferences[soloModeKey] = if (settings.soloMode == SoloMode.SOLO_SAFE) 1 else 0
            
            // Recording settings
            preferences[countInMeasuresKey] = settings.countInMeasures
            preferences[monitorInputWhileRecordingKey] = settings.monitorInputWhileRecording
            preferences[automaticallyCreateNewTakeKey] = settings.automaticallyCreateNewTake
            
            // Export settings
            preferences[defaultExportFormatKey] = settings.defaultExportFormat
            preferences[defaultExportBitDepthKey] = settings.defaultExportBitDepth
            preferences[defaultExportSampleRateKey] = settings.defaultExportSampleRate
            preferences[normalizeOnExportKey] = settings.normalizeOnExport
            preferences[addDitheringKey] = settings.addDithering
            
            // Other settings
            preferences[firstLaunchKey] = settings.firstLaunch
            preferences[onboardingCompletedKey] = settings.onboardingCompleted
            preferences[lastUsedVersionKey] = settings.lastUsedVersion
        }
    }

    /**
     * Updates a single setting
     */
    suspend fun updateSetting(updater: (AppSettings) -> AppSettings) {
        val currentSettings = getSettings().map { it }.let {
            it.map { settings -> updater(settings) }
        }
        
        // This will be implemented when we need it
    }
}