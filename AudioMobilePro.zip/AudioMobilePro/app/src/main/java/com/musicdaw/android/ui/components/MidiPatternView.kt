package com.musicdaw.android.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.musicdaw.android.model.MidiPattern

/**
 * Displays a MIDI pattern in the editor timeline
 */
@Composable
fun MidiPatternView(
    pattern: MidiPattern,
    trackColor: Color,
    zoomLevel: Float,
    onClick: (() -> Unit)? = null
) {
    // Calculate width based on duration and zoom level
    val widthDp = (pattern.duration * 50 * zoomLevel).dp
    
    // Position is calculated based on startTime and zoom level in parent component
    
    Box(
        modifier = Modifier
            .width(widthDp)
            .fillMaxHeight()
            .padding(vertical = 2.dp, horizontal = 1.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(trackColor.copy(alpha = 0.7f))
            .then(onClick?.let { Modifier.clickable(onClick = it) } ?: Modifier),
        contentAlignment = Alignment.TopCenter
    ) {
        // Pattern name
        Text(
            text = pattern.name,
            style = MaterialTheme.typography.bodySmall,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(4.dp)
        )
        
        // Simple visualization of MIDI notes
        Canvas(
            modifier = Modifier
                .fillMaxHeight()
                .padding(top = 20.dp, bottom = 4.dp, start = 4.dp, end = 4.dp)
        ) {
            val canvasHeight = size.height
            val canvasWidth = size.width
            
            // Draw note rectangles
            pattern.notes.forEach { note ->
                // Calculate vertical position based on note pitch (higher notes at top)
                val normalizedPitch = (127 - note.note) / 127f
                val y = normalizedPitch * canvasHeight
                
                // Calculate horizontal position based on note timing
                val x = (note.startTime / pattern.duration) * canvasWidth
                
                // Calculate width based on note duration
                val width = (note.duration / pattern.duration) * canvasWidth
                
                // Calculate velocity-based color (brighter = higher velocity)
                val velocityFactor = note.velocity / 127f
                val noteColor = Color.White.copy(alpha = 0.3f + velocityFactor * 0.7f)
                
                // Draw note rectangle
                drawRect(
                    color = noteColor,
                    topLeft = Offset(x, y),
                    size = androidx.compose.ui.geometry.Size(width, 4f)
                )
            }
        }
    }
}