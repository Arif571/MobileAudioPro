package com.musicdaw.android.repository

import android.content.Context
import com.musicdaw.android.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.*

/**
 * Repository for managing project data
 */
class ProjectRepository(private val context: Context) {
    
    private val _recentProjects = MutableStateFlow<List<Project>>(emptyList())
    val recentProjects: StateFlow<List<Project>> = _recentProjects
    
    // Cache of loaded projects
    private val projectCache = mutableMapOf<String, Project>()
    
    init {
        // Load recent projects list
        loadRecentProjects()
    }
    
    /**
     * Creates a new project
     */
    suspend fun createProject(name: String, tempo: Float = 120f): Project = withContext(Dispatchers.IO) {
        val project = Project.createEmptyProject(
            name = name,
            tempo = tempo
        )
        
        // Add to cache and recent projects
        projectCache[project.id] = project
        updateRecentProjects(project)
        
        return@withContext project
    }
    
    /**
     * Loads a project by ID
     */
    suspend fun loadProject(projectId: String): Project? = withContext(Dispatchers.IO) {
        // Check cache first
        projectCache[projectId]?.let { return@withContext it }
        
        // TODO: Load from disk or cloud
        
        return@withContext null
    }
    
    /**
     * Saves a project
     */
    suspend fun saveProject(project: Project): Project = withContext(Dispatchers.IO) {
        val projectDir = File(context.filesDir, "projects")
        if (!projectDir.exists()) {
            projectDir.mkdirs()
        }
        
        val projectFile = File(projectDir, "${project.id}.json")
        
        // TODO: Save project data to file
        
        val savedProject = project.markSaved(projectFile.absolutePath)
        
        // Update cache and recent projects
        projectCache[savedProject.id] = savedProject
        updateRecentProjects(savedProject)
        
        return@withContext savedProject
    }
    
    /**
     * Deletes a project
     */
    suspend fun deleteProject(projectId: String): Boolean = withContext(Dispatchers.IO) {
        val projectDir = File(context.filesDir, "projects")
        val projectFile = File(projectDir, "$projectId.json")
        
        // Remove from cache and recent projects
        projectCache.remove(projectId)
        
        val updatedList = _recentProjects.value.filter { it.id != projectId }
        _recentProjects.value = updatedList
        
        // Delete project file
        return@withContext projectFile.delete()
    }
    
    /**
     * Gets a list of recent projects
     */
    private fun loadRecentProjects() {
        // For now, just return an empty list
        // TODO: Load recent projects from storage
        _recentProjects.value = emptyList()
    }
    
    /**
     * Updates the recent projects list
     */
    private fun updateRecentProjects(project: Project) {
        val currentList = _recentProjects.value.toMutableList()
        
        // Remove if already in list
        currentList.removeIf { it.id == project.id }
        
        // Add to beginning of list
        currentList.add(0, project)
        
        // Limit to 10 recent projects
        if (currentList.size > 10) {
            currentList.removeAt(currentList.size - 1)
        }
        
        _recentProjects.value = currentList
    }
}