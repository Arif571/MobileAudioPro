package com.musicdaw.android.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.musicdaw.android.R
import com.musicdaw.android.model.Effect
import com.musicdaw.android.model.EffectPreset

@Composable
fun EffectsChain(
    effects: List<Effect>,
    onEffectParameterChange: (effectIndex: Int, paramName: String, value: Float) -> Unit,
    onEffectEnableChange: (effectIndex: Int, enabled: Boolean) -> Unit,
    onEffectReorder: (fromIndex: Int, toIndex: Int) -> Unit,
    onEffectRemove: (effectIndex: Int) -> Unit,
    onEffectAdd: (effectType: String) -> Unit,
    onPresetLoad: (Effect, EffectPreset) -> Unit,
    onPresetSave: (Effect) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddEffectDialog by remember { mutableStateOf(false) }

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Effects Chain",
                    style = MaterialTheme.typography.titleMedium
                )
                
                Button(
                    onClick = { showAddEffectDialog = true },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Effect"
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Effect")
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            if (effects.isEmpty()) {
                // Empty state
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No effects added yet. Click 'Add Effect' to get started.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                // Effects list
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(effects) { index, effect ->
                        EffectItem(
                            effect = effect,
                            effectIndex = index,
                            onParameterChange = { paramName, value ->
                                onEffectParameterChange(index, paramName, value)
                            },
                            onEnableChange = { enabled ->
                                onEffectEnableChange(index, enabled)
                            },
                            onRemove = { onEffectRemove(index) },
                            onMoveUp = {
                                if (index > 0) {
                                    onEffectReorder(index, index - 1)
                                }
                            },
                            onMoveDown = {
                                if (index < effects.size - 1) {
                                    onEffectReorder(index, index + 1)
                                }
                            },
                            onPresetLoad = { preset -> onPresetLoad(effect, preset) },
                            onPresetSave = { onPresetSave(effect) },
                            isFirst = index == 0,
                            isLast = index == effects.size - 1
                        )
                    }
                }
            }
        }
    }
    
    if (showAddEffectDialog) {
        AddEffectDialog(
            onDismiss = { showAddEffectDialog = false },
            onEffectTypeSelected = { effectType ->
                onEffectAdd(effectType)
                showAddEffectDialog = false
            }
        )
    }
}

@Composable
fun EffectItem(
    effect: Effect,
    effectIndex: Int,
    onParameterChange: (paramName: String, value: Float) -> Unit,
    onEnableChange: (enabled: Boolean) -> Unit,
    onRemove: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onPresetLoad: (EffectPreset) -> Unit,
    onPresetSave: () -> Unit,
    isFirst: Boolean,
    isLast: Boolean
) {
    var expanded by remember { mutableStateOf(false) }
    var showPresetsMenu by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (effect.isEnabled) 
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) 
                else 
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                shape = RoundedCornerShape(8.dp)
            ),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (effect.isEnabled)
                MaterialTheme.colorScheme.surface
            else
                MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
        )
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Effect header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (effect.isEnabled)
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                        else
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Effect type icon and name
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = getEffectIcon(effect.type),
                        contentDescription = null,
                        tint = if (effect.isEnabled) 
                            MaterialTheme.colorScheme.primary
                        else
                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        modifier = Modifier.size(24.dp)
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Column {
                        Text(
                            text = effect.name,
                            style = MaterialTheme.typography.titleSmall,
                            color = if (effect.isEnabled)
                                MaterialTheme.colorScheme.onSurface
                            else
                                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        
                        Text(
                            text = getEffectDescription(effect.type),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                
                // Effect controls
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        IconButton(
                            onClick = { showPresetsMenu = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Presets",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        
                        DropdownMenu(
                            expanded = showPresetsMenu,
                            onDismissRequest = { showPresetsMenu = false }
                        ) {
                            Text(
                                text = "Presets",
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                            )
                            
                            Divider()
                            
                            // Preset items would be populated here
                            // For example:
                            DropdownMenuItem(
                                text = { Text("Save Current Settings") },
                                onClick = {
                                    onPresetSave()
                                    showPresetsMenu = false
                                }
                            )
                            
                            Divider()
                            
                            // Example presets
                            val presets = getPresets(effect.type)
                            presets.forEach { preset ->
                                DropdownMenuItem(
                                    text = { Text(preset.name) },
                                    onClick = {
                                        onPresetLoad(preset)
                                        showPresetsMenu = false
                                    }
                                )
                            }
                        }
                    }
                    
                    // Move up/down buttons
                    if (!isFirst) {
                        IconButton(
                            onClick = onMoveUp,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowUp,
                                contentDescription = "Move Up",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    
                    if (!isLast) {
                        IconButton(
                            onClick = onMoveDown,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = "Move Down",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    
                    // Enable/disable switch
                    Switch(
                        checked = effect.isEnabled,
                        onCheckedChange = onEnableChange,
                        thumbContent = if (effect.isEnabled) {
                            {
                                Icon(
                                    imageVector = ImageVector.vectorResource(id = R.drawable.ic_audio_effects),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        } else null
                    )
                    
                    // Remove button
                    IconButton(
                        onClick = onRemove,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Remove Effect",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    
                    // Expand/collapse button
                    IconButton(
                        onClick = { expanded = !expanded },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (expanded) 
                                Icons.Default.KeyboardArrowUp 
                            else 
                                Icons.Default.KeyboardArrowDown,
                            contentDescription = if (expanded) "Collapse" else "Expand",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
            
            // Effect parameters
            AnimatedVisibility(
                visible = expanded && effect.isEnabled,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Parameters grid - arrange in rows for better UI organization
                    val parameters = effect.settings.entries.chunked(2)
                    
                    parameters.forEach { rowParams ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            rowParams.forEach { (param, value) ->
                                EffectParameter(
                                    name = param,
                                    value = value,
                                    onValueChange = { newValue ->
                                        onParameterChange(param, newValue)
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            
                            // If we have an odd number of parameters, add an empty space for balance
                            if (rowParams.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EffectParameter(
    name: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val displayName = name.replaceFirstChar { it.uppercase() }
    val formattedValue = formatEffectParameterValue(name, value)
    
    Column(
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = displayName,
                style = MaterialTheme.typography.labelMedium
            )
            
            Text(
                text = formattedValue,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        // Parameter slider
        // Use a circular style for certain parameters like frequency, Q, etc.
        val isRotaryParameter = name.lowercase() in listOf("q", "frequency", "resonance", "gain")
        
        if (isRotaryParameter) {
            RotaryKnob(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier
                    .size(60.dp)
                    .align(Alignment.CenterHorizontally)
            )
        } else {
            Slider(
                value = value,
                onValueChange = onValueChange,
                valueRange = 0f..1f
            )
        }
    }
}

@Composable
fun RotaryKnob(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    // A simple circular knob visualization
    val rotationDegrees by animateFloatAsState(targetValue = value * 270f)
    
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        // Knob background
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            shape = androidx.compose.foundation.shape.CircleShape,
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {}
        
        // Knob indicator line
        Surface(
            modifier = Modifier
                .width(2.dp)
                .height(24.dp)
                .rotate(rotationDegrees)
                .offset(y = -8.dp),
            color = MaterialTheme.colorScheme.primary
        ) {}
        
        // Knob touch area
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(2.dp)
                .clickable { }
                .pointerInput(Unit) {
                    // Here you would implement custom touch handling for knob rotation
                    // For simplicity, we're using the clickable as a placeholder
                },
            shape = androidx.compose.foundation.shape.CircleShape,
            color = Color.Transparent
        ) {}
    }
}

@Composable
fun AddEffectDialog(
    onDismiss: () -> Unit,
    onEffectTypeSelected: (String) -> Unit
) {
    val effectCategories = listOf(
        "Dynamics" to listOf(
            "compressor" to "Compressor",
            "limiter" to "Limiter",
            "gate" to "Noise Gate",
            "expander" to "Expander"
        ),
        "EQ & Filters" to listOf(
            "eq" to "Equalizer",
            "filter" to "Filter",
            "parametric_eq" to "Parametric EQ"
        ),
        "Time-Based" to listOf(
            "reverb" to "Reverb",
            "delay" to "Delay",
            "chorus" to "Chorus",
            "flanger" to "Flanger",
            "phaser" to "Phaser"
        ),
        "Distortion" to listOf(
            "distortion" to "Distortion",
            "overdrive" to "Overdrive",
            "saturation" to "Saturation"
        ),
        "Utility" to listOf(
            "gain" to "Gain",
            "stereo" to "Stereo Enhancer",
            "autopan" to "Auto Pan"
        )
    )
    
    var selectedCategory by remember { mutableStateOf(effectCategories[0].first) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Effect") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                // Categories tabs
                ScrollableTabRow(
                    selectedTabIndex = effectCategories.indexOfFirst { it.first == selectedCategory },
                    edgePadding = 0.dp
                ) {
                    effectCategories.forEach { (category, _) ->
                        Tab(
                            selected = category == selectedCategory,
                            onClick = { selectedCategory = category },
                            text = { Text(category) }
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Effects in the selected category
                LazyColumn {
                    val effects = effectCategories.find { it.first == selectedCategory }?.second ?: emptyList()
                    
                    items(effects) { (type, displayName) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onEffectTypeSelected(type) }
                                .padding(vertical = 12.dp, horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = getEffectIcon(type),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            
                            Spacer(modifier = Modifier.width(16.dp))
                            
                            Column {
                                Text(
                                    text = displayName,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                
                                Text(
                                    text = getEffectDescription(type),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// Utility functions

fun getEffectIcon(type: String): ImageVector {
    val iconResId = when (type) {
        "reverb" -> R.drawable.ic_reverb
        "delay" -> R.drawable.ic_delay
        "eq", "parametric_eq" -> R.drawable.ic_eq
        "compressor" -> R.drawable.ic_compressor
        "chorus" -> R.drawable.ic_chorus
        "distortion", "overdrive", "saturation" -> R.drawable.ic_distortion
        "filter" -> R.drawable.ic_filter
        "limiter" -> R.drawable.ic_limiter
        "gate" -> R.drawable.ic_gate
        "flanger", "phaser" -> R.drawable.ic_phaser
        "stereo" -> R.drawable.ic_stereo
        "gain" -> R.drawable.ic_gain
        "autopan" -> R.drawable.ic_autopan
        else -> R.drawable.ic_audio_effects
    }
    
    return ImageVector.vectorResource(id = iconResId)
}

fun getEffectDescription(type: String): String {
    return when (type) {
        "reverb" -> "Creates space and depth"
        "delay" -> "Creates echoes and repeats"
        "eq" -> "Shapes the frequency spectrum"
        "parametric_eq" -> "Precise frequency control"
        "compressor" -> "Controls dynamic range"
        "chorus" -> "Creates a richer, thicker sound"
        "distortion" -> "Adds harmonic distortion"
        "overdrive" -> "Soft clipping distortion"
        "saturation" -> "Adds warmth and harmonics"
        "filter" -> "Removes or emphasizes frequencies"
        "limiter" -> "Prevents audio from clipping"
        "gate" -> "Reduces noise below threshold"
        "flanger" -> "Creates a sweeping, jet-like effect"
        "phaser" -> "Creates a sweeping filter effect"
        "stereo" -> "Enhances stereo image"
        "gain" -> "Adjusts volume level"
        "autopan" -> "Automatically pans audio"
        else -> "Audio processing effect"
    }
}

fun formatEffectParameterValue(param: String, value: Float): String {
    return when (param.lowercase()) {
        "time", "delay", "decay", "predelay" -> "${(value * 5000).toInt()} ms"
        "feedback", "mix", "dry/wet", "wet", "dry", "amount", "width" -> "${(value * 100).toInt()}%"
        "ratio" -> "${1 + (value * 19).toInt()}:1"
        "frequency", "freq", "cutoff", "resonance_freq" -> "${20 + (value * 19980).toInt()} Hz"
        "q", "resonance" -> String.format("%.1f", 0.1f + (value * 9.9f))
        "threshold" -> "-${(value * 60).toInt()} dB"
        "attack", "release" -> "${(value * 1000).toInt()} ms"
        "gain", "makeup", "output" -> "${-24 + (value * 48).toInt()} dB"
        "drive", "distortion" -> "${(value * 100).toInt()}%"
        "depth" -> "${(value * 100).toInt()}%"
        "rate", "speed" -> "${0.1f + value * 9.9f} Hz"
        else -> "${(value * 100).toInt()}%"
    }
}

// Mock function to generate presets for each effect type
fun getPresets(effectType: String): List<EffectPreset> {
    return when (effectType) {
        "reverb" -> listOf(
            EffectPreset("Small Room", mapOf("decay" to 0.3f, "mix" to 0.2f, "predelay" to 0.05f)),
            EffectPreset("Large Hall", mapOf("decay" to 0.8f, "mix" to 0.4f, "predelay" to 0.1f)),
            EffectPreset("Cathedral", mapOf("decay" to 0.95f, "mix" to 0.5f, "predelay" to 0.15f))
        )
        "delay" -> listOf(
            EffectPreset("Slapback", mapOf("time" to 0.2f, "feedback" to 0.3f, "mix" to 0.3f)),
            EffectPreset("Eighth Note", mapOf("time" to 0.25f, "feedback" to 0.4f, "mix" to 0.3f)),
            EffectPreset("Quarter Note", mapOf("time" to 0.5f, "feedback" to 0.5f, "mix" to 0.3f))
        )
        "compressor" -> listOf(
            EffectPreset("Gentle", mapOf("threshold" to 0.5f, "ratio" to 0.2f, "attack" to 0.3f, "release" to 0.5f)),
            EffectPreset("Punchy", mapOf("threshold" to 0.7f, "ratio" to 0.4f, "attack" to 0.1f, "release" to 0.3f)),
            EffectPreset("Squashed", mapOf("threshold" to 0.8f, "ratio" to 0.7f, "attack" to 0.2f, "release" to 0.2f))
        )
        "eq" -> listOf(
            EffectPreset("Presence Boost", mapOf("low" to 0.5f, "mid" to 0.7f, "high" to 0.7f)),
            EffectPreset("Bass Boost", mapOf("low" to 0.8f, "mid" to 0.5f, "high" to 0.5f)),
            EffectPreset("Air", mapOf("low" to 0.5f, "mid" to 0.4f, "high" to 0.8f))
        )
        else -> listOf(
            EffectPreset("Default", emptyMap()),
            EffectPreset("Subtle", emptyMap()),
            EffectPreset("Extreme", emptyMap())
        )
    }
}
