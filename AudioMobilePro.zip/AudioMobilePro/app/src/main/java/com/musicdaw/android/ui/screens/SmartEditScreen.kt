package com.musicdaw.android.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.musicdaw.android.ai.SmartEditAI
import com.musicdaw.android.model.AudioClip
import com.musicdaw.android.model.MidiPattern
import com.musicdaw.android.model.Project
import com.musicdaw.android.viewmodel.SmartEditViewModel
import kotlinx.coroutines.launch

/**
 * Layar untuk mengedit audio secara cerdas dengan AI
 */
@Composable
fun SmartEditScreen(
    currentProject: Project?,
    selectedAudioClip: AudioClip? = null,
    onAddToProject: (AudioClip) -> Unit,
    onAddMidiToProject: (MidiPattern) -> Unit,
    onNavigateBack: () -> Unit
) {
    // ViewModel untuk mengelola pengeditan cerdas
    val viewModel: SmartEditViewModel = viewModel()
    val uiState = viewModel.uiState.collectAsState().value
    
    // State untuk UI
    val coroutineScope = rememberCoroutineScope()
    var showSeparationOptions by remember { mutableStateOf(false) }
    var showTimeStretchOptions by remember { mutableStateOf(false) }
    var showPitchShiftOptions by remember { mutableStateOf(false) }
    var showHarmonizeOptions by remember { mutableStateOf(false) }
    var showRepairOptions by remember { mutableStateOf(false) }
    var showExtractMidiOptions by remember { mutableStateOf(false) }
    
    // Inisialisasi clip yang dipilih ke ViewModel
    LaunchedEffect(selectedAudioClip) {
        if (selectedAudioClip != null) {
            viewModel.setSelectedAudioClip(selectedAudioClip)
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Top bar
        TopAppBar(
            title = {
                Text("Smart Edit")
            },
            navigationIcon = {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Kembali"
                    )
                }
            },
            backgroundColor = MaterialTheme.colors.primarySurface
        )
        
        // Main content
        when (uiState) {
            is SmartEditViewModel.UIState.Initial -> {
                // Tampilan awal - pilih audio untuk diedit
                InitialView(
                    currentProject = currentProject,
                    selectedAudioClip = viewModel.selectedAudioClip.value,
                    onAudioSelected = { viewModel.setSelectedAudioClip(it) },
                    onSeparationSelected = { showSeparationOptions = true },
                    onTimeStretchSelected = { showTimeStretchOptions = true },
                    onPitchShiftSelected = { showPitchShiftOptions = true },
                    onHarmonizeSelected = { showHarmonizeOptions = true },
                    onRepairSelected = { showRepairOptions = true },
                    onExtractMidiSelected = { showExtractMidiOptions = true }
                )
            }
            
            is SmartEditViewModel.UIState.Processing -> {
                // Tampilan memproses
                ProcessingView(
                    title = uiState.title,
                    description = uiState.description,
                    progress = uiState.progress
                )
            }
            
            is SmartEditViewModel.UIState.SeparationCompleted -> {
                // Tampilan hasil pemisahan
                SeparationResultView(
                    components = uiState.result.components,
                    onComponentSelected = { component ->
                        onAddToProject(component)
                        viewModel.resetState()
                    },
                    onAddAllToProject = {
                        uiState.result.components.values.forEach { component ->
                            onAddToProject(component)
                        }
                        viewModel.resetState()
                    },
                    onDismiss = {
                        viewModel.resetState()
                    }
                )
            }
            
            is SmartEditViewModel.UIState.EditCompleted -> {
                // Tampilan hasil pengeditan
                EditResultView(
                    resultClip = uiState.resultClip,
                    onAddToProject = {
                        onAddToProject(uiState.resultClip)
                        viewModel.resetState()
                    },
                    onDismiss = {
                        viewModel.resetState()
                    }
                )
            }
            
            is SmartEditViewModel.UIState.MidiExtractionCompleted -> {
                // Tampilan hasil ekstraksi MIDI
                MidiExtractionResultView(
                    midiPattern = uiState.midiPattern,
                    onAddToProject = {
                        onAddMidiToProject(uiState.midiPattern)
                        viewModel.resetState()
                    },
                    onDismiss = {
                        viewModel.resetState()
                    }
                )
            }
            
            is SmartEditViewModel.UIState.Error -> {
                // Tampilan kesalahan
                ErrorView(
                    errorMessage = uiState.errorMessage,
                    onDismiss = {
                        viewModel.resetState()
                    }
                )
            }
        }
    }
    
    // Dialog pemisahan audio
    if (showSeparationOptions) {
        SeparationOptionsDialog(
            onConfirm = { mode, enhanceQuality ->
                showSeparationOptions = false
                
                // Mulai proses pemisahan
                coroutineScope.launch {
                    viewModel.separateAudio(mode, enhanceQuality)
                }
            },
            onDismiss = {
                showSeparationOptions = false
            }
        )
    }
    
    // Dialog time stretch
    if (showTimeStretchOptions) {
        TimeStretchOptionsDialog(
            onConfirm = { tempoFactor, preserveTransients ->
                showTimeStretchOptions = false
                
                // Mulai proses time stretch
                coroutineScope.launch {
                    viewModel.timeStretchAudio(tempoFactor, preserveTransients)
                }
            },
            onDismiss = {
                showTimeStretchOptions = false
            }
        )
    }
    
    // Dialog pitch shift
    if (showPitchShiftOptions) {
        PitchShiftOptionsDialog(
            onConfirm = { semitones, mode, preserveFormants ->
                showPitchShiftOptions = false
                
                // Mulai proses pitch shift
                coroutineScope.launch {
                    viewModel.pitchShiftAudio(semitones, mode, preserveFormants)
                }
            },
            onDismiss = {
                showPitchShiftOptions = false
            }
        )
    }
    
    // Dialog harmonisasi
    if (showHarmonizeOptions) {
        HarmonizeOptionsDialog(
            onConfirm = { targetKey, strength ->
                showHarmonizeOptions = false
                
                // Mulai proses harmonisasi
                coroutineScope.launch {
                    viewModel.harmonizeAudio(targetKey, strength)
                }
            },
            onDismiss = {
                showHarmonizeOptions = false
            }
        )
    }
    
    // Dialog perbaikan audio
    if (showRepairOptions) {
        RepairOptionsDialog(
            onConfirm = { noiseReduction, clickRemoval, enhanceClarity ->
                showRepairOptions = false
                
                // Mulai proses perbaikan
                coroutineScope.launch {
                    viewModel.repairAudio(noiseReduction, clickRemoval, enhanceClarity)
                }
            },
            onDismiss = {
                showRepairOptions = false
            }
        )
    }
    
    // Dialog ekstraksi MIDI
    if (showExtractMidiOptions) {
        ExtractMidiOptionsDialog(
            onConfirm = { type, sensitivity, quantize ->
                showExtractMidiOptions = false
                
                // Mulai proses ekstraksi MIDI
                coroutineScope.launch {
                    viewModel.extractMidi(type, sensitivity, quantize)
                }
            },
            onDismiss = {
                showExtractMidiOptions = false
            }
        )
    }
}

/**
 * Tampilan awal untuk Smart Edit
 */
@Composable
fun InitialView(
    currentProject: Project?,
    selectedAudioClip: AudioClip?,
    onAudioSelected: (AudioClip) -> Unit,
    onSeparationSelected: () -> Unit,
    onTimeStretchSelected: () -> Unit,
    onPitchShiftSelected: () -> Unit,
    onHarmonizeSelected: () -> Unit,
    onRepairSelected: () -> Unit,
    onExtractMidiSelected: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "Edit Audio dengan AI",
                style = MaterialTheme.typography.h5,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            // Audio clip selection card
            AudioSelectionCard(
                currentProject = currentProject,
                selectedAudioClip = selectedAudioClip,
                onAudioSelected = onAudioSelected
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "Pilih Operasi Pengeditan",
                style = MaterialTheme.typography.h6,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }
        
        // Editing feature cards
        item {
            // Disable cards if no audio selected
            val isEnabled = selectedAudioClip != null
            
            // Separation card
            EditingFeatureCard(
                title = "Pisahkan Audio",
                description = "Pisahkan vokal, instrumental, drum, bass, dll",
                icon = Icons.Default.CallSplit,
                backgroundColor = Color(0xFF2196F3),
                onClick = onSeparationSelected,
                enabled = isEnabled
            )
            
            // Time Stretch card
            EditingFeatureCard(
                title = "Ubah Tempo",
                description = "Ubah tempo tanpa mengubah pitch",
                icon = Icons.Default.Speed,
                backgroundColor = Color(0xFF4CAF50),
                onClick = onTimeStretchSelected,
                enabled = isEnabled
            )
            
            // Pitch Shift card
            EditingFeatureCard(
                title = "Ubah Pitch",
                description = "Ubah nada tanpa mengubah tempo",
                icon = Icons.Default.GraphicEq,
                backgroundColor = Color(0xFF9C27B0),
                onClick = onPitchShiftSelected,
                enabled = isEnabled
            )
            
            // Harmonize card
            EditingFeatureCard(
                title = "Harmonisasi",
                description = "Koreksi nada otomatis ke kunci musik tertentu",
                icon = Icons.Default.Piano,
                backgroundColor = Color(0xFFFF9800),
                onClick = onHarmonizeSelected,
                enabled = isEnabled
            )
            
            // Repair card
            EditingFeatureCard(
                title = "Perbaiki Audio",
                description = "Kurangi noise dan perbaiki kualitas audio",
                icon = Icons.Default.Healing,
                backgroundColor = Color(0xFFF44336),
                onClick = onRepairSelected,
                enabled = isEnabled
            )
            
            // Extract MIDI card
            EditingFeatureCard(
                title = "Ekstrak MIDI",
                description = "Konversi audio menjadi pattern MIDI",
                icon = Icons.Default.MusicNote,
                backgroundColor = Color(0xFF607D8B),
                onClick = onExtractMidiSelected,
                enabled = isEnabled
            )
        }
    }
}

/**
 * Kartu untuk memilih audio clip
 */
@Composable
fun AudioSelectionCard(
    currentProject: Project?,
    selectedAudioClip: AudioClip?,
    onAudioSelected: (AudioClip) -> Unit
) {
    var showAudioSelection by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        elevation = 4.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Audio yang Dipilih",
                style = MaterialTheme.typography.h6,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            if (selectedAudioClip != null) {
                // Display selected audio info
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AudioFile,
                        contentDescription = null,
                        tint = MaterialTheme.colors.primary
                    )
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = selectedAudioClip.name,
                            style = MaterialTheme.typography.body1,
                            fontWeight = FontWeight.Bold
                        )
                        
                        Text(
                            text = "Durasi: ${formatDuration(selectedAudioClip.duration)}",
                            style = MaterialTheme.typography.caption
                        )
                    }
                    
                    IconButton(onClick = { showAudioSelection = true }) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Change Selection"
                        )
                    }
                }
            } else {
                // Prompt to select audio
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Belum ada audio yang dipilih",
                        style = MaterialTheme.typography.body1,
                        color = Color.Gray
                    )
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Button(
                        onClick = { showAudioSelection = true },
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = MaterialTheme.colors.primary
                        )
                    ) {
                        Text("Pilih Audio")
                    }
                }
            }
        }
    }
    
    // Audio selection dialog
    if (showAudioSelection) {
        AlertDialog(
            onDismissRequest = { showAudioSelection = false },
            title = {
                Text("Pilih Audio")
            },
            text = {
                LazyColumn {
                    // Display all audio clips from the project
                    if (currentProject != null) {
                        val audioClips = currentProject.tracks
                            .flatMap { it.audioClips }
                        
                        if (audioClips.isEmpty()) {
                            item {
                                Text(
                                    text = "Proyek tidak memiliki audio clip",
                                    style = MaterialTheme.typography.body1,
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 16.dp)
                                )
                            }
                        } else {
                            items(audioClips) { clip ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onAudioSelected(clip)
                                            showAudioSelection = false
                                        }
                                        .padding(vertical = 12.dp, horizontal = 16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AudioFile,
                                        contentDescription = null,
                                        tint = MaterialTheme.colors.primary
                                    )
                                    
                                    Spacer(modifier = Modifier.width(16.dp))
                                    
                                    Column {
                                        Text(
                                            text = clip.name,
                                            style = MaterialTheme.typography.body1,
                                            fontWeight = FontWeight.Bold
                                        )
                                        
                                        Text(
                                            text = "Durasi: ${formatDuration(clip.duration)}",
                                            style = MaterialTheme.typography.caption
                                        )
                                    }
                                }
                                
                                Divider()
                            }
                        }
                    } else {
                        item {
                            Text(
                                text = "Tidak ada proyek yang terbuka",
                                style = MaterialTheme.typography.body1,
                                color = Color.Gray,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAudioSelection = false }) {
                    Text("Batal")
                }
            }
        )
    }
}

/**
 * Card untuk fitur pengeditan
 */
@Composable
fun EditingFeatureCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    backgroundColor: Color,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable(enabled = enabled, onClick = onClick),
        elevation = 4.dp,
        backgroundColor = if (enabled) MaterialTheme.colors.surface else Color.LightGray
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(backgroundColor.copy(alpha = if (enabled) 1f else 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.h6,
                    fontWeight = FontWeight.Bold,
                    color = if (enabled) MaterialTheme.colors.onSurface else Color.Gray
                )
                
                Text(
                    text = description,
                    style = MaterialTheme.typography.body2,
                    color = if (enabled) MaterialTheme.colors.onSurface.copy(alpha = 0.7f) else Color.Gray
                )
            }
            
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = if (enabled) MaterialTheme.colors.primary else Color.Gray
            )
        }
    }
}

/**
 * Dialog untuk opsi pemisahan audio
 */
@Composable
fun SeparationOptionsDialog(
    onConfirm: (SmartEditAI.SeparationMode, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedMode by remember { mutableStateOf(SmartEditAI.SeparationMode.VOCAL_INSTRUMENTAL) }
    var enhanceQuality by remember { mutableStateOf(true) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Opsi Pemisahan Audio")
        },
        text = {
            Column {
                Text(
                    text = "Pilih Mode Pemisahan",
                    style = MaterialTheme.typography.subtitle1,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Mode selection
                Column {
                    SmartEditAI.SeparationMode.values().forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedMode = mode }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedMode == mode,
                                onClick = { selectedMode = mode }
                            )
                            
                            Spacer(modifier = Modifier.width(8.dp))
                            
                            Text(
                                text = formatSeparationModeLabel(mode),
                                style = MaterialTheme.typography.body1
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Enhance quality option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { enhanceQuality = !enhanceQuality }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = enhanceQuality,
                        onCheckedChange = { enhanceQuality = it }
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = "Tingkatkan kualitas hasil (lebih lambat)",
                        style = MaterialTheme.typography.body1
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedMode, enhanceQuality) }
            ) {
                Text("Pisahkan")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text("Batal")
            }
        }
    )
}

/**
 * Dialog untuk opsi time stretch
 */
@Composable
fun TimeStretchOptionsDialog(
    onConfirm: (Float, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var tempoFactor by remember { mutableStateOf(1.0f) }
    var preserveTransients by remember { mutableStateOf(true) }
    var tempoFactorText by remember { mutableStateOf("1.0") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Opsi Ubah Tempo")
        },
        text = {
            Column {
                Text(
                    text = "Faktor Tempo: ${(tempoFactor * 100).toInt()}%",
                    style = MaterialTheme.typography.subtitle1,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Tempo factor slider
                Slider(
                    value = tempoFactor,
                    onValueChange = { 
                        tempoFactor = it
                        tempoFactorText = String.format("%.1f", it)
                    },
                    valueRange = 0.5f..2.0f,
                    steps = 14, // 0.1 increments
                    modifier = Modifier.fillMaxWidth()
                )
                
                // Tempo factor text input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Masukkan nilai:",
                        style = MaterialTheme.typography.body2
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    OutlinedTextField(
                        value = tempoFactorText,
                        onValueChange = { 
                            tempoFactorText = it
                            it.toFloatOrNull()?.let { value ->
                                if (value in 0.25f..4.0f) {
                                    tempoFactor = value
                                }
                            }
                        },
                        modifier = Modifier.width(80.dp),
                        keyboardOptions = androidx.compose.ui.text.input.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                        ),
                        singleLine = true
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = "x",
                        style = MaterialTheme.typography.body1
                    )
                }
                
                // Help text
                Text(
                    text = "Nilai >1.0 mempercepat, <1.0 memperlambat",
                    style = MaterialTheme.typography.caption,
                    color = Color.Gray
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Preserve transients option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { preserveTransients = !preserveTransients }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = preserveTransients,
                        onCheckedChange = { preserveTransients = it }
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = "Pertahankan karakter transien (untuk drum/perkusi)",
                        style = MaterialTheme.typography.body1
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(tempoFactor, preserveTransients) }
            ) {
                Text("Terapkan")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text("Batal")
            }
        }
    )
}

/**
 * Dialog untuk opsi pitch shift
 */
@Composable
fun PitchShiftOptionsDialog(
    onConfirm: (Int, SmartEditAI.PitchMode, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var semitones by remember { mutableStateOf(0) }
    var selectedMode by remember { mutableStateOf(SmartEditAI.PitchMode.MELODIC) }
    var preserveFormants by remember { mutableStateOf(true) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Opsi Ubah Pitch")
        },
        text = {
            Column {
                Text(
                    text = "Semitones: ${if (semitones > 0) "+$semitones" else semitones}",
                    style = MaterialTheme.typography.subtitle1,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Semitones slider
                Slider(
                    value = semitones.toFloat(),
                    onValueChange = { semitones = it.toInt() },
                    valueRange = -12f..12f,
                    steps = 23, // -12 to +12
                    modifier = Modifier.fillMaxWidth()
                )
                
                // Help text
                Text(
                    text = "1 semitone = 1 nada (C ke C# = 1 semitone)",
                    style = MaterialTheme.typography.caption,
                    color = Color.Gray
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Mode selection
                Text(
                    text = "Mode Pitch Shift",
                    style = MaterialTheme.typography.subtitle1,
                    fontWeight = FontWeight.Bold
                )
                
                Column {
                    SmartEditAI.PitchMode.values().forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedMode = mode }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedMode == mode,
                                onClick = { selectedMode = mode }
                            )
                            
                            Spacer(modifier = Modifier.width(8.dp))
                            
                            Text(
                                text = formatPitchModeLabel(mode),
                                style = MaterialTheme.typography.body1
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Preserve formants option (if applicable)
                if (selectedMode == SmartEditAI.PitchMode.MELODIC || 
                    selectedMode == SmartEditAI.PitchMode.FORMANT_PRESERVED) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { preserveFormants = !preserveFormants }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = preserveFormants,
                            onCheckedChange = { preserveFormants = it }
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        Text(
                            text = "Pertahankan formant (untuk vokal/suara)",
                            style = MaterialTheme.typography.body1
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(semitones, selectedMode, preserveFormants) }
            ) {
                Text("Terapkan")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text("Batal")
            }
        }
    )
}

/**
 * Dialog untuk opsi harmonisasi
 */
@Composable
fun HarmonizeOptionsDialog(
    onConfirm: (String, Float) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedKey by remember { mutableStateOf("C Major") }
    var strength by remember { mutableStateOf(0.7f) }
    
    // List of music keys
    val musicKeys = listOf(
        "C Major", "G Major", "D Major", "A Major", "E Major", "B Major", "F# Major",
        "Db Major", "Ab Major", "Eb Major", "Bb Major", "F Major",
        "A Minor", "E Minor", "B Minor", "F# Minor", "C# Minor", "G# Minor", "Eb Minor",
        "Bb Minor", "F Minor", "C Minor", "G Minor", "D Minor"
    )
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Opsi Harmonisasi")
        },
        text = {
            Column {
                Text(
                    text = "Pilih Kunci Musik",
                    style = MaterialTheme.typography.subtitle1,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Key selection dropdown
                var expanded by remember { mutableStateOf(false) }
                
                Box {
                    OutlinedButton(
                        onClick = { expanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(selectedKey)
                        Spacer(modifier = Modifier.weight(1f))
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = null
                        )
                    }
                    
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.heightIn(max = 350.dp)
                    ) {
                        musicKeys.forEach { key ->
                            DropdownMenuItem(
                                onClick = {
                                    selectedKey = key
                                    expanded = false
                                }
                            ) {
                                Text(key)
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Strength slider
                Text(
                    text = "Kekuatan Koreksi: ${(strength * 100).toInt()}%",
                    style = MaterialTheme.typography.subtitle1,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Slider(
                    value = strength,
                    onValueChange = { strength = it },
                    valueRange = 0.1f..1.0f,
                    modifier = Modifier.fillMaxWidth()
                )
                
                // Help text
                Text(
                    text = "Nilai lebih tinggi = koreksi lebih kuat, nilai lebih rendah = lebih natural",
                    style = MaterialTheme.typography.caption,
                    color = Color.Gray
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedKey, strength) }
            ) {
                Text("Terapkan")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text("Batal")
            }
        }
    )
}

/**
 * Dialog untuk opsi perbaikan audio
 */
@Composable
fun RepairOptionsDialog(
    onConfirm: (Float, Float, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var noiseReduction by remember { mutableStateOf(0.5f) }
    var clickRemoval by remember { mutableStateOf(0.7f) }
    var enhanceClarity by remember { mutableStateOf(true) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Opsi Perbaikan Audio")
        },
        text = {
            Column {
                // Noise reduction slider
                Text(
                    text = "Reduksi Noise: ${(noiseReduction * 100).toInt()}%",
                    style = MaterialTheme.typography.subtitle1,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Slider(
                    value = noiseReduction,
                    onValueChange = { noiseReduction = it },
                    valueRange = 0.0f..1.0f,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Click removal slider
                Text(
                    text = "Hilangkan Klik/Pop: ${(clickRemoval * 100).toInt()}%",
                    style = MaterialTheme.typography.subtitle1,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Slider(
                    value = clickRemoval,
                    onValueChange = { clickRemoval = it },
                    valueRange = 0.0f..1.0f,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Enhance clarity option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { enhanceClarity = !enhanceClarity }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = enhanceClarity,
                        onCheckedChange = { enhanceClarity = it }
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = "Tingkatkan kejernihan suara",
                        style = MaterialTheme.typography.body1
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(noiseReduction, clickRemoval, enhanceClarity) }
            ) {
                Text("Terapkan")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text("Batal")
            }
        }
    )
}

/**
 * Dialog untuk opsi ekstraksi MIDI
 */
@Composable
fun ExtractMidiOptionsDialog(
    onConfirm: (String, Float, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedType by remember { mutableStateOf("melodic") }
    var sensitivity by remember { mutableStateOf(0.7f) }
    var quantize by remember { mutableStateOf(true) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Opsi Ekstraksi MIDI")
        },
        text = {
            Column {
                // Type selection
                Text(
                    text = "Tipe Audio",
                    style = MaterialTheme.typography.subtitle1,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedType = "melodic" }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedType == "melodic",
                        onClick = { selectedType = "melodic" }
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = "Melodis (vokal, melodi, lead, dll)",
                        style = MaterialTheme.typography.body1
                    )
                }
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedType = "percussive" }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedType == "percussive",
                        onClick = { selectedType = "percussive" }
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = "Perkusif (drum, hi-hat, dll)",
                        style = MaterialTheme.typography.body1
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Sensitivity slider
                Text(
                    text = "Sensitivitas: ${(sensitivity * 100).toInt()}%",
                    style = MaterialTheme.typography.subtitle1,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Slider(
                    value = sensitivity,
                    onValueChange = { sensitivity = it },
                    valueRange = 0.1f..1.0f,
                    modifier = Modifier.fillMaxWidth()
                )
                
                // Help text
                Text(
                    text = "Nilai lebih tinggi = deteksi lebih sensitif, mungkin mendeteksi lebih banyak nada",
                    style = MaterialTheme.typography.caption,
                    color = Color.Gray
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Quantize option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { quantize = !quantize }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = quantize,
                        onCheckedChange = { quantize = it }
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = "Kuantisasi ke grid (untuk timing yang lebih rapi)",
                        style = MaterialTheme.typography.body1
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedType, sensitivity, quantize) }
            ) {
                Text("Ekstrak MIDI")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text("Batal")
            }
        }
    )
}

/**
 * Tampilan memproses
 */
@Composable
fun ProcessingView(
    title: String,
    description: String,
    progress: Float
) {
    Column(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Autorenew,
            contentDescription = null,
            modifier = Modifier
                .size(72.dp)
                .rotate(progress * 360),
            tint = MaterialTheme.colors.primary
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = title,
            style = MaterialTheme.typography.h5,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = description,
            style = MaterialTheme.typography.body1,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp)
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Progress indicator
        LinearProgressIndicator(
            progress = progress,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "${(progress * 100).toInt()}%",
            style = MaterialTheme.typography.body2
        )
    }
}

/**
 * Tampilan hasil pemisahan audio
 */
@Composable
fun SeparationResultView(
    components: Map<String, AudioClip>,
    onComponentSelected: (AudioClip) -> Unit,
    onAddAllToProject: () -> Unit,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = Color(0xFF4CAF50) // Green
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Pemisahan Selesai!",
            style = MaterialTheme.typography.h5,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "Berhasil memisahkan audio menjadi ${components.size} komponen",
            style = MaterialTheme.typography.body1,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // List komponen
        Text(
            text = "Komponen Audio",
            style = MaterialTheme.typography.h6,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            items(components.entries.toList()) { (name, clip) ->
                ComponentCard(
                    name = formatComponentName(name),
                    clip = clip,
                    onClick = { onComponentSelected(clip) }
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Bottom buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = onAddAllToProject,
                modifier = Modifier.weight(1f)
            ) {
                Text("Tambahkan Semua")
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.weight(1f)
            ) {
                Text("Tutup")
            }
        }
    }
}

/**
 * Card untuk komponen audio
 */
@Composable
fun ComponentCard(
    name: String,
    clip: AudioClip,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable(onClick = onClick),
        elevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AudioFile,
                contentDescription = null,
                tint = MaterialTheme.colors.primary
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.body1,
                    fontWeight = FontWeight.Bold
                )
                
                Text(
                    text = "Durasi: ${formatDuration(clip.duration)}",
                    style = MaterialTheme.typography.caption
                )
            }
            
            IconButton(onClick = onClick) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add to Project",
                    tint = MaterialTheme.colors.primary
                )
            }
        }
    }
}

/**
 * Tampilan hasil pengeditan
 */
@Composable
fun EditResultView(
    resultClip: AudioClip,
    onAddToProject: () -> Unit,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = Color(0xFF4CAF50) // Green
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Pengeditan Selesai!",
            style = MaterialTheme.typography.h5,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "Berhasil membuat audio baru",
            style = MaterialTheme.typography.body1,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Result info card
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = 4.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Hasil Pengeditan",
                    style = MaterialTheme.typography.h6,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AudioFile,
                        contentDescription = null,
                        tint = MaterialTheme.colors.primary
                    )
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Column {
                        Text(
                            text = resultClip.name,
                            style = MaterialTheme.typography.body1,
                            fontWeight = FontWeight.Bold
                        )
                        
                        Text(
                            text = "Durasi: ${formatDuration(resultClip.duration)}",
                            style = MaterialTheme.typography.caption
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Metadata
                if (resultClip.metadata != null && resultClip.metadata!!.isNotEmpty()) {
                    Text(
                        text = "Informasi Proses",
                        style = MaterialTheme.typography.subtitle1,
                        fontWeight = FontWeight.Medium
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Column {
                        resultClip.metadata!!.forEach { (key, value) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = formatMetadataKey(key),
                                    style = MaterialTheme.typography.body2,
                                    color = Color.Gray
                                )
                                
                                Text(
                                    text = value,
                                    style = MaterialTheme.typography.body2
                                )
                            }
                        }
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Bottom buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = onAddToProject,
                modifier = Modifier.weight(1f)
            ) {
                Text("Tambahkan ke Proyek")
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.weight(1f)
            ) {
                Text("Tutup")
            }
        }
    }
}

/**
 * Tampilan hasil ekstraksi MIDI
 */
@Composable
fun MidiExtractionResultView(
    midiPattern: MidiPattern,
    onAddToProject: () -> Unit,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = Color(0xFF4CAF50) // Green
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Ekstraksi MIDI Selesai!",
            style = MaterialTheme.typography.h5,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "Berhasil mengekstrak ${midiPattern.notes.size} nada MIDI",
            style = MaterialTheme.typography.body1,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Result info card
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = 4.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Pattern MIDI",
                    style = MaterialTheme.typography.h6,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = MaterialTheme.colors.primary
                    )
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Column {
                        Text(
                            text = midiPattern.name,
                            style = MaterialTheme.typography.body1,
                            fontWeight = FontWeight.Bold
                        )
                        
                        Text(
                            text = "Durasi: ${formatDuration(midiPattern.duration)}",
                            style = MaterialTheme.typography.caption
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Note info
                Text(
                    text = "Informasi Nada",
                    style = MaterialTheme.typography.subtitle1,
                    fontWeight = FontWeight.Medium
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Jumlah nada",
                            style = MaterialTheme.typography.body2,
                            color = Color.Gray
                        )
                        
                        Text(
                            text = "${midiPattern.notes.size}",
                            style = MaterialTheme.typography.body2
                        )
                    }
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Range nada",
                            style = MaterialTheme.typography.body2,
                            color = Color.Gray
                        )
                        
                        val lowestNote = midiPattern.notes.minByOrNull { it.note }?.note ?: 0
                        val highestNote = midiPattern.notes.maxByOrNull { it.note }?.note ?: 0
                        
                        Text(
                            text = "${formatMidiNote(lowestNote)} - ${formatMidiNote(highestNote)}",
                            style = MaterialTheme.typography.body2
                        )
                    }
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Loop",
                            style = MaterialTheme.typography.body2,
                            color = Color.Gray
                        )
                        
                        Text(
                            text = if (midiPattern.isLooping) "Ya (${midiPattern.loopCount}x)" else "Tidak",
                            style = MaterialTheme.typography.body2
                        )
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Bottom buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = onAddToProject,
                modifier = Modifier.weight(1f)
            ) {
                Text("Tambahkan ke Proyek")
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.weight(1f)
            ) {
                Text("Tutup")
            }
        }
    }
}

/**
 * Tampilan kesalahan
 */
@Composable
fun ErrorView(
    errorMessage: String,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Error,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = Color(0xFFF44336) // Red
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Terjadi Kesalahan",
            style = MaterialTheme.typography.h5,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = errorMessage,
            style = MaterialTheme.typography.body1,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp)
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(
            onClick = onDismiss
        ) {
            Text("Kembali")
        }
    }
}

// ========== Helper Functions ==========

/**
 * Format nama mode pemisahan
 */
private fun formatSeparationModeLabel(mode: SmartEditAI.SeparationMode): String {
    return when (mode) {
        SmartEditAI.SeparationMode.VOCAL_INSTRUMENTAL -> "Vokal dan Instrumental"
        SmartEditAI.SeparationMode.STEMS_4 -> "4 Stem (Drum, Bass, Vokal, Lainnya)"
        SmartEditAI.SeparationMode.STEMS_5 -> "5 Stem (Drum, Bass, Vokal, Piano, Lainnya)"
        SmartEditAI.SeparationMode.COMPLETE_DECOMPOSITION -> "Dekomposisi Lengkap (Semua Instrumen)"
    }
}

/**
 * Format nama mode pitch
 */
private fun formatPitchModeLabel(mode: SmartEditAI.PitchMode): String {
    return when (mode) {
        SmartEditAI.PitchMode.MELODIC -> "Melodis (vokal, melodi)"
        SmartEditAI.PitchMode.PERCUSSIVE -> "Perkusif (drum, perkusi)"
        SmartEditAI.PitchMode.FORMANT_PRESERVED -> "Pertahankan Formant (vokal)"
        SmartEditAI.PitchMode.BASS_OPTIMIZED -> "Optimal untuk Bass"
    }
}

/**
 * Format nama komponen
 */
private fun formatComponentName(name: String): String {
    return name.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
}

/**
 * Format kunci metadata
 */
private fun formatMetadataKey(key: String): String {
    return key.replace("_", " ")
        .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
}

/**
 * Format durasi dalam detik menjadi format menit:detik
 */
private fun formatDuration(durationInSeconds: Float): String {
    val minutes = (durationInSeconds / 60).toInt()
    val seconds = (durationInSeconds % 60).toInt()
    return String.format("%d:%02d", minutes, seconds)
}

/**
 * Format nada MIDI menjadi nama nada
 */
private fun formatMidiNote(midiNote: Int): String {
    val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    val noteName = noteNames[midiNote % 12]
    val octave = (midiNote / 12) - 1
    return "$noteName$octave"
}