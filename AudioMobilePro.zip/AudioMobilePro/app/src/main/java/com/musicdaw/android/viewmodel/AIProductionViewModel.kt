package com.musicdaw.android.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicdaw.android.ai.AIProductionController
import com.musicdaw.android.ai.AIProductionController.ProductionResult
import com.musicdaw.android.model.Project
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

/**
 * ViewModel untuk mengelola produksi musik menggunakan AI
 */
class AIProductionViewModel : ViewModel() {
    // Controller untuk proses produksi AI
    private val productionController = AIProductionController()
    
    // UI state
    private val _uiState = MutableStateFlow<UIState>(UIState.Initial)
    val uiState: StateFlow<UIState> = _uiState
    
    /**
     * Memproses file audio referensi untuk menghasilkan proyek musik baru
     */
    suspend fun processReferenceAudio(
        referenceAudioPath: String,
        targetGenre: String?,
        projectName: String
    ) {
        _uiState.value = UIState.Processing(
            ProductionResult(
                status = AIProductionController.ProductionStatus.ANALYZING,
                statusMessage = "Memulai analisis audio referensi...",
                progressPercent = 0
            )
        )
        
        try {
            productionController.processReferenceAudio(
                referenceAudioPath = referenceAudioPath,
                targetGenre = targetGenre,
                projectName = projectName,
                progressCallback = { result ->
                    if (result.status == AIProductionController.ProductionStatus.ERROR) {
                        _uiState.value = UIState.Error(result.errorMessage ?: "Terjadi kesalahan yang tidak diketahui")
                    } else if (result.status == AIProductionController.ProductionStatus.COMPLETED) {
                        _uiState.value = UIState.Completed(result)
                    } else {
                        _uiState.value = UIState.Processing(result)
                    }
                }
            )
        } catch (e: Exception) {
            _uiState.value = UIState.Error(e.message ?: "Terjadi kesalahan yang tidak diketahui")
        }
    }
    
    /**
     * Mengoptimalkan proyek musik yang ada
     */
    fun optimizeProject(
        project: Project,
        targetGenre: String? = null
    ) {
        _uiState.value = UIState.Processing(
            ProductionResult(
                status = AIProductionController.ProductionStatus.ANALYZING,
                statusMessage = "Memulai optimasi proyek...",
                progressPercent = 0,
                project = project
            )
        )
        
        viewModelScope.launch {
            try {
                productionController.optimizeProject(
                    project = project,
                    targetGenre = targetGenre,
                    progressCallback = { result ->
                        if (result.status == AIProductionController.ProductionStatus.ERROR) {
                            _uiState.value = UIState.Error(result.errorMessage ?: "Terjadi kesalahan saat optimasi")
                        } else if (result.status == AIProductionController.ProductionStatus.COMPLETED) {
                            _uiState.value = UIState.Completed(result)
                        } else {
                            _uiState.value = UIState.Processing(result)
                        }
                    }
                )
            } catch (e: Exception) {
                _uiState.value = UIState.Error(e.message ?: "Terjadi kesalahan saat optimasi")
            }
        }
    }
    
    /**
     * Mengkonversi proyek ke genre yang berbeda
     */
    fun convertProjectToGenre(
        project: Project,
        targetGenre: String
    ) {
        _uiState.value = UIState.Processing(
            ProductionResult(
                status = AIProductionController.ProductionStatus.ANALYZING,
                statusMessage = "Memulai konversi genre...",
                progressPercent = 0,
                project = project
            )
        )
        
        viewModelScope.launch {
            try {
                productionController.convertProjectToGenre(
                    project = project,
                    targetGenre = targetGenre,
                    progressCallback = { result ->
                        if (result.status == AIProductionController.ProductionStatus.ERROR) {
                            _uiState.value = UIState.Error(result.errorMessage ?: "Terjadi kesalahan saat konversi")
                        } else if (result.status == AIProductionController.ProductionStatus.COMPLETED) {
                            _uiState.value = UIState.Completed(result)
                        } else {
                            _uiState.value = UIState.Processing(result)
                        }
                    }
                )
            } catch (e: Exception) {
                _uiState.value = UIState.Error(e.message ?: "Terjadi kesalahan saat konversi")
            }
        }
    }
    
    /**
     * Ekstrak sampel audio dari file
     */
    fun extractSamples(
        audioPath: String
    ) {
        _uiState.value = UIState.Processing(
            ProductionResult(
                status = AIProductionController.ProductionStatus.EXTRACTING_SAMPLES,
                statusMessage = "Mengekstrak sampel dari audio...",
                progressPercent = 0
            )
        )
        
        viewModelScope.launch {
            try {
                productionController.extractSamples(
                    audioPath = audioPath,
                    progressCallback = { progress, message ->
                        _uiState.value = UIState.Processing(
                            ProductionResult(
                                status = AIProductionController.ProductionStatus.EXTRACTING_SAMPLES,
                                statusMessage = message,
                                progressPercent = (progress * 100).toInt()
                            )
                        )
                    }
                )
            } catch (e: Exception) {
                _uiState.value = UIState.Error(e.message ?: "Terjadi kesalahan saat ekstraksi sampel")
            }
        }
    }
    
    /**
     * Mendapatkan daftar file referensi yang tersedia
     */
    fun getAvailableReferenceFiles(): List<String> {
        // Untuk simulasi, kita buat daftar file referensi
        return listOf(
            "DJ Bantengan - Ritual Gamelan.mp3",
            "DJ Nrotok - Kebut Jalan Raya.mp3",
            "Koplo Jawa Timur - Campursari Modern.mp3",
            "Dangdut Koplo - Jaran Goyang.mp3",
            "DJ Trap - Bass Nation.mp3",
            "EDM - Summer Vibes.mp3"
        )
    }
    
    /**
     * Reset state ke status awal
     */
    fun resetState() {
        _uiState.value = UIState.Initial
    }
    
    /**
     * State UI untuk produksi musik AI
     */
    sealed class UIState {
        object Initial : UIState()
        data class Processing(val productionResult: ProductionResult) : UIState()
        data class Completed(val productionResult: ProductionResult) : UIState()
        data class Error(val errorMessage: String) : UIState()
    }
}