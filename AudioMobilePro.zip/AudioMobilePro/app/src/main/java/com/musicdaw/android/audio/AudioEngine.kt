package com.musicdaw.android.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.musicdaw.android.model.Project
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Core audio engine for playback and processing
 */
class AudioEngine(private val context: Context) : DefaultLifecycleObserver {
    
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    
    // Audio output configuration
    private var sampleRate: Int = 48000
    private var bufferSize: Int = 2048
    private var audioTrack: AudioTrack? = null
    
    // Playback state
    private val isInitialized = AtomicBoolean(false)
    private val isPlaying = AtomicBoolean(false)
    private val isRecording = AtomicBoolean(false)
    private val playbackPositionMs = AtomicInteger(0)
    private var playbackJob: Job? = null
    
    // State flows for observers
    private val _playbackState = MutableStateFlow(PlaybackState.STOPPED)
    val playbackState: StateFlow<PlaybackState> = _playbackState
    
    private val _currentPosition = MutableStateFlow(0f)
    val currentPosition: StateFlow<Float> = _currentPosition
    
    private val _meterLevels = MutableStateFlow<List<Float>>(emptyList())
    val meterLevels: StateFlow<List<Float>> = _meterLevels
    
    private var currentProject: Project? = null
    
    /**
     * Initialize the audio engine
     */
    fun initialize() {
        if (isInitialized.get()) return
        
        try {
            // Create AudioTrack
            val minBufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_FLOAT
            )
            
            val actualBufferSize = maxOf(minBufferSize, bufferSize * 4)
            
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(actualBufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            
            isInitialized.set(true)
        } catch (e: Exception) {
            e.printStackTrace()
            // Reset everything on error
            releaseResources()
        }
    }
    
    /**
     * Set the current project for playback
     */
    fun setProject(project: Project) {
        currentProject = project
    }
    
    /**
     * Start playback from the current position
     */
    fun startPlayback() {
        if (!isInitialized.get() || isPlaying.get() || currentProject == null) {
            return
        }
        
        try {
            audioTrack?.play()
            
            isPlaying.set(true)
            _playbackState.value = PlaybackState.PLAYING
            
            playbackJob = scope.launch {
                // Audio rendering loop
                val buffer = FloatArray(bufferSize * 2) // Stereo buffer
                
                val startTimeNanos = System.nanoTime()
                val startPositionMs = playbackPositionMs.get()
                
                while (isActive && isPlaying.get()) {
                    // In a real implementation, this would render audio
                    // For the prototype, we'll just fill the buffer with silence
                    buffer.fill(0f)
                    
                    // Simulate dummy meter levels (random values)
                    val dummyMeterLevels = currentProject?.tracks?.map {
                        (0.1f + Math.random() * 0.4f).toFloat()
                    } ?: emptyList()
                    
                    _meterLevels.value = dummyMeterLevels + listOf(0.5f) // Add master level
                    
                    // Calculate current position
                    val elapsedTimeNanos = System.nanoTime() - startTimeNanos
                    val elapsedTimeMs = elapsedTimeNanos / 1_000_000
                    val currentPositionMs = startPositionMs + elapsedTimeMs
                    
                    playbackPositionMs.set(currentPositionMs.toInt())
                    _currentPosition.value = currentPositionMs / 1000f
                    
                    // Check if we've reached the end of the project
                    if (_currentPosition.value >= (currentProject?.duration ?: 0f)) {
                        stopPlayback()
                        break
                    }
                    
                    // Small delay to avoid hogging the CPU
                    delay(50)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            stopPlayback()
        }
    }
    
    /**
     * Stop playback
     */
    fun stopPlayback() {
        if (!isPlaying.get()) return
        
        playbackJob?.cancel()
        playbackJob = null
        
        try {
            audioTrack?.pause()
            audioTrack?.flush()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        isPlaying.set(false)
        _playbackState.value = PlaybackState.STOPPED
    }
    
    /**
     * Pause playback
     */
    fun pausePlayback() {
        if (!isPlaying.get()) return
        
        playbackJob?.cancel()
        playbackJob = null
        
        try {
            audioTrack?.pause()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        isPlaying.set(false)
        _playbackState.value = PlaybackState.PAUSED
    }
    
    /**
     * Seek to position in seconds
     */
    fun seekTo(positionSeconds: Float) {
        val wasPlaying = isPlaying.get()
        
        if (wasPlaying) {
            pausePlayback()
        }
        
        val positionMs = (positionSeconds * 1000).toInt()
        playbackPositionMs.set(positionMs)
        _currentPosition.value = positionSeconds
        
        if (wasPlaying) {
            startPlayback()
        }
    }
    
    /**
     * Release resources
     */
    fun release() {
        stopPlayback()
        
        try {
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        isInitialized.set(false)
        scope.cancel()
    }
    
    /**
     * Clean up when the app is destroyed
     */
    override fun onDestroy(owner: LifecycleOwner) {
        release()
        super.onDestroy(owner)
    }
    
    /**
     * Playback states
     */
    enum class PlaybackState {
        PLAYING,
        PAUSED,
        STOPPED,
        RECORDING
    }
}