package com.musicdaw.android.ai

import com.musicdaw.android.model.*
import java.util.*
import kotlin.math.sin

/**
 * AI yang khusus memahami dan menghasilkan musik berbagai genre, 
 * terutama untuk genre lokal Indonesia seperti DJ Bantengan, DJ Nrotok, dan DJ Trap.
 * 
 * AI ini memiliki pengetahuan tingkat tinggi tentang genre-genre musik yang ada di YouTube
 * dan mampu memproduksi musik yang 100% sesuai dengan karakteristik genre yang dipilih.
 */
class MusicGenreAI {

    private val genreSpecialist = GenreSpecialistAI()
    private val genreBasedGenerator = GenreBasedGenerator(genreSpecialist)
    
    /**
     * Menganalisis proyek musik untuk mengidentifikasi genre-nya
     */
    fun analyzeProjectGenre(project: Project): Map<String, Float> {
        return genreSpecialist.detectGenre(project)
    }
    
    /**
     * Menghasilkan proyek baru dengan genre spesifik
     */
    fun generateProjectForGenre(genreName: String, projectName: String): Project {
        return genreBasedGenerator.generateProject(genreName, projectName)
    }
    
    /**
     * Mendapatkan karakteristik genre untuk membuat musik
     */
    fun getGenreCharacteristics(genreName: String): GenreCharacteristics {
        return genreSpecialist.getGenreCharacteristics(genreName)
    }
    
    /**
     * Mengubah proyek musik menjadi genre tertentu
     * Mempertahankan elemen musikal dasar sambil mengadopsi karakteristik genre target
     */
    fun transformProjectToGenre(project: Project, targetGenre: String): Project {
        // Dapatkan karakteristik genre target
        val targetCharacteristics = genreSpecialist.getGenreCharacteristics(targetGenre)
        
        // Clone proyek asli
        val transformedProject = project.copy(
            name = "${project.name} (${targetGenre})",
            tempo = targetCharacteristics.tempo
        )
        
        // Ubah track sesuai genre target
        val transformedTracks = transformedProject.tracks.map { track ->
            transformTrackToGenre(track, targetGenre, targetCharacteristics)
        }
        
        // Tambahkan track spesifik genre jika diperlukan
        val specialGenreTrack = createSpecialTrackForGenre(targetGenre, targetCharacteristics)
        val finalTracks = if (specialGenreTrack != null) {
            transformedTracks + specialGenreTrack
        } else {
            transformedTracks
        }
        
        return transformedProject.copy(
            tracks = finalTracks
        )
    }
    
    /**
     * Ubah track sesuai dengan genre target
     */
    private fun transformTrackToGenre(
        track: Track, 
        targetGenre: String,
        targetCharacteristics: GenreCharacteristics
    ): Track {
        // Track drum perlu pola yang benar-benar sesuai genre
        if (track.isDrumTrack) {
            return transformDrumTrack(track, targetCharacteristics)
        }
        
        // Track bass perlu diubah untuk match dengan karakteristik genre
        if (track.name.contains("bass", ignoreCase = true)) {
            return transformBassTrack(track, targetCharacteristics)
        }
        
        // Track melodi perlu disesuaikan dengan skala genre target
        if (track.name.contains("lead", ignoreCase = true) || 
            track.name.contains("melody", ignoreCase = true) ||
            track.name.contains("melodi", ignoreCase = true)) {
            return transformMelodicTrack(track, targetCharacteristics)
        }
        
        // Track lain dapat dipertahankan dengan penyesuaian minimal
        val genreEffects = genreSpecialist.getRecommendedEffectsForGenre(targetGenre)
        
        // Tambahkan efek genre sambil mempertahankan efek asli yang penting
        val updatedEffects = track.effects.filter { effect ->
            // Pertahankan efek penting (EQ, compressor)
            effect.type == "eq" || effect.type == "compressor"
        } + genreEffects.filter { effect ->
            // Tambahkan efek khas genre (reverb, delay, dll)
            effect.type != "eq" && effect.type != "compressor"
        }
        
        return track.copy(
            effects = updatedEffects
        )
    }
    
    /**
     * Ubah track drum sesuai dengan karakteristik genre target
     */
    private fun transformDrumTrack(track: Track, characteristics: GenreCharacteristics): Track {
        // Buat pola drum baru sesuai genre
        val newDrumPattern = when (characteristics.drumPattern) {
            DrumPattern.BANTENGAN_BEAT -> createDrumPatternForGenre(DrumPattern.BANTENGAN_BEAT)
            DrumPattern.NROTOK_PATTERN -> createDrumPatternForGenre(DrumPattern.NROTOK_PATTERN)
            DrumPattern.KOPLO_KENDANG -> createDrumPatternForGenre(DrumPattern.KOPLO_KENDANG)
            DrumPattern.DANGDUT_GROOVE -> createDrumPatternForGenre(DrumPattern.DANGDUT_GROOVE)
            DrumPattern.TRAP_HIHAT -> createDrumPatternForGenre(DrumPattern.TRAP_HIHAT)
            DrumPattern.EDM_BUILDUP -> createDrumPatternForGenre(DrumPattern.EDM_BUILDUP)
            else -> createDrumPatternForGenre(DrumPattern.BASIC_BEAT)
        }
        
        // Pertahankan pola asli untuk referensi jika ada
        val patterns = listOf(newDrumPattern) + track.midiPatterns.map { 
            it.copy(isActive = false) // Non-aktifkan pola asli
        }
        
        return track.copy(
            midiPatterns = patterns
        )
    }
    
    /**
     * Ubah track bass sesuai dengan karakteristik genre target
     */
    private fun transformBassTrack(track: Track, characteristics: GenreCharacteristics): Track {
        // Buat pola bass baru sesuai genre
        val newBassPattern = when (characteristics.bassPattern) {
            BassPattern.BANTENGAN_STYLE -> createBassPatternForGenre(BassPattern.BANTENGAN_STYLE)
            BassPattern.HEAVY_DROP -> createBassPatternForGenre(BassPattern.HEAVY_DROP)
            BassPattern.TRAP_808 -> createBassPatternForGenre(BassPattern.TRAP_808)
            BassPattern.FOUR_ON_FLOOR -> createBassPatternForGenre(BassPattern.FOUR_ON_FLOOR)
            BassPattern.STEADY_RHYTHMIC -> createBassPatternForGenre(BassPattern.STEADY_RHYTHMIC)
            BassPattern.MELODIC_BASS -> createBassPatternForGenre(BassPattern.MELODIC_BASS)
            else -> createBassPatternForGenre(BassPattern.STANDARD)
        }
        
        // EQ dan efek bass yang sesuai untuk genre
        val bassEffects = listOf(
            Effect(
                name = "Bass EQ",
                type = "eq",
                settings = mapOf(
                    "low" to 0.8f,
                    "mid" to 0.5f,
                    "high" to 0.3f,
                    "low_freq" to characteristics.bassFrequency / 500f
                )
            ),
            Effect(
                name = "Bass Compressor",
                type = "compressor",
                settings = mapOf(
                    "threshold" to 0.6f,
                    "ratio" to 0.7f,
                    "attack" to 0.1f,
                    "release" to 0.4f,
                    "gain" to 0.6f
                )
            )
        )
        
        // Pertahankan pola asli untuk referensi
        val patterns = listOf(newBassPattern) + track.midiPatterns.map { 
            it.copy(isActive = false) // Non-aktifkan pola asli
        }
        
        return track.copy(
            midiPatterns = patterns,
            effects = bassEffects
        )
    }
    
    /**
     * Ubah track melodi sesuai dengan karakteristik genre target
     */
    private fun transformMelodicTrack(track: Track, characteristics: GenreCharacteristics): Track {
        // Buat pola melodi baru sesuai skala genre
        val newMelodicPattern = when (characteristics.scalePreference) {
            "pelog" -> createMelodicPatternForScale("pelog")
            "slendro" -> createMelodicPatternForScale("slendro")
            "arabic" -> createMelodicPatternForScale("arabic")
            "minor" -> createMelodicPatternForScale("minor")
            "major" -> createMelodicPatternForScale("major")
            else -> createMelodicPatternForScale("diatonic")
        }
        
        // Efek yang sesuai untuk melodi dalam genre ini
        val melodicEffects = listOf(
            Effect(
                name = "Melodic Reverb",
                type = "reverb",
                settings = mapOf(
                    "mix" to 0.4f,
                    "decay" to 0.5f,
                    "predelay" to 0.1f,
                    "size" to 0.6f,
                    "damping" to 0.5f
                )
            ),
            Effect(
                name = "Melodic Delay",
                type = "delay",
                settings = mapOf(
                    "time" to 0.3f,
                    "feedback" to 0.3f,
                    "mix" to 0.25f
                )
            )
        )
        
        // Pertahankan pola asli untuk referensi
        val patterns = listOf(newMelodicPattern) + track.midiPatterns.map { 
            it.copy(isActive = false) // Non-aktifkan pola asli
        }
        
        return track.copy(
            midiPatterns = patterns,
            effects = melodicEffects
        )
    }
    
    /**
     * Membuat pola drum untuk genre spesifik
     */
    private fun createDrumPatternForGenre(patternType: DrumPattern): MidiPattern {
        // Generate pola drum berdasarkan tipe
        return when (patternType) {
            DrumPattern.BANTENGAN_BEAT -> createBantenganDrumPattern()
            DrumPattern.NROTOK_PATTERN -> createNrotokDrumPattern()
            DrumPattern.KOPLO_KENDANG -> createKoploDrumPattern()
            DrumPattern.DANGDUT_GROOVE -> createDangdutDrumPattern()
            DrumPattern.TRAP_HIHAT -> createTrapDrumPattern()
            DrumPattern.EDM_BUILDUP -> createEdmDrumPattern()
            else -> createBasicDrumPattern()
        }
    }
    
    /**
     * Membuat pola bass untuk genre spesifik
     */
    private fun createBassPatternForGenre(patternType: BassPattern): MidiPattern {
        // Generate pola bass berdasarkan tipe
        return when (patternType) {
            BassPattern.BANTENGAN_STYLE -> createBantenganBassPattern()
            BassPattern.HEAVY_DROP -> createHeavyDropBassPattern()
            BassPattern.TRAP_808 -> createTrap808BassPattern()
            BassPattern.FOUR_ON_FLOOR -> createFourOnFloorBassPattern()
            BassPattern.STEADY_RHYTHMIC -> createSteadyRhythmicBassPattern()
            BassPattern.MELODIC_BASS -> createMelodicBassPattern()
            else -> createStandardBassPattern()
        }
    }
    
    /**
     * Membuat pola melodi untuk skala tertentu
     */
    private fun createMelodicPatternForScale(scale: String): MidiPattern {
        // Generate pola melodi berdasarkan skala
        return when (scale) {
            "pelog" -> createPelogMelodicPattern()
            "slendro" -> createSlendroMelodicPattern()
            "arabic" -> createArabicMelodicPattern()
            "minor" -> createMinorMelodicPattern()
            "major" -> createMajorMelodicPattern()
            else -> createDiatonicMelodicPattern()
        }
    }
    
    /**
     * Membuat track khusus untuk genre tertentu
     */
    private fun createSpecialTrackForGenre(
        genreName: String, 
        characteristics: GenreCharacteristics
    ): Track? {
        return when (genreName.toLowerCase()) {
            "dj bantengan" -> {
                // Track gamelan khusus untuk DJ Bantengan
                Track(
                    name = "Gamelan Accent",
                    type = TrackType.AUDIO,
                    color = 0xFFFFEB3B.toInt(), // Yellow
                    audioClips = listOf(
                        AudioClip(
                            name = "Gong Accent",
                            filePath = "/samples/gamelan/Gong_Ageng.wav",
                            startTime = 0f,
                            duration = 2f,
                            isLooping = false
                        ),
                        AudioClip(
                            name = "Kempul Ornament",
                            filePath = "/samples/gamelan/Kempul_Fill.wav",
                            startTime = 4f,
                            duration = 1f,
                            isLooping = false
                        ),
                        AudioClip(
                            name = "Bonang Pattern",
                            filePath = "/samples/gamelan/Bonang_Pattern.wav",
                            startTime = 8f,
                            duration = 4f,
                            isLooping = true,
                            loopCount = 4
                        )
                    ),
                    volume = 0.75f,
                    effects = listOf(
                        Effect(
                            name = "Gamelan Reverb",
                            type = "reverb",
                            settings = mapOf(
                                "mix" to 0.6f,
                                "decay" to 0.7f,
                                "predelay" to 0.1f,
                                "size" to 0.9f,
                                "damping" to 0.3f
                            )
                        )
                    )
                )
            }
            
            "dj nrotok" -> {
                // Track vokal khusus untuk DJ Nrotok
                Track(
                    name = "Vocal Chops",
                    type = TrackType.AUDIO,
                    color = 0xFFF44336.toInt(), // Red
                    audioClips = listOf(
                        AudioClip(
                            name = "Vocal Chant",
                            filePath = "/samples/vocals/Nrotok_Vocal_Chant.wav",
                            startTime = 2f,
                            duration = 1f,
                            isLooping = true,
                            loopCount = 8
                        ),
                        AudioClip(
                            name = "Vocal Phrase",
                            filePath = "/samples/vocals/Nrotok_Vocal_Phrase.wav",
                            startTime = 16f,
                            duration = 2f,
                            isLooping = false
                        )
                    ),
                    volume = 0.7f,
                    effects = listOf(
                        Effect(
                            name = "Vocal Delay",
                            type = "delay",
                            settings = mapOf(
                                "time" to 0.125f,
                                "feedback" to 0.6f,
                                "mix" to 0.4f
                            )
                        ),
                        Effect(
                            name = "Vocal Filter",
                            type = "filter",
                            settings = mapOf(
                                "cutoff" to 0.7f,
                                "resonance" to 0.5f,
                                "type" to 0.0f // 0.0 = lowpass
                            )
                        )
                    )
                )
            }
            
            else -> null
        }
    }
    
    /**
     * Dekomposisi lagu menjadi elemen-elemen terpisah menggunakan AI
     * Khusus untuk genre lokal seperti DJ Bantengan atau DJ Nrotok yang kompleks
     */
    fun decomposeTrack(audioClip: AudioClip): List<AudioClip> {
        // Dalam implementasi sesungguhnya, ini akan menggunakan model AI khusus
        // untuk memisahkan suara gamelan, percussion, vokal, dll
        
        // Untuk simulasi, kita buat komponen hasil dekomposisi:
        val components = mutableListOf<AudioClip>()
        
        // Komponen drum/perkusi
        components.add(
            AudioClip(
                name = "${audioClip.name} - Drums",
                filePath = "${audioClip.filePath}_drums",
                startTime = audioClip.startTime,
                duration = audioClip.duration,
                isLooping = audioClip.isLooping,
                loopCount = audioClip.loopCount
            )
        )
        
        // Komponen bass
        components.add(
            AudioClip(
                name = "${audioClip.name} - Bass",
                filePath = "${audioClip.filePath}_bass",
                startTime = audioClip.startTime,
                duration = audioClip.duration,
                isLooping = audioClip.isLooping,
                loopCount = audioClip.loopCount
            )
        )
        
        // Komponen melodi
        components.add(
            AudioClip(
                name = "${audioClip.name} - Melody",
                filePath = "${audioClip.filePath}_melody",
                startTime = audioClip.startTime,
                duration = audioClip.duration,
                isLooping = audioClip.isLooping,
                loopCount = audioClip.loopCount
            )
        )
        
        // Tambahkan komponen khusus genre jika terdeteksi
        val detectedGenre = detectGenreFromAudioClip(audioClip)
        
        if (detectedGenre.contains("bantengan", ignoreCase = true)) {
            components.add(
                AudioClip(
                    name = "${audioClip.name} - Gamelan",
                    filePath = "${audioClip.filePath}_gamelan",
                    startTime = audioClip.startTime,
                    duration = audioClip.duration,
                    isLooping = audioClip.isLooping,
                    loopCount = audioClip.loopCount
                )
            )
        } else if (detectedGenre.contains("nrotok", ignoreCase = true)) {
            components.add(
                AudioClip(
                    name = "${audioClip.name} - Vocals",
                    filePath = "${audioClip.filePath}_vocals",
                    startTime = audioClip.startTime,
                    duration = audioClip.duration,
                    isLooping = audioClip.isLooping,
                    loopCount = audioClip.loopCount
                )
            )
        }
        
        return components
    }
    
    /**
     * Deteksi genre dari audio clip
     */
    private fun detectGenreFromAudioClip(audioClip: AudioClip): String {
        // Dalam implementasi sesungguhnya, ini akan menggunakan model AI 
        // untuk menganalisis audio dan mendeteksi genre
        
        // Untuk simulasi, kita deteksi dari nama file
        return when {
            audioClip.name.contains("banten", ignoreCase = true) -> "DJ Bantengan"
            audioClip.name.contains("nrotok", ignoreCase = true) -> "DJ Nrotok"
            audioClip.name.contains("koplo", ignoreCase = true) -> "Koplo"
            audioClip.name.contains("dangdut", ignoreCase = true) -> "Dangdut"
            audioClip.name.contains("trap", ignoreCase = true) -> "Trap"
            else -> "Unknown"
        }
    }
    
    /**
     * Konversi genre - mengubah lagu dari satu genre ke genre lain dengan
     * mempertahankan elemen musikal utama
     */
    fun convertGenre(audioClip: AudioClip, targetGenre: String): AudioClip {
        // Dalam implementasi sesungguhnya, ini akan menggunakan model AI kompleks
        // Untuk uji coba, kita simulasikan konversi dengan mengembalikan audio clip baru
        
        return AudioClip(
            name = "${audioClip.name} (${targetGenre})",
            filePath = "${audioClip.filePath}_${targetGenre.toLowerCase().replace(" ", "_")}",
            startTime = audioClip.startTime,
            duration = audioClip.duration,
            isLooping = audioClip.isLooping,
            loopCount = audioClip.loopCount
        )
    }
    
    // Implementasi pattern generator (metode pembantu)
    private fun createBantenganDrumPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Kick pattern (note 36)
        for (i in 0 until 16 step 4) {
            notes.add(MidiNote(note = 36, startTime = i/4f, duration = 0.25f, velocity = 100))
        }
        notes.add(MidiNote(note = 36, startTime = 2.5f, duration = 0.25f, velocity = 90))
        
        // Snare pattern (note 38) - syncopated
        for (i in 0 until 16 step 8) {
            notes.add(MidiNote(note = 38, startTime = (i + 4)/4f, duration = 0.25f, velocity = 90))
        }
        notes.add(MidiNote(note = 38, startTime = 3.5f, duration = 0.25f, velocity = 85))
        
        // Hi-hat pattern (note 42) - rapid, energetic
        for (i in 0 until 32) {
            val velocity = if (i % 2 == 0) 80 else 60
            notes.add(MidiNote(note = 42, startTime = i/8f, duration = 0.1f, velocity = velocity))
        }
        
        return MidiPattern(
            name = "Bantengan Beat",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createNrotokDrumPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Very intense kick pattern (note 36)
        for (i in 0 until 16) {
            if (i % 4 == 0 || i % 8 == 6) { // Downbeats and syncopated accent
                notes.add(MidiNote(note = 36, startTime = i/4f, duration = 0.25f, velocity = 110))
            }
        }
        
        // Snare pattern (note 38) - fast and energetic
        for (i in 0 until 16) {
            if (i % 4 == 2 || i % 8 == 7) {
                notes.add(MidiNote(note = 38, startTime = i/4f, duration = 0.25f, 
                                 velocity = if (i % 4 == 2) 95 else 85))
            }
        }
        
        // Hi-hat pattern (note 42) - extremely rapid
        for (i in 0 until 64) {
            val velocity = if (i % 4 == 0) 90 else if (i % 2 == 0) 70 else 50
            notes.add(MidiNote(note = 42, startTime = i/16f, duration = 0.05f, velocity = velocity))
        }
        
        return MidiPattern(
            name = "Nrotok Beat",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createKoploDrumPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Kendang base pattern (custom mapping: 36=low, 38=mid, 40=high)
        val kendangPattern = listOf(
            Pair(36, 0.0f), // dung
            Pair(40, 0.25f), // tak
            Pair(38, 0.5f), // mid
            Pair(40, 0.75f), // tak
            Pair(36, 1.0f), // dung
            Pair(40, 1.25f), // tak
            Pair(38, 1.5f), // mid
            Pair(38, 1.75f), // mid
            
            Pair(36, 2.0f), // dung
            Pair(40, 2.25f), // tak
            Pair(38, 2.5f), // mid
            Pair(40, 2.75f), // tak
            Pair(36, 3.0f), // dung
            Pair(40, 3.25f), // tak
            Pair(38, 3.375f), // mid (filler)
            Pair(40, 3.5f), // tak
            Pair(38, 3.625f), // mid (filler)
            Pair(40, 3.75f), // tak
            Pair(38, 3.875f)  // mid (filler)
        )
        
        // Add kendang notes
        for (note in kendangPattern) {
            notes.add(MidiNote(
                note = note.first,
                startTime = note.second,
                duration = 0.125f,
                velocity = if (note.first == 36) 100 else if (note.first == 40) 90 else 85
            ))
        }
        
        return MidiPattern(
            name = "Koplo Kendang",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createDangdutDrumPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Ketipung/tabla pattern (custom mapping: 36=low, 37=dum, 38=tak, 39=slap)
        val ketipungPattern = listOf(
            Pair(37, 0.0f),   // dum
            Pair(38, 0.5f),   // tak
            Pair(37, 1.0f),   // dum
            Pair(38, 1.5f),   // tak
            
            Pair(37, 2.0f),   // dum
            Pair(38, 2.5f),   // tak
            Pair(39, 2.75f),  // slap (ornament)
            Pair(37, 3.0f),   // dum
            Pair(38, 3.5f),   // tak
            Pair(39, 3.75f)   // slap (ornament)
        )
        
        // Add ketipung/tabla notes
        for (note in ketipungPattern) {
            notes.add(MidiNote(
                note = note.first,
                startTime = note.second,
                duration = 0.25f,
                velocity = if (note.first == 39) 85 else if (note.first == 37) 95 else 90
            ))
        }
        
        return MidiPattern(
            name = "Dangdut Groove",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createTrapDrumPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // 808 kick pattern (note 36)
        notes.add(MidiNote(note = 36, startTime = 0.0f, duration = 0.5f, velocity = 110))
        notes.add(MidiNote(note = 36, startTime = 1.0f, duration = 0.5f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 2.0f, duration = 0.5f, velocity = 110))
        notes.add(MidiNote(note = 36, startTime = 3.0f, duration = 0.5f, velocity = 100))
        
        // Snare pattern (note 38)
        notes.add(MidiNote(note = 38, startTime = 1.0f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 38, startTime = 3.0f, duration = 0.25f, velocity = 90))
        
        // Hi-hat pattern (note 42) - trademark trap triplets
        for (i in 0 until 3) {
            val startTime = 1.0f + (i / 6.0f)
            notes.add(MidiNote(note = 42, startTime = startTime, duration = 0.1f, velocity = 75))
        }
        
        for (i in 0 until 3) {
            val startTime = 3.0f + (i / 6.0f)
            notes.add(MidiNote(note = 42, startTime = startTime, duration = 0.1f, velocity = 75))
        }
        
        return MidiPattern(
            name = "Trap Beat",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createEdmDrumPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Four-on-the-floor kick pattern (note 36)
        for (i in 0 until 4) {
            notes.add(MidiNote(note = 36, startTime = i.toFloat(), duration = 0.25f, velocity = 100))
        }
        
        // Clap/snare on the offbeats (note 39)
        for (i in 0 until 2) {
            notes.add(MidiNote(note = 39, startTime = 1.0f + (i * 2), duration = 0.25f, velocity = 90))
        }
        
        // Open hi-hat (note 46) on offbeats
        for (i in 0 until 4) {
            notes.add(MidiNote(note = 46, startTime = 0.5f + i.toFloat(), duration = 0.25f, velocity = 80))
        }
        
        return MidiPattern(
            name = "EDM Buildup",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createBasicDrumPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Basic kick pattern (note 36)
        notes.add(MidiNote(note = 36, startTime = 0.0f, duration = 0.25f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 1.0f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 36, startTime = 2.0f, duration = 0.25f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 3.0f, duration = 0.25f, velocity = 90))
        
        // Basic snare pattern (note 38)
        notes.add(MidiNote(note = 38, startTime = 1.0f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 38, startTime = 3.0f, duration = 0.25f, velocity = 90))
        
        return MidiPattern(
            name = "Basic Beat",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    // Bass pattern generators
    private fun createBantenganBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Root note (A1 = 33) with energetic rhythm
        notes.add(MidiNote(note = 33, startTime = 0.0f, duration = 0.5f, velocity = 100))
        notes.add(MidiNote(note = 33, startTime = 1.0f, duration = 0.25f, velocity = 95))
        notes.add(MidiNote(note = 33, startTime = 1.5f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 33, startTime = 2.0f, duration = 0.5f, velocity = 100))
        notes.add(MidiNote(note = 33, startTime = 3.0f, duration = 0.25f, velocity = 95))
        notes.add(MidiNote(note = 33, startTime = 3.5f, duration = 0.25f, velocity = 90))
        
        return MidiPattern(
            name = "Bantengan Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createHeavyDropBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Heavy bass with drop effect
        notes.add(MidiNote(note = 31, startTime = 0.0f, duration = 0.5f, velocity = 110))
        notes.add(MidiNote(note = 31, startTime = 1.0f, duration = 0.5f, velocity = 100))
        
        // Drop effect
        notes.add(MidiNote(note = 31, startTime = 2.0f, duration = 0.125f, velocity = 110))
        notes.add(MidiNote(note = 29, startTime = 2.125f, duration = 0.125f, velocity = 105))
        notes.add(MidiNote(note = 27, startTime = 2.25f, duration = 0.125f, velocity = 100))
        notes.add(MidiNote(note = 26, startTime = 2.375f, duration = 0.125f, velocity = 105))
        notes.add(MidiNote(note = 24, startTime = 2.5f, duration = 0.25f, velocity = 110))
        
        return MidiPattern(
            name = "Heavy Drop Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createTrap808BassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // 808-style bass with slides
        notes.add(MidiNote(note = 36, startTime = 0.0f, duration = 0.75f, velocity = 110))
        notes.add(MidiNote(note = 36, startTime = 1.0f, duration = 0.5f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 2.0f, duration = 0.1f, velocity = 110))
        notes.add(MidiNote(note = 35, startTime = 2.1f, duration = 0.1f, velocity = 105))
        notes.add(MidiNote(note = 34, startTime = 2.2f, duration = 0.1f, velocity = 100))
        notes.add(MidiNote(note = 32, startTime = 2.3f, duration = 0.8f, velocity = 105))
        
        return MidiPattern(
            name = "Trap 808 Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createFourOnFloorBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // EDM four-on-the-floor bass
        for (i in 0 until 4) {
            notes.add(MidiNote(note = 36, startTime = i.toFloat(), duration = 0.5f, velocity = 100))
        }
        
        return MidiPattern(
            name = "Four On Floor Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createSteadyRhythmicBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Steady rhythmic pattern
        notes.add(MidiNote(note = 36, startTime = 0.0f, duration = 0.25f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 0.5f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 36, startTime = 1.0f, duration = 0.25f, velocity = 95))
        notes.add(MidiNote(note = 36, startTime = 1.5f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 36, startTime = 2.0f, duration = 0.25f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 2.5f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 36, startTime = 3.0f, duration = 0.25f, velocity = 95))
        notes.add(MidiNote(note = 36, startTime = 3.5f, duration = 0.25f, velocity = 90))
        
        return MidiPattern(
            name = "Steady Rhythmic Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createMelodicBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Melodic bass line
        val bassLine = listOf(
            Pair(36, 0.0f),   // Root
            Pair(36, 0.5f),   // Root
            Pair(40, 1.0f),   // Fifth
            Pair(38, 1.5f),   // Third
            
            Pair(36, 2.0f),   // Root
            Pair(36, 2.5f),   // Root
            Pair(41, 3.0f),   // Sixth
            Pair(43, 3.5f)    // Seventh
        )
        
        for (note in bassLine) {
            notes.add(MidiNote(
                note = note.first,
                startTime = note.second,
                duration = 0.4f,
                velocity = if (note.second.toInt() % 2 == 0) 95 else 85
            ))
        }
        
        return MidiPattern(
            name = "Melodic Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createStandardBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Standard bass pattern
        notes.add(MidiNote(note = 36, startTime = 0.0f, duration = 0.5f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 1.0f, duration = 0.5f, velocity = 90))
        notes.add(MidiNote(note = 43, startTime = 2.0f, duration = 0.5f, velocity = 95))
        notes.add(MidiNote(note = 36, startTime = 3.0f, duration = 0.5f, velocity = 90))
        
        return MidiPattern(
            name = "Standard Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    // Melody pattern generators
    private fun createPelogMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Pelog scale approximation
        val pelogScale = listOf(57, 59, 60, 64, 66, 68, 71)
        
        val melodicSequence = listOf(
            Pair(0, 0.0f),    // A
            Pair(2, 0.5f),    // C
            Pair(0, 1.0f),    // A
            Pair(3, 1.5f),    // E
            
            Pair(4, 2.0f),    // F#
            Pair(3, 2.5f),    // E
            Pair(2, 3.0f),    // C
            Pair(0, 3.5f)     // A
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = pelogScale[note.first], 
                startTime = note.second,
                duration = 0.4f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Pelog Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createSlendroMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Slendro scale approximation
        val slendroScale = listOf(55, 57, 60, 62, 64, 67, 69)
        
        val melodicSequence = listOf(
            Pair(1, 0.0f),    // A
            Pair(2, 0.5f),    // C
            Pair(4, 1.0f),    // E
            Pair(2, 1.5f),    // C
            
            Pair(1, 2.0f),    // A
            Pair(0, 2.5f),    // G
            Pair(1, 3.0f),    // A
            Pair(3, 3.5f)     // D
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = slendroScale[note.first], 
                startTime = note.second,
                duration = 0.4f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Slendro Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createArabicMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Arabic scale approximation
        val arabicScale = listOf(62, 64, 65, 68, 69, 70, 73, 74)
        
        val melodicSequence = listOf(
            Pair(0, 0.0f),    // D
            Pair(1, 0.5f),    // E
            Pair(2, 0.75f),   // F
            Pair(4, 1.0f),    // A
            Pair(3, 1.5f),    // G#
            Pair(2, 1.75f),   // F
            
            Pair(1, 2.0f),    // E
            Pair(2, 2.25f),   // F
            Pair(3, 2.5f),    // G#
            Pair(4, 2.75f),   // A
            Pair(5, 3.0f),    // Bb
            Pair(4, 3.25f),   // A
            Pair(3, 3.5f),    // G#
            Pair(1, 3.75f)    // E
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = arabicScale[note.first], 
                startTime = note.second,
                duration = 0.2f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Arabic Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createMinorMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // F minor scale
        val minorScale = listOf(65, 67, 68, 70, 72, 73, 75, 77)
        
        val melodicSequence = listOf(
            Pair(0, 0.0f),    // F
            Pair(0, 0.5f),    // F
            Pair(2, 1.0f),    // Ab
            Pair(0, 1.5f),    // F
            
            Pair(3, 2.0f),    // Bb
            Pair(2, 2.5f),    // Ab
            Pair(0, 3.0f),    // F
            Pair(4, 3.5f)     // C
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = minorScale[note.first], 
                startTime = note.second,
                duration = 0.4f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Minor Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createMajorMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // A major scale
        val majorScale = listOf(69, 71, 73, 74, 76, 78, 80, 81)
        
        val melodicSequence = listOf(
            Pair(0, 0.0f),    // A
            Pair(2, 0.5f),    // C#
            Pair(4, 1.0f),    // E
            Pair(4, 1.5f),    // E
            
            Pair(2, 2.0f),    // C#
            Pair(4, 2.5f),    // E
            Pair(5, 3.0f),    // F#
            Pair(4, 3.5f)     // E
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = majorScale[note.first], 
                startTime = note.second,
                duration = 0.4f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Major Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createDiatonicMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // C major scale
        val majorScale = listOf(60, 62, 64, 65, 67, 69, 71, 72)
        
        val melodicSequence = listOf(
            Pair(0, 0.0f),    // C
            Pair(2, 0.5f),    // E
            Pair(4, 1.0f),    // G
            Pair(2, 1.5f),    // E
            
            Pair(4, 2.0f),    // G
            Pair(5, 2.5f),    // A
            Pair(4, 3.0f),    // G
            Pair(2, 3.5f)     // E
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = majorScale[note.first], 
                startTime = note.second,
                duration = 0.4f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Diatonic Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    /**
     * Mendapatkan prompt untuk lagu genre spesifik
     */
    fun getGenreSpecificPrompt(genre: String): String {
        return when (genre.toLowerCase()) {
            "dj bantengan" -> 
                "Buatlah musik DJ Bantengan dengan irama gamelan tradisional Jawa, " +
                "menggabungkan suara tradisional seperti gong, kenong, dan penekanan pada " +
                "perkusi dan bass berat. Tambahkan suara mistis untuk memberi nuansa khas bantengan."
            
            "dj nrotok" ->
                "Buatlah musik DJ Nrotok dengan tempo cepat sekitar 160-170 BPM, " +
                "fokus pada ritme perkusi repetitif dan sample vokal yang dipotong-potong. " +
                "Tambahkan bass drop yang berat dan variasi hi-hat cepat untuk memberi energi."
            
            "koplo" ->
                "Buatlah musik Koplo dengan pola kendang yang energik dan cepat, " +
                "mantapkan tempo sekitar 145-150 BPM. Berikan ornamentasi melodi dan " +
                "suara ketipung yang menjadi ciri khas musik dangdut Koplo."
            
            "dangdut" ->
                "Buatlah musik Dangdut dengan ciri khas tabla/ketipung dan melodi ornamental. " +
                "Berikan nuansa Timur Tengah dengan tempo sekitar 120-130 BPM dan pastikan " +
                "memiliki bagian melodi yang mudah diingat."
            
            "trap" ->
                "Buatlah musik Trap dengan hi-hat triplet, 808 bass yang berat, dan ruang untuk vocal. " +
                "Berikan tempo sekitar 140 BPM dengan pola snare yang khas dan suara synth yang gelap."
            
            else -> 
                "Buatlah musik elektronik dengan karakter yang unik, penekanan pada ritme " +
                "dan melodi yang menarik. Tambahkan variasi dinamis untuk menjaga ketertarikan pendengar."
        }
    }
    
    /**
     * Mendapatkan rekomendasi sample untuk genre tertentu
     */
    fun getSampleRecommendations(genre: String): List<String> {
        return genreSpecialist.getSampleRecommendations(genre)
    }
}