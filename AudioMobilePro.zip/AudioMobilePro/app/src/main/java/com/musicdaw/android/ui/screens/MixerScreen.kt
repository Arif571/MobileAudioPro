package com.musicdaw.android.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.musicdaw.android.audio.AudioEngine
import com.musicdaw.android.model.Effect
import com.musicdaw.android.model.Project
import com.musicdaw.android.model.Track
import kotlinx.coroutines.launch

@Composable
fun MixerScreen(
    currentProject: Project?,
    audioEngine: AudioEngine
) {
    if (currentProject == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No project loaded. Please create or open a project.")
        }
        return
    }
    
    val coroutineScope = rememberCoroutineScope()
    val meterLevels = audioEngine.meterLevels.collectAsState(initial = emptyList())
    val trackLevels = meterLevels.value.take(currentProject.tracks.size)
    val masterLevel = meterLevels.value.lastOrNull() ?: 0f
    
    // Mutable state for project with effects list open
    var selectedTrackId by remember { mutableStateOf<String?>(null) }
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Top toolbar
        TopAppBar(
            title = {
                Text(
                    text = "${currentProject.name} - Mixer",
                    fontWeight = FontWeight.Bold
                )
            },
            backgroundColor = MaterialTheme.colors.primarySurface
        )
        
        // Main mixer area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            // Track channels
            LazyRow(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Track channel strips
                items(currentProject.tracks) { track ->
                    val isSelected = track.id == selectedTrackId
                    
                    MixerChannelStrip(
                        track = track,
                        meterLevel = trackLevels.getOrElse(currentProject.tracks.indexOf(track)) { 0f },
                        isSelected = isSelected,
                        onSelect = { 
                            selectedTrackId = if (isSelected) null else track.id
                        }
                    )
                }
                
                // Master channel strip
                item {
                    MasterChannelStrip(
                        project = currentProject,
                        meterLevel = masterLevel,
                        isSelected = "master" == selectedTrackId,
                        onSelect = {
                            selectedTrackId = if ("master" == selectedTrackId) null else "master"
                        }
                    )
                }
            }
            
            // Effects panel (if a track is selected)
            selectedTrackId?.let { trackId ->
                val track = if (trackId == "master") null else currentProject.tracks.find { it.id == trackId }
                
                EffectsPanel(
                    track = track,
                    masterMixerState = if (track == null) currentProject.mixerState else null
                )
            }
        }
        
        // Playback controls at the bottom
        PlaybackControls(audioEngine)
    }
}

@Composable
fun MixerChannelStrip(
    track: Track,
    meterLevel: Float,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    val trackColor = Color(track.color)
    
    Card(
        modifier = Modifier
            .width(90.dp)
            .fillMaxHeight()
            .padding(bottom = if (isSelected) 0.dp else 120.dp),
        elevation = if (isSelected) 8.dp else 2.dp,
        backgroundColor = if (isSelected) 
            MaterialTheme.colors.surface.copy(alpha = 0.9f) 
        else 
            MaterialTheme.colors.surface.copy(alpha = 0.7f),
        shape = RoundedCornerShape(
            topStart = 8.dp,
            topEnd = 8.dp,
            bottomStart = if (isSelected) 0.dp else 8.dp,
            bottomEnd = if (isSelected) 0.dp else 8.dp
        )
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(8.dp)
        ) {
            // Track name and color
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .background(trackColor, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = track.name.first().toString(),
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = track.name,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                maxLines = 2,
                modifier = Modifier.height(32.dp)
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Mute/Solo/Arm buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeOff,
                    contentDescription = "Mute",
                    tint = if (track.isMuted) Color.Red else Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
                
                Icon(
                    imageVector = Icons.Default.Headphones,
                    contentDescription = "Solo",
                    tint = if (track.isSolo) Color.Yellow else Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
                
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Record Arm",
                    tint = if (track.isArmed) Color.Red else Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Pan control
            Text(
                text = when {
                    track.pan < 0 -> "L ${(-track.pan * 100).toInt()}"
                    track.pan > 0 -> "R ${(track.pan * 100).toInt()}"
                    else -> "C"
                },
                fontSize = 12.sp
            )
            
            Slider(
                value = track.pan,
                onValueChange = { /* Update pan */ },
                valueRange = -1f..1f,
                modifier = Modifier
                    .height(80.dp)
                    .width(60.dp)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Level meter
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(1f)
                    .width(24.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.DarkGray)
                    .padding(2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .fillMaxHeight(meterLevel)
                        .background(
                            when {
                                meterLevel > 0.9f -> Color.Red
                                meterLevel > 0.7f -> Color.Yellow
                                else -> trackColor
                            }
                        )
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Volume fader
            Slider(
                value = track.volume,
                onValueChange = { /* Update volume */ },
                valueRange = 0f..1f,
                modifier = Modifier
                    .height(120.dp)
                    .width(60.dp)
            )
            
            Text(
                text = "${(track.volume * 100).toInt()}%",
                fontSize = 12.sp
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Effects/EQ button
            Button(
                onClick = onSelect,
                colors = ButtonColors(
                    backgroundColor = if (isSelected) MaterialTheme.colors.primary else Color.Gray.copy(alpha = 0.3f),
                    contentColor = Color.White,
                    disabledBackgroundColor = Color.Gray,
                    disabledContentColor = Color.DarkGray
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
            ) {
                Text(
                    text = if (isSelected) "Close" else "Effects",
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun MasterChannelStrip(
    project: Project,
    meterLevel: Float,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    val mixerState = project.mixerState
    
    Card(
        modifier = Modifier
            .width(100.dp)
            .fillMaxHeight()
            .padding(bottom = if (isSelected) 0.dp else 120.dp),
        elevation = if (isSelected) 8.dp else 4.dp,
        backgroundColor = if (isSelected) 
            MaterialTheme.colors.secondary.copy(alpha = 0.9f) 
        else 
            MaterialTheme.colors.secondary.copy(alpha = 0.7f),
        shape = RoundedCornerShape(
            topStart = 8.dp,
            topEnd = 8.dp,
            bottomStart = if (isSelected) 0.dp else 8.dp,
            bottomEnd = if (isSelected) 0.dp else 8.dp
        )
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(8.dp)
        ) {
            // Master label
            Text(
                text = "MASTER",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Master icon
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Master",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Mute button
            IconButton(
                onClick = { /* Toggle master mute */ },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeOff,
                    contentDescription = "Mute Master",
                    tint = if (mixerState.isMasterMuted) Color.Red else Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Pan control
            Text(
                text = when {
                    mixerState.masterPan < 0 -> "L ${(-mixerState.masterPan * 100).toInt()}"
                    mixerState.masterPan > 0 -> "R ${(mixerState.masterPan * 100).toInt()}"
                    else -> "C"
                },
                fontSize = 12.sp,
                color = Color.White
            )
            
            Slider(
                value = mixerState.masterPan,
                onValueChange = { /* Update master pan */ },
                valueRange = -1f..1f,
                modifier = Modifier
                    .height(80.dp)
                    .width(60.dp)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Level meter
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(1f)
                    .width(32.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.DarkGray)
                    .padding(2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .fillMaxHeight(meterLevel)
                        .background(
                            when {
                                meterLevel > 0.9f -> Color.Red
                                meterLevel > 0.7f -> Color.Yellow
                                else -> Color.Green
                            }
                        )
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Volume fader
            Slider(
                value = mixerState.masterVolume,
                onValueChange = { /* Update master volume */ },
                valueRange = 0f..1f,
                modifier = Modifier
                    .height(120.dp)
                    .width(60.dp)
            )
            
            Text(
                text = "${(mixerState.masterVolume * 100).toInt()}%",
                fontSize = 12.sp,
                color = Color.White
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Effects/EQ button
            Button(
                onClick = onSelect,
                colors = ButtonColors(
                    backgroundColor = if (isSelected) Color.White else Color.White.copy(alpha = 0.3f),
                    contentColor = MaterialTheme.colors.secondary,
                    disabledBackgroundColor = Color.Gray,
                    disabledContentColor = Color.DarkGray
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
            ) {
                Text(
                    text = if (isSelected) "Close" else "Master FX",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun EffectsPanel(
    track: Track?,
    masterMixerState: com.musicdaw.android.model.MixerState?
) {
    val effects = track?.effects ?: masterMixerState?.masterEffects ?: emptyList()
    val title = when {
        track != null -> "${track.name} Effects"
        masterMixerState != null -> "Master Effects"
        else -> "Effects"
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
            .padding(top = 16.dp)
            .align(Alignment.BottomCenter),
        elevation = 8.dp,
        backgroundColor = MaterialTheme.colors.surface.copy(alpha = 0.95f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Panel header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                
                // Add effect button
                IconButton(onClick = { /* Add new effect */ }) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Effect"
                    )
                }
            }
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            // Effects list
            if (effects.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No effects. Click + to add an effect.",
                        color = Color.Gray
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                ) {
                    effects.forEach { effect ->
                        EffectItem(effect)
                    }
                }
            }
        }
    }
}

@Composable
fun EffectItem(effect: Effect) {
    var expanded by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        elevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(8.dp)
        ) {
            // Effect header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Effect type and name
                Column {
                    Text(
                        text = effect.name,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Text(
                        text = effect.type.capitalize(),
                        fontSize = 12.sp,
                        color = MaterialTheme.colors.primary
                    )
                }
                
                // Effect controls
                Row {
                    // Bypass button
                    IconButton(
                        onClick = { /* Toggle bypass */ },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = "Bypass",
                            tint = if (effect.isBypassed) Color.Red else Color.Green,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    
                    // Expand/collapse button
                    IconButton(
                        onClick = { expanded = !expanded },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = if (expanded) "Collapse" else "Expand",
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
            
            // Effect parameters (when expanded)
            if (expanded) {
                Divider(modifier = Modifier.padding(vertical = 4.dp))
                
                Column(
                    modifier = Modifier.padding(8.dp)
                ) {
                    effect.settings.forEach { (paramName, value) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = paramName.replace("_", " ").capitalize(),
                                fontSize = 14.sp,
                                modifier = Modifier.width(100.dp)
                            )
                            
                            Slider(
                                value = value,
                                onValueChange = { /* Update parameter */ },
                                valueRange = 0f..1f,
                                modifier = Modifier.weight(1f)
                            )
                            
                            Text(
                                text = "${(value * 100).toInt()}%",
                                fontSize = 12.sp,
                                modifier = Modifier.width(40.dp),
                                textAlign = TextAlign.End
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaybackControls(audioEngine: AudioEngine) {
    val playbackState = audioEngine.playbackState.collectAsState(initial = AudioEngine.PlaybackState.STOPPED)
    val isPlaying = playbackState.value == AudioEngine.PlaybackState.PLAYING
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(MaterialTheme.colors.primary)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        // Rewind
        IconButton(onClick = { audioEngine.seekTo(0f) }) {
            Icon(
                imageVector = Icons.Default.SkipPrevious,
                contentDescription = "Rewind",
                tint = Color.White
            )
        }
        
        // Play/Pause
        IconButton(
            onClick = {
                if (isPlaying) {
                    audioEngine.pausePlayback()
                } else {
                    audioEngine.startPlayback()
                }
            },
            modifier = Modifier
                .size(48.dp)
                .padding(8.dp)
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = Color.White,
                modifier = Modifier.size(32.dp)
            )
        }
        
        // Stop
        IconButton(onClick = { audioEngine.stopPlayback() }) {
            Icon(
                imageVector = Icons.Default.Stop,
                contentDescription = "Stop",
                tint = Color.White
            )
        }
    }
}

// String extension function
private fun String.capitalize(): String {
    return this.replaceFirstChar { 
        if (it.isLowerCase()) it.titlecase() else it.toString() 
    }
}