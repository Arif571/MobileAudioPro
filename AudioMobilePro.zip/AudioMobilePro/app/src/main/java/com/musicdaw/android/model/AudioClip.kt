package com.musicdaw.android.model

import java.util.*

/**
 * Represents an audio clip in an audio track
 */
data class AudioClip(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val filePath: String,
    val startTime: Float, // Position in the track (seconds)
    val duration: Float, // Duration of the clip (seconds)
    val offset: Float = 0f, // Offset into the source file (seconds)
    val gain: Float = 1.0f, // Volume multiplier
    val fadeInDuration: Float = 0f,
    val fadeOutDuration: Float = 0f,
    val isLooping: Boolean = false,
    val loopCount: Int = 1, // -1 for infinite
    val waveformData: List<Float> = emptyList(),
    val color: Int? = null, // Optional override of track color
    val isReversed: Boolean = false,
    val timeStretch: Float = 1.0f, // 1.0 = normal speed
    val pitchShift: Int = 0, // Semitones, 0 = normal pitch
    val take: Int = 1, // For multiple takes of the same recording
    val isComped: Boolean = false, // If this clip is part of a comp
    val isSelected: Boolean = false
) {
    /**
     * Calculate the end time of this clip in the track
     */
    fun endTime(): Float {
        return startTime + duration
    }
    
    /**
     * Creates a copy of this clip with adjusted start time
     */
    fun withStartTime(newStartTime: Float): AudioClip {
        return this.copy(startTime = newStartTime)
    }
    
    /**
     * Creates a copy of this clip with adjusted gain
     */
    fun withGain(newGain: Float): AudioClip {
        return this.copy(gain = newGain.coerceIn(0f, 2f))
    }
    
    /**
     * Creates a copy of this clip with adjusted fade-in duration
     */
    fun withFadeIn(duration: Float): AudioClip {
        return this.copy(fadeInDuration = duration.coerceAtLeast(0f))
    }
    
    /**
     * Creates a copy of this clip with adjusted fade-out duration
     */
    fun withFadeOut(duration: Float): AudioClip {
        return this.copy(fadeOutDuration = duration.coerceAtLeast(0f))
    }
    
    /**
     * Toggles the looping state of this clip
     */
    fun toggleLooping(): AudioClip {
        return this.copy(isLooping = !isLooping)
    }
    
    /**
     * Creates a copy of this clip with adjusted loop count
     */
    fun withLoopCount(count: Int): AudioClip {
        return this.copy(loopCount = count)
    }
    
    /**
     * Creates a copy of this clip with time stretching applied
     */
    fun withTimeStretch(factor: Float): AudioClip {
        if (factor <= 0f) return this
        return this.copy(timeStretch = factor)
    }
    
    /**
     * Creates a copy of this clip with pitch shifting applied
     */
    fun withPitchShift(semitones: Int): AudioClip {
        return this.copy(pitchShift = semitones)
    }
    
    /**
     * Toggles the reversed state of this clip
     */
    fun toggleReversed(): AudioClip {
        return this.copy(isReversed = !isReversed)
    }
    
    /**
     * Toggles the selected state of this clip
     */
    fun toggleSelected(): AudioClip {
        return this.copy(isSelected = !isSelected)
    }
    
    companion object {
        /**
         * Creates an audio clip from a file
         */
        fun fromFile(
            name: String,
            filePath: String,
            startTime: Float,
            duration: Float
        ): AudioClip {
            return AudioClip(
                name = name,
                filePath = filePath,
                startTime = startTime,
                duration = duration
            )
        }
        
        /**
         * Creates an audio clip from a recording
         */
        fun fromRecording(
            name: String,
            filePath: String,
            startTime: Float,
            duration: Float,
            take: Int
        ): AudioClip {
            return AudioClip(
                name = name,
                filePath = filePath,
                startTime = startTime,
                duration = duration,
                take = take
            )
        }
    }
}