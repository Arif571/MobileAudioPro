package com.musicdaw.android

import android.app.Application
import android.content.Context
import com.musicdaw.android.audio.AudioEngine
import com.musicdaw.android.repository.EffectsRepository
import com.musicdaw.android.repository.ProjectRepository
import com.musicdaw.android.repository.SamplesRepository
import com.musicdaw.android.repository.SettingsRepository

class MusicDAWApplication : Application() {
    
    // Repositories
    lateinit var projectRepository: ProjectRepository
        private set
    
    lateinit var samplesRepository: SamplesRepository
        private set
    
    lateinit var effectsRepository: EffectsRepository
        private set
    
    lateinit var settingsRepository: SettingsRepository
        private set
    
    // Audio Engine
    lateinit var audioEngine: AudioEngine
        private set
    
    override fun onCreate() {
        super.onCreate()
        instance = this
        
        // Initialize repositories
        projectRepository = ProjectRepository(this)
        samplesRepository = SamplesRepository(this)
        effectsRepository = EffectsRepository(this)
        settingsRepository = SettingsRepository(this)
        
        // Initialize audio engine
        audioEngine = AudioEngine(this)
    }
    
    companion object {
        lateinit var instance: MusicDAWApplication
            private set
        
        fun getAppContext(): Context = instance.applicationContext
    }
}
