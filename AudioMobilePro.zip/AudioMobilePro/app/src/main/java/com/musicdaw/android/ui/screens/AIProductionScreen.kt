package com.musicdaw.android.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.musicdaw.android.ai.AIProductionController.ProductionStatus
import com.musicdaw.android.model.Project
import com.musicdaw.android.viewmodel.AIProductionViewModel
import kotlinx.coroutines.launch

/**
 * Layar untuk produksi musik menggunakan AI
 */
@Composable
fun AIProductionScreen(
    currentProject: Project?,
    onProjectCreated: (Project) -> Unit,
    onNavigateBack: () -> Unit
) {
    // ViewModel untuk mengontrol produksi AI
    val viewModel: AIProductionViewModel = viewModel()
    
    // State untuk UI
    val uiState = viewModel.uiState.collectAsState().value
    val coroutineScope = rememberCoroutineScope()
    var showGenreDialog by remember { mutableStateOf(false) }
    var selectedReferenceFile by remember { mutableStateOf<String?>(null) }
    var projectName by remember { mutableStateOf("") }
    
    val referenceFiles = remember { viewModel.getAvailableReferenceFiles() }
    
    // Efek untuk menginisialisasi nama proyek default bila diperlukan
    LaunchedEffect(key1 = currentProject) {
        if (projectName.isEmpty()) {
            projectName = "AI Project ${System.currentTimeMillis() / 1000}"
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Top bar
        TopAppBar(
            title = {
                Text("Produksi Musik AI")
            },
            navigationIcon = {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Kembali"
                    )
                }
            },
            backgroundColor = MaterialTheme.colors.primarySurface
        )
        
        // Main content
        when (uiState) {
            is AIProductionViewModel.UIState.Initial -> {
                // Tampilan awal untuk memilih metode produksi
                InitialView(
                    onReferenceSelected = { file ->
                        selectedReferenceFile = file
                        showGenreDialog = true
                    },
                    onProjectNameChanged = { projectName = it },
                    projectName = projectName,
                    referenceFiles = referenceFiles
                )
            }
            
            is AIProductionViewModel.UIState.Processing -> {
                // Tampilan sedang memproses
                ProcessingView(
                    status = uiState.productionResult.status,
                    progress = uiState.productionResult.progressPercent,
                    statusMessage = uiState.productionResult.statusMessage
                )
            }
            
            is AIProductionViewModel.UIState.Completed -> {
                // Tampilan hasil produksi berhasil
                CompletedView(
                    project = uiState.productionResult.project!!,
                    genre = uiState.productionResult.detectedGenre,
                    onUseProject = {
                        onProjectCreated(uiState.productionResult.project)
                        onNavigateBack()
                    }
                )
            }
            
            is AIProductionViewModel.UIState.Error -> {
                // Tampilan kesalahan
                ErrorView(
                    errorMessage = uiState.errorMessage,
                    onRetry = {
                        viewModel.resetState()
                    }
                )
            }
        }
    }
    
    // Dialog untuk memilih genre
    if (showGenreDialog && selectedReferenceFile != null) {
        GenreSelectionDialog(
            onDismiss = { showGenreDialog = false },
            onGenreSelected = { genre ->
                showGenreDialog = false
                
                // Mulai produksi dengan file referensi dan genre yang dipilih
                coroutineScope.launch {
                    viewModel.processReferenceAudio(
                        referenceAudioPath = selectedReferenceFile!!,
                        targetGenre = genre,
                        projectName = projectName
                    )
                }
            }
        )
    }
}

/**
 * Tampilan awal untuk mengatur produksi musik AI
 */
@Composable
fun InitialView(
    onReferenceSelected: (String) -> Unit,
    onProjectNameChanged: (String) -> Unit,
    projectName: String,
    referenceFiles: List<String>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "Buat Musik dengan AI",
                style = MaterialTheme.typography.h5,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            // Kolom input nama proyek
            OutlinedTextField(
                value = projectName,
                onValueChange = onProjectNameChanged,
                label = { Text("Nama Proyek") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            )
            
            Text(
                text = "Pilih Lagu Referensi",
                style = MaterialTheme.typography.h6,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 16.dp)
            )
            
            Text(
                text = "AI akan menganalisis lagu referensi, mengekstrak sampel, dan membuat musik baru dengan gaya serupa",
                style = MaterialTheme.typography.body1,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }
        
        // List file referensi
        if (referenceFiles.isEmpty()) {
            item {
                EmptyReferenceView()
            }
        } else {
            items(referenceFiles) { file ->
                ReferenceFileCard(
                    fileName = file,
                    onClick = { onReferenceSelected(file) }
                )
            }
        }
        
        // Import button
        item {
            Spacer(modifier = Modifier.height(16.dp))
            
            OutlinedButton(
                onClick = { /* TODO: Import file */ },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Import"
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Import Lagu Referensi")
            }
        }
    }
}

/**
 * Tampilan ketika tidak ada file referensi
 */
@Composable
fun EmptyReferenceView() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.MusicNote,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = Color.Gray
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Belum ada file audio referensi",
            style = MaterialTheme.typography.h6,
            color = Color.Gray
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "Import lagu untuk dijadikan referensi pembuatan musik",
            style = MaterialTheme.typography.body1,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Card untuk menampilkan file referensi
 */
@Composable
fun ReferenceFileCard(
    fileName: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable(onClick = onClick),
        elevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = null,
                tint = MaterialTheme.colors.primary
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = fileName,
                    style = MaterialTheme.typography.body1,
                    fontWeight = FontWeight.Bold
                )
                
                Text(
                    text = "Audio File",
                    style = MaterialTheme.typography.caption,
                    color = Color.Gray
                )
            }
            
            IconButton(onClick = onClick) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Use Reference",
                    tint = MaterialTheme.colors.primary
                )
            }
        }
    }
}

/**
 * Dialog untuk memilih genre target
 */
@Composable
fun GenreSelectionDialog(
    onDismiss: () -> Unit,
    onGenreSelected: (String) -> Unit
) {
    // List genre yang tersedia
    val genres = listOf(
        "DJ Bantengan",
        "DJ Nrotok",
        "Koplo",
        "Dangdut",
        "Trap",
        "EDM",
        "House",
        "Hip-Hop",
        "Dubstep",
        "Detect Automatically"
    )
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Pilih Genre Target")
        },
        text = {
            LazyColumn {
                items(genres) { genre ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onGenreSelected(if (genre == "Detect Automatically") null else genre) }
                            .padding(vertical = 12.dp, horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (genre.contains("DJ", ignoreCase = true) || 
                            genre.contains("Koplo", ignoreCase = true) || 
                            genre.contains("Dangdut", ignoreCase = true)) {
                            // Highlight genre lokal Indonesia
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = Color(0xFFFF5722),
                                modifier = Modifier.size(20.dp)
                            )
                        } else {
                            Spacer(modifier = Modifier.width(20.dp))
                        }
                        
                        Spacer(modifier = Modifier.width(16.dp))
                        
                        Text(
                            text = genre,
                            style = MaterialTheme.typography.body1,
                            fontWeight = if (genre.contains("DJ", ignoreCase = true) || 
                                            genre.contains("Koplo", ignoreCase = true) || 
                                            genre.contains("Dangdut", ignoreCase = true))
                                        FontWeight.Bold else FontWeight.Normal,
                            color = if (genre.contains("DJ", ignoreCase = true) || 
                                      genre.contains("Koplo", ignoreCase = true) || 
                                      genre.contains("Dangdut", ignoreCase = true))
                                    Color(0xFFFF5722) else MaterialTheme.colors.onSurface
                        )
                    }
                }
            }
        },
        confirmButton = { },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

/**
 * Tampilan selama pemrosesan
 */
@Composable
fun ProcessingView(
    status: ProductionStatus,
    progress: Int,
    statusMessage: String
) {
    Column(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Status icon
        val icon = when (status) {
            ProductionStatus.ANALYZING -> Icons.Default.Search
            ProductionStatus.EXTRACTING_SAMPLES -> Icons.Default.AudiotrackOutlined
            ProductionStatus.GENERATING_PATTERNS -> Icons.Default.MusicNote
            ProductionStatus.MIXING -> Icons.Default.Equalizer
            ProductionStatus.MASTERING -> Icons.Default.GraphicEq
            else -> Icons.Default.BuildCircle
        }
        
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = MaterialTheme.colors.primary
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = formatStatusText(status),
            style = MaterialTheme.typography.h5,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = statusMessage,
            style = MaterialTheme.typography.body1,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp)
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Progress indicator
        LinearProgressIndicator(
            progress = progress / 100f,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "$progress%",
            style = MaterialTheme.typography.body2
        )
    }
}

/**
 * Format text status berdasarkan ProductionStatus
 */
private fun formatStatusText(status: ProductionStatus): String {
    return when (status) {
        ProductionStatus.ANALYZING -> "Menganalisis Audio"
        ProductionStatus.EXTRACTING_SAMPLES -> "Mengekstrak Sampel"
        ProductionStatus.GENERATING_PATTERNS -> "Membuat Pola Musik"
        ProductionStatus.MIXING -> "Proses Mixing"
        ProductionStatus.MASTERING -> "Proses Mastering"
        ProductionStatus.COMPLETED -> "Selesai"
        ProductionStatus.ERROR -> "Error"
    }
}

/**
 * Tampilan ketika produksi selesai
 */
@Composable
fun CompletedView(
    project: Project,
    genre: String,
    onUseProject: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = Color(0xFF4CAF50) // Green
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Produksi Selesai!",
            style = MaterialTheme.typography.h5,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "Berhasil menciptakan musik '${project.name}' dengan genre $genre",
            style = MaterialTheme.typography.body1,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp)
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // Info proyek
        Card(
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .padding(vertical = 16.dp),
            elevation = 4.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                InfoRow(label = "Nama", value = project.name)
                InfoRow(label = "Tempo", value = "${project.tempo.toInt()} BPM")
                InfoRow(label = "Kunci", value = project.key ?: "C Major")
                InfoRow(label = "Track", value = "${project.tracks.size}")
                InfoRow(label = "Genre", value = genre)
                InfoRow(label = "Durasi", value = formatDuration(project.duration))
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(
            onClick = onUseProject,
            modifier = Modifier.fillMaxWidth(0.8f)
        ) {
            Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = null
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Gunakan Proyek Ini")
        }
    }
}

/**
 * Tampilan ketika terjadi error
 */
@Composable
fun ErrorView(
    errorMessage: String,
    onRetry: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Error,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = Color(0xFFF44336) // Red
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Terjadi Kesalahan",
            style = MaterialTheme.typography.h5,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = errorMessage,
            style = MaterialTheme.typography.body1,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp)
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(
            onClick = onRetry,
            modifier = Modifier.fillMaxWidth(0.5f)
        ) {
            Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = null
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Coba Lagi")
        }
    }
}

/**
 * Baris informasi dengan label dan nilai
 */
@Composable
fun InfoRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.body1,
            fontWeight = FontWeight.Bold
        )
        
        Text(
            text = value,
            style = MaterialTheme.typography.body1
        )
    }
}

/**
 * Format durasi dalam detik menjadi format menit:detik
 */
private fun formatDuration(durationInSeconds: Float): String {
    val minutes = (durationInSeconds / 60).toInt()
    val seconds = (durationInSeconds % 60).toInt()
    return String.format("%d:%02d", minutes, seconds)
}