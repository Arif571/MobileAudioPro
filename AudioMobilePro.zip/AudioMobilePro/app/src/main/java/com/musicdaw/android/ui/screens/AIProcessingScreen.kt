package com.musicdaw.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.musicdaw.android.model.AITask
import com.musicdaw.android.model.AITaskStatus
import com.musicdaw.android.model.AITaskType
import com.musicdaw.android.model.Project
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.*

@Composable
fun AIProcessingScreen(
    currentProject: Project?
) {
    if (currentProject == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No project loaded. Please create or open a project.")
        }
        return
    }
    
    // Mock AI tasks for demonstration
    val mockTasks = remember {
        mutableStateListOf(
            AITask(
                name = "Vocal Extraction",
                description = "Extract vocals from 'Lead Vocal' track",
                type = AITaskType.VOCAL_SEPARATION,
                status = AITaskStatus.COMPLETED,
                progress = 1.0f,
                createdDate = Date(System.currentTimeMillis() - 3600000), // 1 hour ago
                completedDate = Date(System.currentTimeMillis() - 3540000) // 59 minutes ago
            ),
            AITask(
                name = "Auto-Mixing Session",
                description = "Apply AI-powered mixing to entire project",
                type = AITaskType.AUTO_MIXING,
                status = AITaskStatus.IN_PROGRESS,
                progress = 0.7f,
                createdDate = Date()
            )
        )
    }
    
    var selectedTaskType by remember { mutableStateOf<AITaskType?>(null) }
    var showNewTaskDialog by remember { mutableStateOf(false) }
    
    val coroutineScope = rememberCoroutineScope()
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Top toolbar
        TopAppBar(
            title = {
                Text(
                    text = "AI Assistant",
                    fontWeight = FontWeight.Bold
                )
            },
            backgroundColor = MaterialTheme.colors.primarySurface,
            actions = {
                // Add new AI task button
                IconButton(onClick = { showNewTaskDialog = true }) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New AI Task"
                    )
                }
            }
        )
        
        // AI Features explanation
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            elevation = 4.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "AI-Powered Music Production",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Enhance your music with cloud-based artificial intelligence. " +
                           "Select from the following features to automatically process your audio.",
                    fontSize = 14.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // AI feature quick-access buttons
                AIFeatureButtons(
                    onFeatureSelected = { taskType ->
                        selectedTaskType = taskType
                        showNewTaskDialog = true
                    }
                )
            }
        }
        
        // Current and past AI tasks
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            elevation = 4.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "AI Processing Tasks",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                if (mockTasks.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No tasks yet. Create a new AI task to get started.",
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f)
                    ) {
                        items(mockTasks) { task ->
                            AITaskItem(
                                task = task,
                                onCancelTask = { 
                                    mockTasks.remove(task) 
                                },
                                onRemoveTask = { 
                                    mockTasks.remove(task) 
                                }
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }
            }
        }
    }
    
    // New AI task dialog
    if (showNewTaskDialog) {
        NewAITaskDialog(
            initialTaskType = selectedTaskType,
            onDismiss = { 
                showNewTaskDialog = false
                selectedTaskType = null
            },
            onCreateTask = { taskName, taskType, description ->
                // Add new task to the list
                val newTask = AITask(
                    name = taskName,
                    description = description,
                    type = taskType,
                    status = AITaskStatus.QUEUED,
                    progress = 0f,
                    createdDate = Date()
                )
                
                mockTasks.add(0, newTask)
                showNewTaskDialog = false
                selectedTaskType = null
                
                // Simulate task execution
                coroutineScope.launch {
                    delay(1000) // Wait a second
                    val index = mockTasks.indexOf(newTask)
                    if (index >= 0) {
                        mockTasks[index] = newTask.copy(status = AITaskStatus.IN_PROGRESS)
                        
                        // Simulate progress
                        for (i in 1..10) {
                            delay(500)
                            val currentIndex = mockTasks.indexOf(mockTasks[index])
                            if (currentIndex >= 0) {
                                mockTasks[currentIndex] = mockTasks[currentIndex].copy(
                                    progress = i / 10f
                                )
                            }
                        }
                        
                        // Mark as completed
                        val finalIndex = mockTasks.indexOf(mockTasks[index])
                        if (finalIndex >= 0) {
                            mockTasks[finalIndex] = mockTasks[finalIndex].copy(
                                status = AITaskStatus.COMPLETED,
                                progress = 1f,
                                completedDate = Date()
                            )
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun AIFeatureButtons(
    onFeatureSelected: (AITaskType) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            AIFeatureButton(
                icon = Icons.Default.Audiotrack,
                title = "Song Decomposition",
                taskType = AITaskType.SONG_DECOMPOSITION,
                color = Color(0xFF3F51B5),
                onSelected = onFeatureSelected
            )
            
            AIFeatureButton(
                icon = Icons.Default.MusicNote,
                title = "Sample Extraction",
                taskType = AITaskType.SAMPLE_EXTRACTION,
                color = Color(0xFF9C27B0),
                onSelected = onFeatureSelected
            )
            
            AIFeatureButton(
                icon = Icons.Default.Settings,
                title = "Auto-Mixing",
                taskType = AITaskType.AUTO_MIXING,
                color = Color(0xFFF44336),
                onSelected = onFeatureSelected
            )
        }
        
        Spacer(modifier = Modifier.height(12.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            AIFeatureButton(
                icon = Icons.Default.Star,
                title = "Mastering",
                taskType = AITaskType.AUTO_MASTERING,
                color = Color(0xFF4CAF50),
                onSelected = onFeatureSelected
            )
            
            AIFeatureButton(
                icon = Icons.Default.Mic,
                title = "Vocal Separation",
                taskType = AITaskType.VOCAL_SEPARATION,
                color = Color(0xFF2196F3),
                onSelected = onFeatureSelected
            )
            
            AIFeatureButton(
                icon = Icons.Default.Person,
                title = "Voice Cloning",
                taskType = AITaskType.VOICE_CLONING,
                color = Color(0xFFFF9800),
                onSelected = onFeatureSelected
            )
        }
    }
}

@Composable
fun AIFeatureButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    taskType: AITaskType,
    color: Color,
    onSelected: (AITaskType) -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(100.dp)
            .clickable { onSelected(taskType) }
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(color.copy(alpha = 0.8f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color.White,
                modifier = Modifier.size(28.dp)
            )
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        Text(
            text = title,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            modifier = Modifier.height(32.dp)
        )
    }
}

@Composable
fun AITaskItem(
    task: AITask,
    onCancelTask: () -> Unit,
    onRemoveTask: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            // Task header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Task name and type
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = task.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    
                    Text(
                        text = task.type.displayName,
                        color = MaterialTheme.colors.primary,
                        fontSize = 12.sp
                    )
                }
                
                // Status indicator and action button
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val statusColor = when (task.status) {
                        AITaskStatus.QUEUED -> Color.Gray
                        AITaskStatus.IN_PROGRESS -> Color.Blue
                        AITaskStatus.COMPLETED -> Color.Green
                        AITaskStatus.FAILED -> Color.Red
                        AITaskStatus.CANCELLED -> Color.Gray
                    }
                    
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(statusColor, RoundedCornerShape(6.dp))
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    if (task.status == AITaskStatus.IN_PROGRESS || task.status == AITaskStatus.QUEUED) {
                        IconButton(
                            onClick = onCancelTask,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Cancel",
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    } else {
                        IconButton(
                            onClick = onRemoveTask,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Remove",
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
            
            // Task description
            Text(
                text = task.description,
                fontSize = 14.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            
            // Progress indicator for in-progress tasks
            if (task.status == AITaskStatus.IN_PROGRESS) {
                Spacer(modifier = Modifier.height(8.dp))
                
                Column {
                    Text(
                        text = "${(task.progress * 100).toInt()}%",
                        fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.End)
                    )
                    
                    LinearProgressIndicator(
                        progress = task.progress,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            
            // Status and timestamp
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = task.status.displayName,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                
                Text(
                    text = when (task.status) {
                        AITaskStatus.COMPLETED -> "Completed ${formatTimestamp(task.completedDate)}"
                        else -> "Created ${formatTimestamp(task.createdDate)}"
                    },
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
fun NewAITaskDialog(
    initialTaskType: AITaskType?,
    onDismiss: () -> Unit,
    onCreateTask: (String, AITaskType, String) -> Unit
) {
    var taskName by remember { mutableStateOf("") }
    var taskDescription by remember { mutableStateOf("") }
    var selectedTaskType by remember { mutableStateOf(initialTaskType ?: AITaskType.SONG_DECOMPOSITION) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("New AI Task")
        },
        text = {
            Column {
                // Task name
                TextField(
                    value = taskName,
                    onValueChange = { taskName = it },
                    label = { Text("Task Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Task type
                Text(
                    text = "Task Type",
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Task type selection
                Column {
                    AITaskType.values().forEach { taskType ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedTaskType = taskType }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedTaskType == taskType,
                                onClick = { selectedTaskType = taskType }
                            )
                            
                            Spacer(modifier = Modifier.width(8.dp))
                            
                            Text(text = taskType.displayName)
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Task description
                TextField(
                    value = taskDescription,
                    onValueChange = { taskDescription = it },
                    label = { Text("Description (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (taskName.isNotBlank()) {
                        onCreateTask(
                            taskName,
                            selectedTaskType,
                            if (taskDescription.isBlank()) "Apply $selectedTaskType to current project" else taskDescription
                        )
                    }
                },
                enabled = taskName.isNotBlank()
            ) {
                Text("Create Task")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// Helper function to format timestamps
private fun formatTimestamp(date: Date?): String {
    if (date == null) return ""
    
    val now = Date()
    val diffMillis = now.time - date.time
    val diffMinutes = diffMillis / (60 * 1000)
    
    return when {
        diffMinutes < 1 -> "just now"
        diffMinutes < 60 -> "$diffMinutes min ago"
        diffMinutes < 24 * 60 -> "${diffMinutes / 60} hr ago"
        else -> "${diffMinutes / (24 * 60)} days ago"
    }
}