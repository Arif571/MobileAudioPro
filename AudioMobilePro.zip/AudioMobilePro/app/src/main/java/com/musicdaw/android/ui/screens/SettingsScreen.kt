package com.musicdaw.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.musicdaw.android.model.AppSettings
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    // Mock settings for demonstration
    var settings by remember {
        mutableStateOf(
            AppSettings(
                audioBufferSize = 1024,
                sampleRate = 44100,
                bitDepth = 16,
                maxPolyphony = 64,
                autosaveIntervalMinutes = 5,
                theme = "Dark",
                language = "English",
                audioInputDevice = "Default",
                audioOutputDevice = "Default",
                midiInputDevice = "Default",
                showWelcomeOnStartup = true,
                cloudSyncEnabled = true,
                showTips = true,
                showMetronomeByDefault = true,
                defaultTempo = 120f,
                defaultTimeSignatureNumerator = 4,
                defaultTimeSignatureDenominator = 4,
                saveProjectsToCloud = true,
                enableAnalytics = true,
                enableCrashReporting = true,
                cacheSize = 1024,
                maxUndoLevels = 100,
                backupIntervalMinutes = 30,
                numberOfBackupsToKeep = 5
            )
        )
    }
    
    var showThemeDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showBufferSizeDialog by remember { mutableStateOf(false) }
    var showSampleRateDialog by remember { mutableStateOf(false) }
    var showBitDepthDialog by remember { mutableStateOf(false) }
    var showBackupIntervalDialog by remember { mutableStateOf(false) }
    var showMaxUndoLevelsDialog by remember { mutableStateOf(false) }
    var showResetSettingsConfirmation by remember { mutableStateOf(false) }
    
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Top app bar
        TopAppBar(
            title = {
                Text(
                    text = "Settings",
                    fontWeight = FontWeight.Bold
                )
            },
            backgroundColor = MaterialTheme.colors.primarySurface
        )
        
        // Settings content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // User settings
            SettingsCategory(title = "User Settings")
            
            SettingsItem(
                title = "Theme",
                subtitle = settings.theme,
                icon = Icons.Default.Palette,
                onClick = { showThemeDialog = true }
            )
            
            SettingsItem(
                title = "Language",
                subtitle = settings.language,
                icon = Icons.Default.Language,
                onClick = { showLanguageDialog = true }
            )
            
            SwitchSettingItem(
                title = "Show Welcome Screen on Startup",
                isChecked = settings.showWelcomeOnStartup,
                icon = Icons.Default.Home,
                onCheckedChange = {
                    settings = settings.copy(showWelcomeOnStartup = it)
                }
            )
            
            SwitchSettingItem(
                title = "Show Tips",
                isChecked = settings.showTips,
                icon = Icons.Default.Lightbulb,
                onCheckedChange = {
                    settings = settings.copy(showTips = it)
                }
            )
            
            Divider(modifier = Modifier.padding(vertical = 16.dp))
            
            // Audio settings
            SettingsCategory(title = "Audio Settings")
            
            SettingsItem(
                title = "Buffer Size",
                subtitle = "${settings.audioBufferSize} samples",
                icon = Icons.Default.Memory,
                onClick = { showBufferSizeDialog = true }
            )
            
            SettingsItem(
                title = "Sample Rate",
                subtitle = "${settings.sampleRate} Hz",
                icon = Icons.Default.GraphicEq,
                onClick = { showSampleRateDialog = true }
            )
            
            SettingsItem(
                title = "Bit Depth",
                subtitle = "${settings.bitDepth} bit",
                icon = Icons.Default.HighQuality,
                onClick = { showBitDepthDialog = true }
            )
            
            SettingsItem(
                title = "Audio Input Device",
                subtitle = settings.audioInputDevice,
                icon = Icons.Default.Mic,
                onClick = { /* Show device selection */ }
            )
            
            SettingsItem(
                title = "Audio Output Device",
                subtitle = settings.audioOutputDevice,
                icon = Icons.Default.Speaker,
                onClick = { /* Show device selection */ }
            )
            
            SettingsItem(
                title = "MIDI Input Device",
                subtitle = settings.midiInputDevice,
                icon = Icons.Default.MusicNote,
                onClick = { /* Show device selection */ }
            )
            
            SliderSettingItem(
                title = "Max Polyphony",
                subtitle = "${settings.maxPolyphony} voices",
                icon = Icons.Default.Layers,
                value = settings.maxPolyphony.toFloat(),
                valueRange = 16f..128f,
                steps = 112,
                onValueChange = {
                    settings = settings.copy(maxPolyphony = it.toInt())
                }
            )
            
            SwitchSettingItem(
                title = "Show Metronome by Default",
                isChecked = settings.showMetronomeByDefault,
                icon = Icons.Default.Timer,
                onCheckedChange = {
                    settings = settings.copy(showMetronomeByDefault = it)
                }
            )
            
            SliderSettingItem(
                title = "Default Tempo",
                subtitle = "${settings.defaultTempo.toInt()} BPM",
                icon = Icons.Default.Speed,
                value = settings.defaultTempo,
                valueRange = 40f..240f,
                steps = 199,
                onValueChange = {
                    settings = settings.copy(defaultTempo = it)
                }
            )
            
            Divider(modifier = Modifier.padding(vertical = 16.dp))
            
            // Cloud settings
            SettingsCategory(title = "Cloud & Storage")
            
            SwitchSettingItem(
                title = "Cloud Sync",
                isChecked = settings.cloudSyncEnabled,
                icon = Icons.Default.Cloud,
                onCheckedChange = {
                    settings = settings.copy(cloudSyncEnabled = it)
                }
            )
            
            SwitchSettingItem(
                title = "Save Projects to Cloud",
                isChecked = settings.saveProjectsToCloud,
                icon = Icons.Default.CloudUpload,
                onCheckedChange = {
                    settings = settings.copy(saveProjectsToCloud = it)
                },
                enabled = settings.cloudSyncEnabled
            )
            
            SliderSettingItem(
                title = "Autosave Interval",
                subtitle = "${settings.autosaveIntervalMinutes} minutes",
                icon = Icons.Default.Save,
                value = settings.autosaveIntervalMinutes.toFloat(),
                valueRange = 1f..30f,
                steps = 29,
                onValueChange = {
                    settings = settings.copy(autosaveIntervalMinutes = it.toInt())
                }
            )
            
            SettingsItem(
                title = "Backup Interval",
                subtitle = "${settings.backupIntervalMinutes} minutes",
                icon = Icons.Default.Backup,
                onClick = { showBackupIntervalDialog = true }
            )
            
            SettingsItem(
                title = "Number of Backups to Keep",
                subtitle = "${settings.numberOfBackupsToKeep}",
                icon = Icons.Default.Archive,
                onClick = { /* Show dialog */ }
            )
            
            SettingsItem(
                title = "Max Undo Levels",
                subtitle = "${settings.maxUndoLevels}",
                icon = Icons.Default.Undo,
                onClick = { showMaxUndoLevelsDialog = true }
            )
            
            SliderSettingItem(
                title = "Cache Size",
                subtitle = "${settings.cacheSize} MB",
                icon = Icons.Default.Storage,
                value = settings.cacheSize.toFloat(),
                valueRange = 256f..4096f,
                steps = 15,
                onValueChange = {
                    settings = settings.copy(cacheSize = it.toInt())
                }
            )
            
            Divider(modifier = Modifier.padding(vertical = 16.dp))
            
            // Privacy & Data
            SettingsCategory(title = "Privacy & Data")
            
            SwitchSettingItem(
                title = "Enable Analytics",
                isChecked = settings.enableAnalytics,
                icon = Icons.Default.Insights,
                onCheckedChange = {
                    settings = settings.copy(enableAnalytics = it)
                }
            )
            
            SwitchSettingItem(
                title = "Enable Crash Reporting",
                isChecked = settings.enableCrashReporting,
                icon = Icons.Default.BugReport,
                onCheckedChange = {
                    settings = settings.copy(enableCrashReporting = it)
                }
            )
            
            Divider(modifier = Modifier.padding(vertical = 16.dp))
            
            // Action buttons
            SettingsCategory(title = "Advanced")
            
            ActionSettingItem(
                title = "Reset All Settings",
                icon = Icons.Default.Restore,
                onClick = { showResetSettingsConfirmation = true },
                buttonColor = MaterialTheme.colors.error
            )
            
            ActionSettingItem(
                title = "Clear Cache",
                icon = Icons.Default.ClearAll,
                onClick = { /* Show confirmation dialog */ }
            )
            
            ActionSettingItem(
                title = "Export Settings",
                icon = Icons.Default.GetApp,
                onClick = { /* Export settings */ }
            )
            
            ActionSettingItem(
                title = "Import Settings",
                icon = Icons.Default.Publish,
                onClick = { /* Import settings */ }
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // App info
            Text(
                text = "Music DAW v1.0.0",
                style = MaterialTheme.typography.body2,
                color = Color.Gray,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            
            Text(
                text = "© 2025 Music DAW, Inc.",
                style = MaterialTheme.typography.caption,
                color = Color.Gray,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
    
    // Theme dialog
    if (showThemeDialog) {
        val themes = listOf("Light", "Dark", "System Default")
        
        SelectionDialog(
            title = "Select Theme",
            options = themes,
            selectedOption = settings.theme,
            onOptionSelected = { 
                settings = settings.copy(theme = it)
                showThemeDialog = false
            },
            onDismiss = { showThemeDialog = false }
        )
    }
    
    // Language dialog
    if (showLanguageDialog) {
        val languages = listOf("English", "Español", "Français", "Deutsch", "日本語", "한국어", "中文")
        
        SelectionDialog(
            title = "Select Language",
            options = languages,
            selectedOption = settings.language,
            onOptionSelected = { 
                settings = settings.copy(language = it)
                showLanguageDialog = false
            },
            onDismiss = { showLanguageDialog = false }
        )
    }
    
    // Buffer size dialog
    if (showBufferSizeDialog) {
        val bufferSizes = listOf(256, 512, 1024, 2048, 4096)
        
        SelectionDialog(
            title = "Select Buffer Size",
            options = bufferSizes.map { "$it samples" },
            selectedOption = "${settings.audioBufferSize} samples",
            onOptionSelected = { 
                val newSize = it.split(" ")[0].toInt()
                settings = settings.copy(audioBufferSize = newSize)
                showBufferSizeDialog = false
            },
            onDismiss = { showBufferSizeDialog = false }
        )
    }
    
    // Sample rate dialog
    if (showSampleRateDialog) {
        val sampleRates = listOf(44100, 48000, 88200, 96000)
        
        SelectionDialog(
            title = "Select Sample Rate",
            options = sampleRates.map { "$it Hz" },
            selectedOption = "${settings.sampleRate} Hz",
            onOptionSelected = { 
                val newRate = it.split(" ")[0].toInt()
                settings = settings.copy(sampleRate = newRate)
                showSampleRateDialog = false
            },
            onDismiss = { showSampleRateDialog = false }
        )
    }
    
    // Bit depth dialog
    if (showBitDepthDialog) {
        val bitDepths = listOf(16, 24, 32)
        
        SelectionDialog(
            title = "Select Bit Depth",
            options = bitDepths.map { "$it bit" },
            selectedOption = "${settings.bitDepth} bit",
            onOptionSelected = { 
                val newDepth = it.split(" ")[0].toInt()
                settings = settings.copy(bitDepth = newDepth)
                showBitDepthDialog = false
            },
            onDismiss = { showBitDepthDialog = false }
        )
    }
    
    // Backup interval dialog
    if (showBackupIntervalDialog) {
        val intervals = listOf(5, 10, 15, 30, 60, 120)
        
        SelectionDialog(
            title = "Select Backup Interval",
            options = intervals.map { "$it minutes" },
            selectedOption = "${settings.backupIntervalMinutes} minutes",
            onOptionSelected = { 
                val newInterval = it.split(" ")[0].toInt()
                settings = settings.copy(backupIntervalMinutes = newInterval)
                showBackupIntervalDialog = false
            },
            onDismiss = { showBackupIntervalDialog = false }
        )
    }
    
    // Max undo levels dialog
    if (showMaxUndoLevelsDialog) {
        val levels = listOf(10, 20, 50, 100, 200, 500)
        
        SelectionDialog(
            title = "Max Undo Levels",
            options = levels.map { it.toString() },
            selectedOption = settings.maxUndoLevels.toString(),
            onOptionSelected = { 
                val newLevels = it.toInt()
                settings = settings.copy(maxUndoLevels = newLevels)
                showMaxUndoLevelsDialog = false
            },
            onDismiss = { showMaxUndoLevelsDialog = false }
        )
    }
    
    // Reset settings confirmation dialog
    if (showResetSettingsConfirmation) {
        AlertDialog(
            onDismissRequest = { showResetSettingsConfirmation = false },
            title = { Text("Reset All Settings") },
            text = { Text("Are you sure you want to reset all settings to default values? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        // Reset settings to default
                        settings = AppSettings()
                        showResetSettingsConfirmation = false
                    },
                    colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.error)
                ) {
                    Text("Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetSettingsConfirmation = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SettingsCategory(title: String) {
    Text(
        text = title,
        color = MaterialTheme.colors.primary,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

@Composable
fun SettingsItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colors.primary,
            modifier = Modifier.size(24.dp)
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                fontSize = 16.sp
            )
            
            Text(
                text = subtitle,
                fontSize = 14.sp,
                color = Color.Gray
            )
        }
        
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = "Open",
            tint = Color.Gray,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
fun SwitchSettingItem(
    title: String,
    isChecked: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                onClick = { onCheckedChange(!isChecked) },
                enabled = enabled
            )
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (enabled) MaterialTheme.colors.primary else Color.Gray,
            modifier = Modifier.size(24.dp)
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Text(
            text = title,
            fontSize = 16.sp,
            modifier = Modifier.weight(1f),
            color = if (enabled) Color.Unspecified else Color.Gray
        )
        
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            enabled = enabled
        )
    }
}

@Composable
fun SliderSettingItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int,
    onValueChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colors.primary,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    fontSize = 16.sp
                )
                
                Text(
                    text = subtitle,
                    fontSize = 14.sp,
                    color = Color.Gray
                )
            }
        }
        
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 40.dp, top = 8.dp)
        )
    }
}

@Composable
fun ActionSettingItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    buttonColor: Color = MaterialTheme.colors.primary
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colors.primary,
            modifier = Modifier.size(24.dp)
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Text(
            text = title,
            fontSize = 16.sp,
            modifier = Modifier.weight(1f)
        )
        
        Button(
            onClick = onClick,
            colors = ButtonDefaults.buttonColors(backgroundColor = buttonColor)
        ) {
            Text("Execute", color = Color.White)
        }
    }
}

@Composable
fun SelectionDialog(
    title: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { option ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOptionSelected(option) }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = option == selectedOption,
                            onClick = { onOptionSelected(option) }
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        Text(option)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
        dismissButton = {}
    )
}