package com.musicdaw.android.model

import java.util.*

/**
 * Represents an AI processing task in the DAW
 */
data class AITask(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String,
    val type: AITaskType,
    val status: AITaskStatus = AITaskStatus.QUEUED,
    val progress: Float = 0f, // 0.0 to 1.0
    val createdDate: Date = Date(),
    val startedDate: Date? = null,
    val completedDate: Date? = null,
    val error: String? = null,
    val resultFiles: List<String> = emptyList(),
    val inputFiles: List<String> = emptyList(),
    val parameters: Map<String, String> = emptyMap(),
    val trackIds: List<String> = emptyList(),
    val userId: String? = null,
    val requiresNetwork: Boolean = true
)

/**
 * Represents the status of an AI task
 */
enum class AITaskStatus(val displayName: String) {
    QUEUED("Queued"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed"),
    FAILED("Failed"),
    CANCELLED("Cancelled")
}

/**
 * Represents the type of AI task
 */
enum class AITaskType(val displayName: String) {
    SONG_DECOMPOSITION("Song Decomposition"),
    SAMPLE_EXTRACTION("Sample Extraction"),
    AUTO_MIXING("Auto Mixing"),
    AUTO_MASTERING("Auto Mastering"),
    VOCAL_SEPARATION("Vocal Separation"),
    INSTRUMENT_SEPARATION("Instrument Separation"),
    GENRE_TRANSFER("Genre Transfer"),
    VOICE_CLONING("Voice Cloning"),
    LYRIC_DETECTION("Lyric Detection"),
    CHORD_DETECTION("Chord Detection"),
    BEAT_DETECTION("Beat Detection"),
    KEY_DETECTION("Key Detection"),
    MELODY_EXTRACTION("Melody Extraction"),
    AUDIO_CLEANUP("Audio Cleanup"),
    NOISE_REDUCTION("Noise Reduction"),
    DRUM_REPLACEMENT("Drum Replacement")
}

/**
 * Represents the result of an AI task
 */
data class AITaskResult(
    val taskId: String,
    val success: Boolean,
    val message: String,
    val resultFiles: List<String>,
    val additionalData: Map<String, String> = emptyMap()
)