package com.musicdaw.android.model

import java.util.*

/**
 * Represents an audio effect that can be applied to a track
 */
data class Effect(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: String,
    val settings: Map<String, Float> = emptyMap(),
    val isEnabled: Boolean = true,
    val isBypassed: Boolean = false,
    val presetName: String? = null
) {

    /**
     * Creates a copy of this effect with the enabled state toggled
     */
    fun toggleEnabled(): Effect {
        return this.copy(isEnabled = !isEnabled)
    }

    /**
     * Creates a copy of this effect with the bypass state toggled
     */
    fun toggleBypass(): Effect {
        return this.copy(isBypassed = !isBypassed)
    }

    /**
     * Creates a copy of this effect with an updated parameter setting
     */
    fun updateSetting(paramName: String, value: Float): Effect {
        val newSettings = settings.toMutableMap().apply {
            put(paramName, value)
        }
        return this.copy(settings = newSettings)
    }

    /**
     * Creates a copy of this effect with multiple updated parameter settings
     */
    fun updateSettings(newSettings: Map<String, Float>): Effect {
        val updatedSettings = settings.toMutableMap().apply {
            putAll(newSettings)
        }
        return this.copy(settings = updatedSettings)
    }

    /**
     * Creates a copy of this effect with a new name
     */
    fun withName(newName: String): Effect {
        return this.copy(name = newName)
    }

    /**
     * Creates a copy of this effect with settings from a preset
     */
    fun applyPreset(preset: EffectPreset): Effect {
        return this.copy(
            settings = preset.settings,
            presetName = preset.name
        )
    }
    
    companion object {
        /**
         * Creates a reverb effect with default settings
         */
        fun createReverb(name: String = "Reverb"): Effect {
            return Effect(
                name = name,
                type = "reverb",
                settings = mapOf(
                    "mix" to 0.3f,
                    "decay" to 0.5f,
                    "predelay" to 0.1f,
                    "size" to 0.7f,
                    "damping" to 0.5f
                )
            )
        }
        
        /**
         * Creates a delay effect with default settings
         */
        fun createDelay(name: String = "Delay"): Effect {
            return Effect(
                name = name,
                type = "delay",
                settings = mapOf(
                    "time" to 0.5f,
                    "feedback" to 0.4f,
                    "mix" to 0.3f,
                    "sync" to 0f // 0 = off, 1 = on
                )
            )
        }
        
        /**
         * Creates an EQ effect with default settings
         */
        fun createEQ(name: String = "EQ"): Effect {
            return Effect(
                name = name,
                type = "eq",
                settings = mapOf(
                    "low" to 0.5f,
                    "mid" to 0.5f,
                    "high" to 0.5f,
                    "low_freq" to 0.2f, // ~200Hz
                    "mid_freq" to 0.5f, // ~1kHz
                    "high_freq" to 0.8f // ~5kHz
                )
            )
        }
        
        /**
         * Creates a compressor effect with default settings
         */
        fun createCompressor(name: String = "Compressor"): Effect {
            return Effect(
                name = name,
                type = "compressor",
                settings = mapOf(
                    "threshold" to 0.7f,
                    "ratio" to 0.3f,
                    "attack" to 0.2f,
                    "release" to 0.5f,
                    "gain" to 0.5f
                )
            )
        }
    }
}

/**
 * Represents a preset for an effect
 */
data class EffectPreset(
    val name: String,
    val settings: Map<String, Float>
) {
    companion object {
        /**
         * Creates a collection of standard reverb presets
         */
        fun getReverbPresets(): List<EffectPreset> {
            return listOf(
                EffectPreset("Small Room", mapOf(
                    "mix" to 0.2f,
                    "decay" to 0.3f,
                    "predelay" to 0.05f,
                    "size" to 0.4f,
                    "damping" to 0.6f
                )),
                EffectPreset("Large Hall", mapOf(
                    "mix" to 0.4f,
                    "decay" to 0.7f,
                    "predelay" to 0.1f,
                    "size" to 0.8f,
                    "damping" to 0.3f
                )),
                EffectPreset("Cathedral", mapOf(
                    "mix" to 0.5f,
                    "decay" to 0.9f,
                    "predelay" to 0.15f,
                    "size" to 0.9f,
                    "damping" to 0.2f
                )),
                EffectPreset("Plate", mapOf(
                    "mix" to 0.3f,
                    "decay" to 0.5f,
                    "predelay" to 0.02f,
                    "size" to 0.6f,
                    "damping" to 0.7f
                ))
            )
        }
    }
}