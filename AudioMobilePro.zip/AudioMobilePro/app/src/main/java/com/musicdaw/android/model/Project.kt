package com.musicdaw.android.model

import java.util.*

/**
 * Represents a music project in the DAW
 */
data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val createdDate: Date = Date(),
    val modifiedDate: Date = Date(),
    val tempo: Float = 120f,
    val timeSignatureNumerator: Int = 4,
    val timeSignatureDenominator: Int = 4,
    val tracks: List<Track> = emptyList(),
    val duration: Float = 0f, // Project duration in seconds
    val markers: List<Marker> = emptyList(),
    val key: String = "C", // Musical key of the project
    val author: String = "",
    val tags: List<String> = emptyList(),
    val isModified: Boolean = false,
    val filePath: String? = null, // Path where the project is saved
    val thumbnail: String? = null, // Path to project thumbnail image
    val mixerState: MixerState = MixerState()
) {

    /**
     * Adds a track to the project
     */
    fun addTrack(track: Track): Project {
        val newTracks = tracks.toMutableList().apply {
            add(track)
        }
        return this.copy(
            tracks = newTracks,
            modifiedDate = Date(),
            isModified = true
        )
    }

    /**
     * Removes a track from the project
     */
    fun removeTrack(trackId: String): Project {
        val newTracks = tracks.filter { it.id != trackId }
        return this.copy(
            tracks = newTracks,
            modifiedDate = Date(),
            isModified = true
        )
    }

    /**
     * Updates a track in the project
     */
    fun updateTrack(trackId: String, updatedTrack: Track): Project {
        val trackIndex = tracks.indexOfFirst { it.id == trackId }
        if (trackIndex == -1) return this

        val newTracks = tracks.toMutableList().apply {
            set(trackIndex, updatedTrack)
        }
        return this.copy(
            tracks = newTracks,
            modifiedDate = Date(),
            isModified = true
        )
    }

    /**
     * Moves a track to a new position in the project
     */
    fun moveTrack(trackId: String, newPosition: Int): Project {
        val track = tracks.find { it.id == trackId } ?: return this
        val newTracks = tracks.toMutableList().apply {
            remove(track)
            add(newPosition.coerceIn(0, size), track)
        }
        return this.copy(
            tracks = newTracks,
            modifiedDate = Date(),
            isModified = true
        )
    }

    /**
     * Updates the project tempo
     */
    fun withTempo(newTempo: Float): Project {
        return this.copy(
            tempo = newTempo,
            modifiedDate = Date(),
            isModified = true
        )
    }

    /**
     * Updates the project time signature
     */
    fun withTimeSignature(numerator: Int, denominator: Int): Project {
        return this.copy(
            timeSignatureNumerator = numerator,
            timeSignatureDenominator = denominator,
            modifiedDate = Date(),
            isModified = true
        )
    }

    /**
     * Adds a marker to the project
     */
    fun addMarker(marker: Marker): Project {
        val newMarkers = markers.toMutableList().apply {
            add(marker)
        }
        return this.copy(
            markers = newMarkers,
            modifiedDate = Date(),
            isModified = true
        )
    }

    /**
     * Removes a marker from the project
     */
    fun removeMarker(markerId: String): Project {
        val newMarkers = markers.filter { it.id != markerId }
        return this.copy(
            markers = newMarkers,
            modifiedDate = Date(),
            isModified = true
        )
    }

    /**
     * Calculates the current project duration based on all tracks
     */
    fun calculateDuration(): Project {
        val maxTrackDuration = tracks.maxOfOrNull { track ->
            track.getEndTime()
        } ?: 0f

        return this.copy(duration = maxTrackDuration)
    }

    /**
     * Updates the project mixer state
     */
    fun withMixerState(mixerState: MixerState): Project {
        return this.copy(
            mixerState = mixerState,
            modifiedDate = Date(),
            isModified = true
        )
    }

    /**
     * Marks the project as saved (not modified)
     */
    fun markSaved(filePath: String): Project {
        return this.copy(
            isModified = false,
            filePath = filePath,
            modifiedDate = Date()
        )
    }
    
    companion object {
        /**
         * Creates a demo project with some default tracks
         */
        fun createDemoProject(name: String = "Demo Project"): Project {
            // Create various tracks for the demo
            val midiTrack = Track(
                name = "MIDI Track 1",
                type = TrackType.MIDI,
                color = 0xFF9C27B0.toInt(), // Purple
                volume = 0.8f
            )
            
            val audioTrack = Track(
                name = "Audio Track 1",
                type = TrackType.AUDIO,
                color = 0xFF2196F3.toInt(), // Blue
                volume = 0.8f
            )
            
            val drumTrack = Track(
                name = "Drum Track",
                type = TrackType.MIDI,
                isDrumTrack = true,
                color = 0xFFFF5722.toInt(), // Orange
                volume = 0.8f
            )
            
            // Create a basic drum pattern on the drum track
            val drumPattern = MidiPattern(
                name = "Basic Drum Pattern",
                notes = listOf(
                    // Kick on beats 1 and 3
                    MidiNote(note = 36, startTime = 0f, duration = 0.1f, velocity = 100),
                    MidiNote(note = 36, startTime = 1.0f, duration = 0.1f, velocity = 100),
                    
                    // Snare on beats 2 and 4
                    MidiNote(note = 38, startTime = 0.5f, duration = 0.1f, velocity = 90),
                    MidiNote(note = 38, startTime = 1.5f, duration = 0.1f, velocity = 90),
                    
                    // Hihat
                    MidiNote(note = 42, startTime = 0.0f, duration = 0.1f, velocity = 80),
                    MidiNote(note = 42, startTime = 0.25f, duration = 0.1f, velocity = 60),
                    MidiNote(note = 42, startTime = 0.5f, duration = 0.1f, velocity = 80),
                    MidiNote(note = 42, startTime = 0.75f, duration = 0.1f, velocity = 60)
                ),
                duration = 2.0f
            )
            
            val updatedDrumTrack = drumTrack.addMidiPattern(drumPattern)
            
            return Project(
                name = name,
                tempo = 120f,
                timeSignatureNumerator = 4,
                timeSignatureDenominator = 4,
                tracks = listOf(midiTrack, audioTrack, updatedDrumTrack),
                markers = listOf(
                    Marker(name = "Intro", position = 0f),
                    Marker(name = "Verse", position = 4f),
                    Marker(name = "Chorus", position = 8f)
                )
            ).calculateDuration()
        }
    }
}

/**
 * Represents a marker in the project timeline
 */
data class Marker(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val position: Float, // Position in seconds
    val color: Int = 0xFF4CAF50.toInt() // Default to green
)

/**
 * Represents the mixer state of the project
 */
data class MixerState(
    val masterVolume: Float = 1.0f,
    val masterPan: Float = 0f,
    val masterEffects: List<Effect> = listOf(
        Effect(
            name = "Master Compressor",
            type = "compressor",
            settings = mapOf(
                "threshold" to 0.7f,
                "ratio" to 0.3f,
                "attack" to 0.2f,
                "release" to 0.5f,
                "gain" to 0.5f
            )
        ),
        Effect(
            name = "Master EQ",
            type = "eq",
            settings = mapOf(
                "low" to 0.5f,
                "mid" to 0.5f,
                "high" to 0.5f
            )
        )
    ),
    val isMasterMuted: Boolean = false,
    val soloedTracks: List<String> = emptyList()
)