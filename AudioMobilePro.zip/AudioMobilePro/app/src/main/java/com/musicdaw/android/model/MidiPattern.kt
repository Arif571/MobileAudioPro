package com.musicdaw.android.model

import java.util.*

/**
 * Represents a pattern of MIDI notes that can be placed on a MIDI track
 */
data class MidiPattern(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val notes: List<MidiNote> = emptyList(),
    val startTime: Float = 0f, // Position in the track (in seconds)
    val duration: Float = 4f, // Duration of the pattern (in seconds, typically 1 or more measures)
    val isLooping: Boolean = false,
    val loopCount: Int = 1, // Number of times to loop (-1 for infinite)
    val color: Int = 0
) {

    /**
     * Calculates the end time of this pattern on the track
     */
    fun endTime(): Float {
        return startTime + (duration * if (isLooping) loopCount else 1)
    }

    /**
     * Creates a copy of this pattern with adjusted start time
     */
    fun withStartTime(newStartTime: Float): MidiPattern {
        return this.copy(startTime = newStartTime)
    }

    /**
     * Creates a copy of this pattern with adjusted duration
     */
    fun withDuration(newDuration: Float): MidiPattern {
        if (newDuration <= 0) {
            return this
        }
        return this.copy(duration = newDuration)
    }

    /**
     * Creates a copy of this pattern with looping toggled
     */
    fun toggleLooping(): MidiPattern {
        return this.copy(isLooping = !isLooping)
    }

    /**
     * Creates a copy of this pattern with a new note added
     */
    fun addNote(note: MidiNote): MidiPattern {
        val newNotes = notes.toMutableList().apply {
            add(note)
        }
        return this.copy(notes = newNotes)
    }

    /**
     * Creates a copy of this pattern with a note removed
     */
    fun removeNote(noteId: String): MidiPattern {
        val newNotes = notes.filter { it.id != noteId }
        return this.copy(notes = newNotes)
    }

    /**
     * Creates a copy of this pattern with an updated note
     */
    fun updateNote(noteId: String, updatedNote: MidiNote): MidiPattern {
        val noteIndex = notes.indexOfFirst { it.id == noteId }
        if (noteIndex == -1) return this
        
        val newNotes = notes.toMutableList().apply {
            set(noteIndex, updatedNote)
        }
        return this.copy(notes = newNotes)
    }

    /**
     * Creates a copy of this pattern with all notes transposed by a number of semitones
     */
    fun transpose(semitones: Int): MidiPattern {
        if (semitones == 0) {
            return this
        }
        
        val transposedNotes = notes.map { it.transpose(semitones) }
        return this.copy(notes = transposedNotes)
    }

    /**
     * Creates a copy of this pattern with notes quantized to the nearest beat or grid division
     */
    fun quantize(gridDivision: Float): MidiPattern {
        val quantizedNotes = notes.map { it.quantize(gridDivision) }
        return this.copy(notes = quantizedNotes)
    }

    /**
     * Creates a copy of this pattern with velocity of all notes scaled by a factor
     */
    fun scaleVelocity(factor: Float): MidiPattern {
        if (factor == 1f) {
            return this
        }
        
        val scaledNotes = notes.map { it.withVelocity((it.velocity * factor).coerceIn(1, 127)) }
        return this.copy(notes = scaledNotes)
    }
}