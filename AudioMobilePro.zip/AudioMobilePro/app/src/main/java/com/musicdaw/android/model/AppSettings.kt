package com.musicdaw.android.model

/**
 * Represents the application settings for the DAW
 */
data class AppSettings(
    // Audio settings
    val audioBufferSize: Int = 1024,
    val sampleRate: Int = 44100,
    val bitDepth: Int = 16,
    val maxPolyphony: Int = 64,
    val audioInputDevice: String = "Default",
    val audioOutputDevice: String = "Default",
    val midiInputDevice: String = "Default",
    val midiLatency: Int = 10, // in milliseconds
    
    // UI settings
    val theme: String = "Dark",
    val language: String = "English",
    val showWelcomeOnStartup: Boolean = true,
    val showTips: Boolean = true,
    val zoomSensitivity: Float = 1.0f,
    val showPeakMeters: Boolean = true,
    
    // Project settings
    val autosaveIntervalMinutes: Int = 5,
    val showMetronomeByDefault: Boolean = true,
    val defaultTempo: Float = 120f,
    val defaultTimeSignatureNumerator: Int = 4,
    val defaultTimeSignatureDenominator: Int = 4,
    val defaultKey: String = "C Major",
    val showGridLines: Boolean = true,
    val snapToGrid: Boolean = true,
    val defaultGridDivision: Float = 0.25f, // quarter note by default
    
    // Storage settings
    val cloudSyncEnabled: Boolean = true,
    val saveProjectsToCloud: Boolean = true,
    val downloadSamplesOnDemand: Boolean = true,
    val cacheSize: Int = 1024, // in MB
    val maxUndoLevels: Int = 100,
    val backupIntervalMinutes: Int = 30,
    val numberOfBackupsToKeep: Int = 5,
    
    // Performance settings
    val enableMultiThreadedProcessing: Boolean = true,
    val renderQuality: String = "High", // High, Medium, Low
    val maxCpuUsage: Int = 80, // percentage
    val enableGpuAcceleration: Boolean = true,
    
    // AI settings
    val aiServerUrl: String = "https://ai.musicdaw.com/api",
    val useLocalAiProcessing: Boolean = false,
    val aiProcessingPriority: String = "Balanced", // Speed, Quality, Balanced
    val downloadAiModelsOnDemand: Boolean = true,
    
    // Privacy settings
    val enableAnalytics: Boolean = true,
    val enableCrashReporting: Boolean = true,
    val shareUsageData: Boolean = true,
    
    // Advanced settings
    val enableExperimentalFeatures: Boolean = false,
    val developerMode: Boolean = false,
    val logLevel: String = "Info" // Debug, Info, Warning, Error
) {
    /**
     * Returns the buffer size in samples
     */
    fun getBufferSizeInSamples(): Int {
        return audioBufferSize
    }
    
    /**
     * Returns the buffer size in milliseconds
     */
    fun getBufferSizeInMs(): Float {
        return (audioBufferSize * 1000f) / sampleRate
    }
    
    /**
     * Returns the proper settings for the selected theme
     */
    fun getThemeSettings(): Map<String, Any> {
        return when (theme) {
            "Dark" -> mapOf(
                "backgroundColor" to 0xFF121212,
                "surfaceColor" to 0xFF1E1E1E,
                "primaryColor" to 0xFF2196F3,
                "secondaryColor" to 0xFFBB86FC,
                "textColor" to 0xFFFFFFFF,
                "isDark" to true
            )
            "Light" -> mapOf(
                "backgroundColor" to 0xFFFAFAFA,
                "surfaceColor" to 0xFFFFFFFF,
                "primaryColor" to 0xFF2196F3,
                "secondaryColor" to 0xFF03DAC6,
                "textColor" to 0xFF000000,
                "isDark" to false
            )
            else -> mapOf(
                "backgroundColor" to 0xFF121212,
                "surfaceColor" to 0xFF1E1E1E,
                "primaryColor" to 0xFF2196F3,
                "secondaryColor" to 0xFFBB86FC,
                "textColor" to 0xFFFFFFFF,
                "isDark" to true
            )
        }
    }
    
    /**
     * Returns a copy of the settings with low latency optimization
     */
    fun optimizeForLowLatency(): AppSettings {
        return this.copy(
            audioBufferSize = 256,
            enableMultiThreadedProcessing = true,
            renderQuality = "Medium",
            maxPolyphony = 32,
            midiLatency = 5
        )
    }
    
    /**
     * Returns a copy of the settings with high quality optimization
     */
    fun optimizeForHighQuality(): AppSettings {
        return this.copy(
            audioBufferSize = 2048,
            sampleRate = 48000,
            bitDepth = 24,
            enableMultiThreadedProcessing = true,
            renderQuality = "High",
            maxPolyphony = 128
        )
    }
    
    /**
     * Returns a copy of the settings with battery optimization
     */
    fun optimizeForBattery(): AppSettings {
        return this.copy(
            audioBufferSize = 2048,
            enableMultiThreadedProcessing = false,
            renderQuality = "Low",
            maxPolyphony = 32,
            enableGpuAcceleration = false,
            maxCpuUsage = 50,
            downloadSamplesOnDemand = false,
            showPeakMeters = false
        )
    }
    
    /**
     * Exports the settings as a map for saving to a file
     */
    fun toMap(): Map<String, Any?> {
        return mapOf(
            "audioBufferSize" to audioBufferSize,
            "sampleRate" to sampleRate,
            "bitDepth" to bitDepth,
            "maxPolyphony" to maxPolyphony,
            "audioInputDevice" to audioInputDevice,
            "audioOutputDevice" to audioOutputDevice,
            "midiInputDevice" to midiInputDevice,
            "midiLatency" to midiLatency,
            "theme" to theme,
            "language" to language,
            "showWelcomeOnStartup" to showWelcomeOnStartup,
            "showTips" to showTips,
            "zoomSensitivity" to zoomSensitivity,
            "showPeakMeters" to showPeakMeters,
            "autosaveIntervalMinutes" to autosaveIntervalMinutes,
            "showMetronomeByDefault" to showMetronomeByDefault,
            "defaultTempo" to defaultTempo,
            "defaultTimeSignatureNumerator" to defaultTimeSignatureNumerator,
            "defaultTimeSignatureDenominator" to defaultTimeSignatureDenominator,
            "defaultKey" to defaultKey,
            "showGridLines" to showGridLines,
            "snapToGrid" to snapToGrid,
            "defaultGridDivision" to defaultGridDivision,
            "cloudSyncEnabled" to cloudSyncEnabled,
            "saveProjectsToCloud" to saveProjectsToCloud,
            "downloadSamplesOnDemand" to downloadSamplesOnDemand,
            "cacheSize" to cacheSize,
            "maxUndoLevels" to maxUndoLevels,
            "backupIntervalMinutes" to backupIntervalMinutes,
            "numberOfBackupsToKeep" to numberOfBackupsToKeep,
            "enableMultiThreadedProcessing" to enableMultiThreadedProcessing,
            "renderQuality" to renderQuality,
            "maxCpuUsage" to maxCpuUsage,
            "enableGpuAcceleration" to enableGpuAcceleration,
            "aiServerUrl" to aiServerUrl,
            "useLocalAiProcessing" to useLocalAiProcessing,
            "aiProcessingPriority" to aiProcessingPriority,
            "downloadAiModelsOnDemand" to downloadAiModelsOnDemand,
            "enableAnalytics" to enableAnalytics,
            "enableCrashReporting" to enableCrashReporting,
            "shareUsageData" to shareUsageData,
            "enableExperimentalFeatures" to enableExperimentalFeatures,
            "developerMode" to developerMode,
            "logLevel" to logLevel
        )
    }
    
    companion object {
        /**
         * Create settings from a map
         */
        fun fromMap(map: Map<String, Any?>): AppSettings {
            return AppSettings(
                audioBufferSize = (map["audioBufferSize"] as? Number)?.toInt() ?: 1024,
                sampleRate = (map["sampleRate"] as? Number)?.toInt() ?: 44100,
                bitDepth = (map["bitDepth"] as? Number)?.toInt() ?: 16,
                maxPolyphony = (map["maxPolyphony"] as? Number)?.toInt() ?: 64,
                audioInputDevice = map["audioInputDevice"] as? String ?: "Default",
                audioOutputDevice = map["audioOutputDevice"] as? String ?: "Default",
                midiInputDevice = map["midiInputDevice"] as? String ?: "Default",
                midiLatency = (map["midiLatency"] as? Number)?.toInt() ?: 10,
                theme = map["theme"] as? String ?: "Dark",
                language = map["language"] as? String ?: "English",
                showWelcomeOnStartup = map["showWelcomeOnStartup"] as? Boolean ?: true,
                showTips = map["showTips"] as? Boolean ?: true,
                zoomSensitivity = (map["zoomSensitivity"] as? Number)?.toFloat() ?: 1.0f,
                showPeakMeters = map["showPeakMeters"] as? Boolean ?: true,
                autosaveIntervalMinutes = (map["autosaveIntervalMinutes"] as? Number)?.toInt() ?: 5,
                showMetronomeByDefault = map["showMetronomeByDefault"] as? Boolean ?: true,
                defaultTempo = (map["defaultTempo"] as? Number)?.toFloat() ?: 120f,
                defaultTimeSignatureNumerator = (map["defaultTimeSignatureNumerator"] as? Number)?.toInt() ?: 4,
                defaultTimeSignatureDenominator = (map["defaultTimeSignatureDenominator"] as? Number)?.toInt() ?: 4,
                defaultKey = map["defaultKey"] as? String ?: "C Major",
                showGridLines = map["showGridLines"] as? Boolean ?: true,
                snapToGrid = map["snapToGrid"] as? Boolean ?: true,
                defaultGridDivision = (map["defaultGridDivision"] as? Number)?.toFloat() ?: 0.25f,
                cloudSyncEnabled = map["cloudSyncEnabled"] as? Boolean ?: true,
                saveProjectsToCloud = map["saveProjectsToCloud"] as? Boolean ?: true,
                downloadSamplesOnDemand = map["downloadSamplesOnDemand"] as? Boolean ?: true,
                cacheSize = (map["cacheSize"] as? Number)?.toInt() ?: 1024,
                maxUndoLevels = (map["maxUndoLevels"] as? Number)?.toInt() ?: 100,
                backupIntervalMinutes = (map["backupIntervalMinutes"] as? Number)?.toInt() ?: 30,
                numberOfBackupsToKeep = (map["numberOfBackupsToKeep"] as? Number)?.toInt() ?: 5,
                enableMultiThreadedProcessing = map["enableMultiThreadedProcessing"] as? Boolean ?: true,
                renderQuality = map["renderQuality"] as? String ?: "High",
                maxCpuUsage = (map["maxCpuUsage"] as? Number)?.toInt() ?: 80,
                enableGpuAcceleration = map["enableGpuAcceleration"] as? Boolean ?: true,
                aiServerUrl = map["aiServerUrl"] as? String ?: "https://ai.musicdaw.com/api",
                useLocalAiProcessing = map["useLocalAiProcessing"] as? Boolean ?: false,
                aiProcessingPriority = map["aiProcessingPriority"] as? String ?: "Balanced",
                downloadAiModelsOnDemand = map["downloadAiModelsOnDemand"] as? Boolean ?: true,
                enableAnalytics = map["enableAnalytics"] as? Boolean ?: true,
                enableCrashReporting = map["enableCrashReporting"] as? Boolean ?: true,
                shareUsageData = map["shareUsageData"] as? Boolean ?: true,
                enableExperimentalFeatures = map["enableExperimentalFeatures"] as? Boolean ?: false,
                developerMode = map["developerMode"] as? Boolean ?: false,
                logLevel = map["logLevel"] as? String ?: "Info"
            )
        }
    }
}