package com.musicdaw.android.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.musicdaw.android.audio.AudioEngine
import com.musicdaw.android.model.*
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

@Composable
fun EditorScreen(
    currentProject: Project?,
    audioEngine: AudioEngine
) {
    if (currentProject == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No project loaded. Please create or open a project.")
        }
        return
    }
    
    val coroutineScope = rememberCoroutineScope()
    
    // Track playback state
    val playbackState = audioEngine.playbackState.collectAsState(initial = AudioEngine.PlaybackState.STOPPED)
    val currentPosition = audioEngine.currentPosition.collectAsState(initial = 0f)
    val isPlaying = playbackState.value == AudioEngine.PlaybackState.PLAYING
    
    // UI state for editor
    var horizontalZoom by remember { mutableStateOf(50f) } // pixels per second
    var verticalZoom by remember { mutableStateOf(40f) } // pixels per track
    
    // Scrolling state
    val horizontalScrollState = rememberScrollState()
    val verticalScrollState = rememberScrollState()
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Top control bar
        EditorTopBar(
            project = currentProject,
            isPlaying = isPlaying,
            onPlayPause = {
                if (isPlaying) {
                    audioEngine.pausePlayback()
                } else {
                    audioEngine.startPlayback()
                }
            },
            onStop = {
                audioEngine.stopPlayback()
            },
            onZoomIn = {
                horizontalZoom = (horizontalZoom * 1.2f).coerceAtMost(200f)
            },
            onZoomOut = {
                horizontalZoom = (horizontalZoom / 1.2f).coerceAtLeast(10f)
            }
        )
        
        // Main editor area
        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            // Track headers (left sidebar)
            Column(
                modifier = Modifier
                    .width(200.dp)
                    .fillMaxHeight()
                    .background(Color(0xFF2D2D2D))
                    .verticalScroll(verticalScrollState)
            ) {
                currentProject.tracks.forEach { track ->
                    TrackHeader(
                        track = track,
                        height = verticalZoom.dp
                    )
                }
            }
            
            // Timeline and tracks content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                // Editor background grid and timeline
                TimelineEditor(
                    project = currentProject,
                    currentPosition = currentPosition.value,
                    horizontalZoom = horizontalZoom,
                    verticalZoom = verticalZoom,
                    horizontalScrollState = horizontalScrollState,
                    verticalScrollState = verticalScrollState,
                    onPositionClick = { position ->
                        coroutineScope.launch {
                            audioEngine.seekTo(position)
                        }
                    }
                )
                
                // Play position indicator (vertical line)
                val playPositionOffset = currentPosition.value * horizontalZoom
                
                Canvas(
                    modifier = Modifier
                        .matchParentSize()
                        .padding(top = 20.dp) // Account for timeline ruler height
                ) {
                    drawLine(
                        color = Color.Red,
                        start = Offset(playPositionOffset, 0f),
                        end = Offset(playPositionOffset, size.height),
                        strokeWidth = 2f
                    )
                }
            }
        }
        
        // Bottom transport controls
        TransportControls(
            currentPosition = currentPosition.value,
            isPlaying = isPlaying,
            onPlayPause = {
                if (isPlaying) {
                    audioEngine.pausePlayback()
                } else {
                    audioEngine.startPlayback()
                }
            },
            onStop = {
                audioEngine.stopPlayback()
            },
            onRewind = {
                audioEngine.seekTo(0f)
            },
            onSeek = { position ->
                audioEngine.seekTo(position)
            },
            projectDuration = currentProject.duration
        )
    }
}

@Composable
fun EditorTopBar(
    project: Project,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onStop: () -> Unit,
    onZoomIn: () -> Unit,
    onZoomOut: () -> Unit
) {
    TopAppBar(
        title = {
            Column {
                Text(
                    text = project.name,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${project.tempo.toInt()} BPM | ${project.timeSignatureNumerator}/${project.timeSignatureDenominator}",
                    fontSize = 12.sp
                )
            }
        },
        backgroundColor = MaterialTheme.colors.primarySurface,
        actions = {
            // Transport controls in toolbar
            IconButton(onClick = onPlayPause) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play"
                )
            }
            
            IconButton(onClick = onStop) {
                Icon(
                    imageVector = Icons.Default.Stop,
                    contentDescription = "Stop"
                )
            }
            
            Divider(
                modifier = Modifier
                    .height(24.dp)
                    .width(1.dp)
                    .padding(horizontal = 8.dp)
            )
            
            // Zoom controls
            IconButton(onClick = onZoomIn) {
                Icon(
                    imageVector = Icons.Default.ZoomIn,
                    contentDescription = "Zoom In"
                )
            }
            
            IconButton(onClick = onZoomOut) {
                Icon(
                    imageVector = Icons.Default.ZoomOut,
                    contentDescription = "Zoom Out"
                )
            }
        }
    )
}

@Composable
fun TrackHeader(
    track: Track,
    height: androidx.compose.ui.unit.Dp
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(height)
            .padding(2.dp)
            .background(Color(0xFF3D3D3D))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Track color indicator
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .background(Color(track.color))
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            // Track name and type
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = track.name,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                
                Text(
                    text = track.type.name,
                    color = Color.LightGray,
                    fontSize = 12.sp
                )
            }
            
            // Track controls
            Row {
                IconButton(
                    onClick = { /* Toggle mute */ },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (track.isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "Mute",
                        tint = if (track.isMuted) Color.Red else Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
                
                IconButton(
                    onClick = { /* Toggle solo */ },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Headphones,
                        contentDescription = "Solo",
                        tint = if (track.isSolo) Color.Yellow else Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
                
                IconButton(
                    onClick = { /* Toggle record arm */ },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Record Arm",
                        tint = if (track.isArmed) Color.Red else Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun TimelineEditor(
    project: Project,
    currentPosition: Float,
    horizontalZoom: Float,
    verticalZoom: Float,
    horizontalScrollState: androidx.compose.foundation.ScrollState,
    verticalScrollState: androidx.compose.foundation.ScrollState,
    onPositionClick: (Float) -> Unit
) {
    val totalWidth = (project.duration * horizontalZoom)
    val totalHeight = (project.tracks.size * verticalZoom)
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF252525))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .horizontalScroll(horizontalScrollState)
                .verticalScroll(verticalScrollState)
        ) {
            // Timeline ruler
            Canvas(
                modifier = Modifier
                    .height(20.dp)
                    .width(totalWidth.dp)
                    .background(Color(0xFF3D3D3D))
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            val clickPosition = offset.x / horizontalZoom
                            onPositionClick(clickPosition)
                        }
                    }
            ) {
                val secondWidth = horizontalZoom
                val height = size.height
                
                // Draw timeline markers
                for (second in 0..project.duration.toInt()) {
                    val x = second * secondWidth
                    
                    // Second marker
                    drawLine(
                        color = Color.White,
                        start = Offset(x, height * 0.6f),
                        end = Offset(x, height),
                        strokeWidth = 1f
                    )
                    
                    // Second label (every 5 seconds)
                    if (second % 5 == 0) {
                        drawLine(
                            color = Color.White,
                            start = Offset(x, 0f),
                            end = Offset(x, height),
                            strokeWidth = if (second % 10 == 0) 2f else 1f
                        )
                    }
                }
            }
            
            // Track contents (clips and MIDI)
            Column(
                modifier = Modifier
                    .padding(top = 20.dp) // Account for timeline ruler height
                    .width(totalWidth.dp)
                    .height(totalHeight.dp)
            ) {
                project.tracks.forEachIndexed { index, track ->
                    TrackContent(
                        track = track,
                        horizontalZoom = horizontalZoom,
                        trackHeight = verticalZoom.dp
                    )
                }
            }
            
            // Grid lines
            Canvas(
                modifier = Modifier
                    .padding(top = 20.dp)
                    .width(totalWidth.dp)
                    .height(totalHeight.dp)
            ) {
                // Vertical grid lines (time divisions)
                for (second in 0..project.duration.toInt()) {
                    val x = second * horizontalZoom
                    drawLine(
                        color = Color(0xFF444444),
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = if (second % 4 == 0) 1f else 0.5f
                    )
                }
                
                // Horizontal grid lines (track divisions)
                for (track in 0..project.tracks.size) {
                    val y = track * verticalZoom
                    drawLine(
                        color = Color(0xFF444444),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1f
                    )
                }
            }
        }
    }
}

@Composable
fun TrackContent(
    track: Track,
    horizontalZoom: Float,
    trackHeight: androidx.compose.ui.unit.Dp
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(trackHeight)
    ) {
        // Draw audio clips
        track.audioClips.forEach { clip ->
            AudioClipComponent(
                clip = clip,
                trackHeight = trackHeight,
                horizontalZoom = horizontalZoom,
                trackColor = Color(track.color)
            )
        }
        
        // Draw MIDI patterns
        track.midiPatterns.forEach { pattern ->
            MidiPatternComponent(
                pattern = pattern,
                trackHeight = trackHeight,
                horizontalZoom = horizontalZoom,
                trackColor = Color(track.color)
            )
        }
    }
}

@Composable
fun AudioClipComponent(
    clip: AudioClip,
    trackHeight: androidx.compose.ui.unit.Dp,
    horizontalZoom: Float,
    trackColor: Color
) {
    val startX = clip.startTime * horizontalZoom
    val width = clip.duration * horizontalZoom
    
    Box(
        modifier = Modifier
            .offset(x = startX.dp)
            .width(width.dp)
            .height(trackHeight - 4.dp)
            .padding(vertical = 2.dp)
            .background(
                color = trackColor.copy(alpha = 0.8f),
                shape = MaterialTheme.shapes.small
            )
    ) {
        // Clip name
        Text(
            text = clip.name,
            modifier = Modifier
                .padding(4.dp)
                .align(Alignment.TopStart),
            color = Color.White,
            fontSize = 12.sp
        )
        
        // Simple waveform visualization
        Canvas(modifier = Modifier.matchParentSize()) {
            val path = Path()
            val centerY = size.height / 2
            
            // Create a simple sine wave pattern as placeholder
            path.moveTo(0f, centerY)
            for (x in 0..size.width.toInt() step 5) {
                val xFloat = x.toFloat()
                val amplitude = size.height * 0.3f
                val y = centerY + (Math.sin(xFloat * 0.1) * amplitude).toFloat()
                path.lineTo(xFloat, y)
            }
            
            drawPath(
                path = path,
                color = Color.White.copy(alpha = 0.5f),
                style = Stroke(width = 1.5f)
            )
        }
    }
}

@Composable
fun MidiPatternComponent(
    pattern: MidiPattern,
    trackHeight: androidx.compose.ui.unit.Dp,
    horizontalZoom: Float,
    trackColor: Color
) {
    val startX = pattern.startTime * horizontalZoom
    val width = pattern.duration * horizontalZoom
    
    Box(
        modifier = Modifier
            .offset(x = startX.dp)
            .width(width.dp)
            .height(trackHeight - 4.dp)
            .padding(vertical = 2.dp)
            .background(
                color = trackColor.copy(alpha = 0.6f),
                shape = MaterialTheme.shapes.small
            )
    ) {
        // Pattern name
        Text(
            text = pattern.name,
            modifier = Modifier
                .padding(4.dp)
                .align(Alignment.TopStart),
            color = Color.White,
            fontSize = 12.sp
        )
        
        // Piano roll visualization
        Canvas(modifier = Modifier.matchParentSize()) {
            val height = size.height
            val noteHeight = height / 24 // Simplified piano roll (2 octaves)
            
            // Draw note blocks
            pattern.notes.forEach { note ->
                val noteStartX = note.startTime * horizontalZoom
                val noteWidth = note.duration * horizontalZoom
                val noteY = height - (note.note % 24) * noteHeight - noteHeight
                
                drawRect(
                    color = Color.White.copy(alpha = 0.7f),
                    topLeft = Offset(noteStartX, noteY),
                    size = androidx.compose.ui.geometry.Size(noteWidth, noteHeight)
                )
            }
        }
    }
}

@Composable
fun TransportControls(
    currentPosition: Float,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onStop: () -> Unit,
    onRewind: () -> Unit,
    onSeek: (Float) -> Unit,
    projectDuration: Float
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(MaterialTheme.colors.surface)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Transport buttons
        IconButton(onClick = onRewind) {
            Icon(
                imageVector = Icons.Default.SkipPrevious,
                contentDescription = "Rewind"
            )
        }
        
        IconButton(onClick = onPlayPause) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play"
            )
        }
        
        IconButton(onClick = onStop) {
            Icon(
                imageVector = Icons.Default.Stop,
                contentDescription = "Stop"
            )
        }
        
        // Position display
        val positionMinutes = (currentPosition / 60).toInt()
        val positionSeconds = (currentPosition % 60).toInt()
        val durationMinutes = (projectDuration / 60).toInt()
        val durationSeconds = (projectDuration % 60).toInt()
        
        Text(
            text = String.format("%02d:%02d / %02d:%02d", 
                positionMinutes, positionSeconds,
                durationMinutes, durationSeconds
            ),
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        
        // Position slider
        Slider(
            value = currentPosition,
            onValueChange = { onSeek(it) },
            valueRange = 0f..maxOf(projectDuration, 1f),
            modifier = Modifier.weight(1f)
        )
    }
}