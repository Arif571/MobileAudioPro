package com.musicdaw.android.ai

import com.musicdaw.android.model.*
import android.content.Context
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.io.File
import java.io.FileInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.math.*
import java.util.*

/**
 * AI spesialis untuk genre musik Indonesia (DJ Bantengan, DJ Nrotok, Koplo, dll)
 * dengan kemampuan untuk menghasilkan, menganalisis, dan mengkonversi musik berdasarkan karakteristik genre
 */
class GenreSpecialistAI(private val context: Context) {

    companion object {
        private const val TAG = "GenreSpecialistAI"
        
        // Definisi parameter untuk berbagai genre
        private val GENRE_PARAMETERS = mapOf(
            "DJ Bantengan" to mapOf(
                "tempo_range" to Pair(90f, 110f),
                "base_scale" to "pelog", // skala gamelan Jawa untuk nuansa mistis
                "characteristic_elements" to listOf("gamelan", "gong", "kendang", "saron", "bonang"),
                "rhythm_complexity" to 0.7f,
                "ethnic_ratio" to 0.8f,
                "modern_edm_ratio" to 0.5f,
                "sub_bass_intensity" to 0.6f,
                "vocal_type" to "chants_and_shouts",
                "atmosphere" to "mystical"
            ),
            "DJ Nrotok" to mapOf(
                "tempo_range" to Pair(140f, 160f),
                "base_scale" to "minor", // biasanya menggunakan skala minor
                "characteristic_elements" to listOf("kendang", "bedug", "kentongan", "tribal_percussion"),
                "rhythm_complexity" to 0.85f,
                "ethnic_ratio" to 0.6f,
                "modern_edm_ratio" to 0.7f,
                "sub_bass_intensity" to 0.7f,
                "vocal_type" to "chops_and_cuts",
                "atmosphere" to "energetic"
            ),
            "Koplo" to mapOf(
                "tempo_range" to Pair(125f, 145f),
                "base_scale" to "pentatonic", // pentatonik untuk nuansa Jawa
                "characteristic_elements" to listOf("kendang", "ketipung", "kenong", "kempul", "gong"),
                "rhythm_complexity" to 0.8f,
                "ethnic_ratio" to 0.9f,
                "modern_edm_ratio" to 0.3f,
                "sub_bass_intensity" to 0.5f,
                "vocal_type" to "melodic_female",
                "atmosphere" to "festive"
            ),
            // Tambahkan genre global untuk referensi dan konversi
            "Trap" to mapOf(
                "tempo_range" to Pair(130f, 150f),
                "base_scale" to "minor",
                "characteristic_elements" to listOf("808_bass", "hi_hat_rolls", "snare_rolls"),
                "rhythm_complexity" to 0.7f,
                "ethnic_ratio" to 0.0f,
                "modern_edm_ratio" to 0.6f,
                "sub_bass_intensity" to 0.9f,
                "vocal_type" to "ad_libs",
                "atmosphere" to "dark"
            ),
            "EDM" to mapOf(
                "tempo_range" to Pair(120f, 130f),
                "base_scale" to "major",
                "characteristic_elements" to listOf("synth_lead", "side_chain", "plucks", "riser"),
                "rhythm_complexity" to 0.6f,
                "ethnic_ratio" to 0.0f,
                "modern_edm_ratio" to 1.0f,
                "sub_bass_intensity" to 0.7f,
                "vocal_type" to "chopped_vocals",
                "atmosphere" to "euphoric"
            )
        )
        
        // Definisi pola ritmik untuk setiap genre
        private val RHYTHM_PATTERNS = mapOf(
            "DJ Bantengan" to mapOf(
                "kendang" to listOf(
                    intArrayOf(1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0),
                    intArrayOf(1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0)
                ),
                "gamelan" to listOf(
                    intArrayOf(0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0),
                    intArrayOf(1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0)
                ),
                "gong" to listOf(
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0)
                )
            ),
            "DJ Nrotok" to mapOf(
                "kendang" to listOf(
                    intArrayOf(1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0),
                    intArrayOf(1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1)
                ),
                "bedug" to listOf(
                    intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0),
                    intArrayOf(1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0)
                ),
                "tribal" to listOf(
                    intArrayOf(0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1),
                    intArrayOf(1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0)
                )
            ),
            "Koplo" to mapOf(
                "ketipung" to listOf(
                    intArrayOf(1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0),
                    intArrayOf(1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0)
                ),
                "cengkok" to listOf(
                    intArrayOf(0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0),
                    intArrayOf(0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0)
                ),
                "kempul" to listOf(
                    intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0),
                    intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1)
                )
            )
        )
        
        // Definisi melodi karakteristik untuk setiap genre
        private val MELODIC_PATTERNS = mapOf(
            "DJ Bantengan" to listOf(
                intArrayOf(0, 4, 5, 7, 5, 4, 0, -1, 0, 4, 5, 7, 5, 4, 0, -1),
                intArrayOf(0, 4, 7, 9, 7, 4, 0, -1, 0, 4, 7, 9, 7, 4, 0, -1),
                intArrayOf(0, 2, 4, 7, 4, 2, 0, -1, 0, 2, 4, 7, 4, 2, 0, -1)
            ),
            "DJ Nrotok" to listOf(
                intArrayOf(0, 0, 3, 0, 7, 0, 3, 0, 0, 0, 3, 0, 10, 7, 3, 0),
                intArrayOf(0, 3, 7, 10, 7, 3, 0, -1, 0, 3, 7, 12, 7, 3, 0, -1),
                intArrayOf(0, 0, 7, 7, 3, 3, 7, 7, 0, 0, 7, 7, 10, 7, 3, 0)
            ),
            "Koplo" to listOf(
                intArrayOf(0, 2, 3, 5, 5, 3, 2, 0, 0, 2, 3, 5, 5, 3, 2, 0),
                intArrayOf(0, 3, 5, 7, 5, 3, 0, -1, 0, 3, 5, 7, 8, 7, 5, 3),
                intArrayOf(5, 5, 5, 5, 7, 8, 7, 5, 3, 3, 3, 2, 3, 5, 3, 2)
            )
        )
    }

    // Model generator genre
    private var genreGeneratorModel: Interpreter? = null
    
    // Model genre classifier
    private var genreClassifierModel: Interpreter? = null
    
    // Model genre converter
    private var genreConverterModel: Interpreter? = null
    
    // Library data karakteristik
    private val genreCharacteristics = mutableMapOf<String, JSONObject>()
    
    // Sample database untuk setiap genre
    private val genreSampleDatabase = mutableMapOf<String, List<SampleReference>>()
    
    init {
        try {
            // Load TensorFlow Lite models
            genreGeneratorModel = loadTfliteModel("models/genre_generator.tflite")
            genreClassifierModel = loadTfliteModel("models/genre_classifier.tflite")
            genreConverterModel = loadTfliteModel("models/genre_converter.tflite")
            
            // Load characteristics data
            loadGenreCharacteristics()
            
            // Load sample database
            loadSampleDatabase()
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing GenreSpecialistAI", e)
        }
    }
    
    /**
     * Hasilkan musik dengan genre yang spesifik
     * @param genre Genre musik target
     * @param sampleSets Sample yang tersedia untuk digunakan
     * @param durationInBars Durasi musik dalam bar
     * @param tempo Tempo musik dalam BPM
     * @param complexity Kompleksitas musik (0.0-1.0)
     * @return Project dengan musik genre tertentu
     */
    suspend fun generateMusic(
        genre: String,
        sampleSets: List<AudioSampleExtractorAI.AudioSample>,
        durationInBars: Int = 16,
        tempo: Float? = null,
        complexity: Float = 0.7f
    ): Project = withContext(Dispatchers.Default) {
        try {
            Log.d(TAG, "Generating $genre music with ${sampleSets.size} samples")
            
            // Validasi genre dan parameter
            if (!isGenreSupported(genre)) {
                throw IllegalArgumentException("Genre not supported: $genre")
            }
            
            // Tentukan tempo berdasarkan genre jika tidak ditentukan
            val genreParams = GENRE_PARAMETERS[genre] ?: GENRE_PARAMETERS["DJ Bantengan"]!!
            val tempoRange = genreParams["tempo_range"] as Pair<Float, Float>
            val actualTempo = tempo ?: (tempoRange.first + (tempoRange.second - tempoRange.first) * Random().nextFloat())
            
            // 1. Buat struktur musik
            val structureParts = generateMusicStructure(genre, durationInBars)
            
            // 2. Pilih skala musik yang sesuai dengan genre
            val musicScale = selectMusicScale(genre)
            
            // 3. Hasilkan chord progression
            val chordProgression = generateChordProgression(genre, musicScale, structureParts)
            
            // 4. Kategorikan sample berdasarkan tipe instrument
            val categorizedSamples = categorizeSamples(sampleSets, genre)
            
            // 5. Hasilkan track untuk setiap elemen genre
            val tracks = mutableListOf<Track>()
            
            // 5.1 Track perkusi
            val percussionTracks = createPercussionTracks(genre, actualTempo, structureParts, 
                                                         categorizedSamples, complexity)
            tracks.addAll(percussionTracks)
            
            // 5.2 Track bass
            val bassTrack = createBassTrack(genre, actualTempo, structureParts, chordProgression, 
                                           categorizedSamples, complexity)
            if (bassTrack != null) {
                tracks.add(bassTrack)
            }
            
            // 5.3 Track melodi dan instrumen etnik
            val melodicTracks = createMelodicTracks(genre, actualTempo, structureParts, 
                                                  chordProgression, categorizedSamples, complexity)
            tracks.addAll(melodicTracks)
            
            // 5.4 Track efek
            val fxTrack = createFXTrack(genre, actualTempo, structureParts, categorizedSamples)
            if (fxTrack != null) {
                tracks.add(fxTrack)
            }
            
            // 6. Terapkan efek genre-specific ke track
            val tracksWithEffects = applyGenreSpecificEffects(tracks, genre)
            
            // 7. Kembalikan project yang sudah jadi
            return@withContext Project(
                name = "Generated $genre",
                tempo = actualTempo,
                key = musicScale.rootNote,
                tracks = tracksWithEffects,
                duration = calculateProjectDuration(durationInBars, actualTempo)
            )
            
        } catch (e: Exception) {
            Log.e(TAG, "Error generating music", e)
            
            // Return simple project if generation fails
            return@withContext createSimpleProject(genre, sampleSets)
        }
    }
    
    /**
     * Deteksi genre dari sebuah audio
     * @param audioData Data audio yang akan dianalisis
     * @return Genre yang terdeteksi dan skor kemiripan
     */
    suspend fun detectGenre(
        audioData: FloatArray
    ): Map<String, Float> = withContext(Dispatchers.Default) {
        val genreScores = mutableMapOf<String, Float>()
        
        try {
            if (genreClassifierModel != null) {
                // Extract features from audio
                val features = extractGenreFeatures(audioData)
                
                // Run inference with classifier model
                val genreCount = 5 // Number of genres we support
                val outputBuffer = ByteBuffer.allocateDirect(4 * genreCount)
                outputBuffer.order(ByteOrder.nativeOrder())
                
                genreClassifierModel!!.run(features, outputBuffer)
                
                // Get results
                outputBuffer.rewind()
                val genres = listOf("DJ Bantengan", "DJ Nrotok", "Koplo", "Trap", "EDM")
                
                for (i in 0 until genreCount) {
                    val score = outputBuffer.float
                    genreScores[genres[i]] = score
                }
                
                return@withContext genreScores
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error detecting genre", e)
        }
        
        // Fallback: return dummy scores if model fails
        return@withContext mapOf(
            "DJ Bantengan" to 0.7f,
            "DJ Nrotok" to 0.2f,
            "Koplo" to 0.1f,
            "Trap" to 0.0f,
            "EDM" to 0.0f
        )
    }
    
    /**
     * Konversi project ke genre target
     * @param project Project yang akan dikonversi
     * @param targetGenre Genre target
     * @return Project yang sudah dikonversi ke genre target
     */
    suspend fun convertToGenre(
        project: Project,
        targetGenre: String
    ): Project = withContext(Dispatchers.Default) {
        try {
            Log.d(TAG, "Converting project to $targetGenre")
            
            // 1. Analisis genre current project
            val currentGenre = analyzeProjectGenre(project)
            val dominantGenre = currentGenre.entries.maxByOrNull { it.value }?.key ?: "Unknown"
            
            Log.d(TAG, "Current genre detected as $dominantGenre")
            
            // 2. Track classfication and separation
            val tracksByRole = classifyProjectTracks(project)
            
            // 3. Transform each track type according to target genre
            val transformedTracks = mutableListOf<Track>()
            
            // 3.1 Transform percussion tracks
            val percussionTracks = tracksByRole["percussion"] ?: emptyList()
            transformedTracks.addAll(transformPercussionTracks(
                percussionTracks, dominantGenre, targetGenre, project.tempo
            ))
            
            // 3.2 Transform bass tracks
            val bassTracks = tracksByRole["bass"] ?: emptyList()
            transformedTracks.addAll(transformBassTracks(
                bassTracks, dominantGenre, targetGenre, project.tempo, project.key
            ))
            
            // 3.3 Transform melodic tracks
            val melodicTracks = tracksByRole["melodic"] ?: emptyList()
            transformedTracks.addAll(transformMelodicTracks(
                melodicTracks, dominantGenre, targetGenre, project.tempo, project.key
            ))
            
            // 3.4 Transform FX tracks
            val fxTracks = tracksByRole["fx"] ?: emptyList()
            transformedTracks.addAll(transformFXTracks(
                fxTracks, dominantGenre, targetGenre, project.tempo
            ))
            
            // 3.5 Keep vocal tracks mostly unchanged
            val vocalTracks = tracksByRole["vocal"] ?: emptyList()
            transformedTracks.addAll(transformVocalTracks(
                vocalTracks, dominantGenre, targetGenre
            ))
            
            // 3.6 Add genre-specific tracks if needed
            if (targetGenre.contains("bantengan", ignoreCase = true) || 
                targetGenre.contains("nrotok", ignoreCase = true) || 
                targetGenre.contains("koplo", ignoreCase = true)) {
                
                val ethnicTracks = createGenreSpecificTracks(targetGenre, project.tempo, project.key)
                transformedTracks.addAll(ethnicTracks)
            }
            
            // 4. Adjust tempo if needed
            val adjustedTempo = adjustTempoForGenre(project.tempo, targetGenre)
            
            // 5. Apply genre-specific effects
            val tracksWithEffects = applyGenreSpecificEffects(transformedTracks, targetGenre)
            
            // 6. Return the converted project
            return@withContext project.copy(
                tracks = tracksWithEffects,
                tempo = adjustedTempo
            )
            
        } catch (e: Exception) {
            Log.e(TAG, "Error converting project genre", e)
            
            // Return original project if conversion fails
            return@withContext project
        }
    }
    
    /**
     * Analisis genre dari sebuah project
     * @param project Project yang akan dianalisis
     * @return Map genre dengan skor kemiripan
     */
    suspend fun analyzeProjectGenre(project: Project): Map<String, Float> = withContext(Dispatchers.Default) {
        val genreScores = mutableMapOf<String, Float>()
        
        try {
            // Extract features from project
            val projectFeatures = extractProjectFeatures(project)
            
            // Analyze features using genreClassifierModel if available
            if (genreClassifierModel != null) {
                // Run inference with classifier model
                val genreCount = 5 // Number of genres we support
                val outputBuffer = ByteBuffer.allocateDirect(4 * genreCount)
                outputBuffer.order(ByteOrder.nativeOrder())
                
                genreClassifierModel!!.run(projectFeatures, outputBuffer)
                
                // Get results
                outputBuffer.rewind()
                val genres = listOf("DJ Bantengan", "DJ Nrotok", "Koplo", "Trap", "EDM")
                
                for (i in 0 until genreCount) {
                    val score = outputBuffer.float
                    genreScores[genres[i]] = score
                }
                
                return@withContext genreScores
            }
            
            // Fallback: analyze based on track names and content
            var bantenganScore = 0f
            var nrotokScore = 0f
            var koploScore = 0f
            var trapScore = 0f
            var edmScore = 0f
            
            for (track in project.tracks) {
                // Check track name for clues
                val trackName = track.name.toLowerCase()
                
                when {
                    trackName.contains("gamelan") || trackName.contains("gong") -> bantenganScore += 0.3f
                    trackName.contains("kendang") || trackName.contains("bedug") -> {
                        nrotokScore += 0.2f
                        koploScore += 0.2f
                    }
                    trackName.contains("koplo") || trackName.contains("ketipung") -> koploScore += 0.3f
                    trackName.contains("808") || trackName.contains("trap") -> trapScore += 0.3f
                    trackName.contains("edm") || trackName.contains("synth") -> edmScore += 0.3f
                }
                
                // Check tempo
                val tempo = project.tempo
                when {
                    tempo in 90f..110f -> bantenganScore += 0.1f
                    tempo in 140f..160f -> nrotokScore += 0.2f
                    tempo in 125f..145f -> koploScore += 0.1f
                    tempo in 130f..150f -> trapScore += 0.1f
                    tempo in 120f..130f -> edmScore += 0.1f
                }
            }
            
            // Normalize scores
            val sum = bantenganScore + nrotokScore + koploScore + trapScore + edmScore
            if (sum > 0) {
                genreScores["DJ Bantengan"] = bantenganScore / sum
                genreScores["DJ Nrotok"] = nrotokScore / sum
                genreScores["Koplo"] = koploScore / sum
                genreScores["Trap"] = trapScore / sum
                genreScores["EDM"] = edmScore / sum
            } else {
                // If no clues, make an educated guess based on tempo
                val tempo = project.tempo
                when {
                    tempo in 90f..110f -> genreScores["DJ Bantengan"] = 0.8f
                    tempo in 140f..160f -> genreScores["DJ Nrotok"] = 0.8f
                    tempo in 125f..145f -> genreScores["Koplo"] = 0.8f
                    tempo in 130f..150f -> genreScores["Trap"] = 0.8f
                    tempo in 120f..130f -> genreScores["EDM"] = 0.8f
                    else -> genreScores["EDM"] = 0.6f // Default
                }
            }
            
            return@withContext genreScores
        } catch (e: Exception) {
            Log.e(TAG, "Error analyzing project genre", e)
            
            // Return default if analysis fails
            return@withContext mapOf(
                "DJ Bantengan" to 0.2f,
                "DJ Nrotok" to 0.2f,
                "Koplo" to 0.2f,
                "Trap" to 0.2f,
                "EDM" to 0.2f
            )
        }
    }
    
    /**
     * Transform project to new genre
     */
    suspend fun transformProjectToGenre(
        project: Project,
        targetGenre: String
    ): Project = withContext(Dispatchers.Default) {
        try {
            // This is a more complete version of convertToGenre
            // with full transformation of patterns, harmony, and structure
            
            // 1. Analyze current genre
            val currentGenre = analyzeProjectGenre(project)
            val dominantGenre = currentGenre.entries.maxByOrNull { it.value }?.key ?: "Unknown"
            
            // 2. Extract musical parameters from project
            val musicParameters = extractMusicParameters(project)
            
            // 3. Convert to target genre
            if (genreConverterModel != null) {
                // Prepare input buffer
                val inputBuffer = prepareGenreTransformInput(musicParameters, dominantGenre, targetGenre)
                
                // Run genre transformer model
                val outputBuffer = ByteBuffer.allocateDirect(4 * 1024) // Size depends on model output
                outputBuffer.order(ByteOrder.nativeOrder())
                
                genreConverterModel!!.run(inputBuffer, outputBuffer)
                
                // Process output to create transformed project
                outputBuffer.rewind()
                val transformedProject = processGenreTransformOutput(outputBuffer, project, targetGenre)
                
                return@withContext transformedProject
            }
            
            // 4. Fallback to manual conversion if model fails
            return@withContext convertToGenre(project, targetGenre)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error transforming project", e)
            
            // Return original project if transformation fails
            return@withContext project
        }
    }
    
    /**
     * Memuat model TensorFlow Lite dari assets
     */
    private fun loadTfliteModel(modelPath: String): Interpreter? {
        try {
            val assetManager = context.assets
            val fileDescriptor = assetManager.openFd(modelPath)
            val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
            val fileChannel = inputStream.channel
            val startOffset = fileDescriptor.startOffset
            val declaredLength = fileDescriptor.declaredLength
            val mappedBuffer = fileChannel.map(
                FileChannel.MapMode.READ_ONLY,
                startOffset,
                declaredLength
            )
            
            val options = Interpreter.Options()
            options.setNumThreads(4)
            
            return Interpreter(mappedBuffer, options)
        } catch (e: Exception) {
            Log.e(TAG, "Error loading model: $modelPath", e)
            return null
        }
    }
    
    /**
     * Load genre characteristics data
     */
    private fun loadGenreCharacteristics() {
        try {
            val jsonString = loadJsonFromAssets("data/genre_characteristics.json")
            val root = JSONObject(jsonString)
            
            val genres = root.keys()
            while (genres.hasNext()) {
                val genre = genres.next()
                genreCharacteristics[genre] = root.getJSONObject(genre)
            }
            
            Log.d(TAG, "Loaded characteristics for ${genreCharacteristics.size} genres")
        } catch (e: Exception) {
            Log.e(TAG, "Error loading genre characteristics", e)
            
            // Create default characteristics if loading fails
            for (genre in GENRE_PARAMETERS.keys) {
                genreCharacteristics[genre] = JSONObject()
            }
        }
    }
    
    /**
     * Load sample database for each genre
     */
    private fun loadSampleDatabase() {
        try {
            val jsonString = loadJsonFromAssets("data/genre_samples.json")
            val root = JSONObject(jsonString)
            
            val genres = root.keys()
            while (genres.hasNext()) {
                val genre = genres.next()
                val samplesJson = root.getJSONArray(genre)
                
                val samples = mutableListOf<SampleReference>()
                for (i in 0 until samplesJson.length()) {
                    val sampleJson = samplesJson.getJSONObject(i)
                    
                    samples.add(
                        SampleReference(
                            name = sampleJson.getString("name"),
                            path = sampleJson.getString("path"),
                            type = sampleJson.getString("type"),
                            tags = sampleJson.getJSONArray("tags").let { 
                                List(it.length()) { i -> it.getString(i) } 
                            }
                        )
                    )
                }
                
                genreSampleDatabase[genre] = samples
            }
            
            Log.d(TAG, "Loaded sample database for ${genreSampleDatabase.size} genres")
        } catch (e: Exception) {
            Log.e(TAG, "Error loading sample database", e)
            
            // Initialize empty databases if loading fails
            for (genre in GENRE_PARAMETERS.keys) {
                genreSampleDatabase[genre] = emptyList()
            }
        }
    }
    
    /**
     * Load JSON from assets
     */
    private fun loadJsonFromAssets(filePath: String): String {
        val inputStream = context.assets.open(filePath)
        val size = inputStream.available()
        val buffer = ByteArray(size)
        inputStream.read(buffer)
        inputStream.close()
        return String(buffer, Charsets.UTF_8)
    }
    
    /**
     * Check if a genre is supported
     */
    private fun isGenreSupported(genre: String): Boolean {
        // Check exact match
        if (GENRE_PARAMETERS.containsKey(genre)) {
            return true
        }
        
        // Check partial match
        for (supportedGenre in GENRE_PARAMETERS.keys) {
            if (genre.contains(supportedGenre, ignoreCase = true) ||
                supportedGenre.contains(genre, ignoreCase = true)) {
                return true
            }
        }
        
        return false
    }
    
    /**
     * Get normalized genre name
     */
    private fun getNormalizedGenre(genre: String): String {
        // Look for exact match
        if (GENRE_PARAMETERS.containsKey(genre)) {
            return genre
        }
        
        // Look for partial match
        for (supportedGenre in GENRE_PARAMETERS.keys) {
            if (genre.contains(supportedGenre, ignoreCase = true) ||
                supportedGenre.contains(genre, ignoreCase = true)) {
                return supportedGenre
            }
        }
        
        // Default
        return "DJ Bantengan"
    }
    
    /**
     * Generate music structure based on genre
     */
    private fun generateMusicStructure(genre: String, totalBars: Int): List<MusicPart> {
        val parts = mutableListOf<MusicPart>()
        var barsAssigned = 0
        
        when {
            genre.contains("bantengan", ignoreCase = true) || 
            genre.contains("nrotok", ignoreCase = true) -> {
                // Electronic dance structure with buildups and drops
                parts.add(MusicPart(type = PartType.INTRO, lengthInBars = 8))
                barsAssigned += 8
                
                parts.add(MusicPart(type = PartType.BUILD, lengthInBars = 8))
                barsAssigned += 8
                
                parts.add(MusicPart(type = PartType.DROP, lengthInBars = 16))
                barsAssigned += 16
                
                parts.add(MusicPart(type = PartType.BREAKDOWN, lengthInBars = 8))
                barsAssigned += 8
                
                // Add more parts if needed
                while (barsAssigned < totalBars) {
                    if (totalBars - barsAssigned >= 16) {
                        parts.add(MusicPart(type = PartType.DROP, lengthInBars = 16))
                        barsAssigned += 16
                    } else if (totalBars - barsAssigned >= 8) {
                        parts.add(MusicPart(type = PartType.OUTRO, lengthInBars = 8))
                        barsAssigned += 8
                    } else {
                        parts.add(MusicPart(type = PartType.OUTRO, lengthInBars = totalBars - barsAssigned))
                        barsAssigned = totalBars
                    }
                }
            }
            
            genre.contains("koplo", ignoreCase = true) -> {
                // Structure with verses and choruses for more melodic content
                parts.add(MusicPart(type = PartType.INTRO, lengthInBars = 8))
                barsAssigned += 8
                
                parts.add(MusicPart(type = PartType.VERSE, lengthInBars = 16))
                barsAssigned += 16
                
                parts.add(MusicPart(type = PartType.CHORUS, lengthInBars = 16))
                barsAssigned += 16
                
                // Add more parts if needed
                while (barsAssigned < totalBars) {
                    if (totalBars - barsAssigned >= 16) {
                        val nextPart = if (parts.last().type == PartType.VERSE) {
                            PartType.CHORUS
                        } else {
                            PartType.VERSE
                        }
                        parts.add(MusicPart(type = nextPart, lengthInBars = 16))
                        barsAssigned += 16
                    } else if (totalBars - barsAssigned >= 8) {
                        parts.add(MusicPart(type = PartType.OUTRO, lengthInBars = 8))
                        barsAssigned += 8
                    } else {
                        parts.add(MusicPart(type = PartType.OUTRO, lengthInBars = totalBars - barsAssigned))
                        barsAssigned = totalBars
                    }
                }
            }
            
            else -> {
                // Default structure
                val partSize = 16
                var remainingBars = totalBars
                
                // Add intro
                val introBars = min(8, remainingBars)
                if (introBars > 0) {
                    parts.add(MusicPart(type = PartType.INTRO, lengthInBars = introBars))
                    remainingBars -= introBars
                }
                
                // Add main parts
                while (remainingBars > 8) {
                    val partBars = min(partSize, remainingBars)
                    val partType = if (parts.isEmpty() || parts.last().type != PartType.DROP) {
                        PartType.DROP
                    } else {
                        PartType.BREAKDOWN
                    }
                    
                    parts.add(MusicPart(type = partType, lengthInBars = partBars))
                    remainingBars -= partBars
                }
                
                // Add outro if any bars left
                if (remainingBars > 0) {
                    parts.add(MusicPart(type = PartType.OUTRO, lengthInBars = remainingBars))
                }
            }
        }
        
        return parts
    }
    
    /**
     * Select music scale based on genre
     */
    private fun selectMusicScale(genre: String): MusicScale {
        val genreParams = GENRE_PARAMETERS[genre] ?: GENRE_PARAMETERS["DJ Bantengan"]!!
        val scaleType = genreParams["base_scale"] as String
        
        // Random root note
        val possibleRoots = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
        val rootNote = possibleRoots[Random().nextInt(possibleRoots.size)]
        
        // Intervals based on scale type
        val intervals = when (scaleType) {
            "pelog" -> intArrayOf(0, 2, 4, 5, 7, 9, 10) // Pelog-like
            "slendro" -> intArrayOf(0, 2, 5, 7, 9) // Slendro-like
            "minor" -> intArrayOf(0, 2, 3, 5, 7, 8, 10) // Natural minor
            "pentatonic" -> intArrayOf(0, 2, 4, 7, 9) // Major pentatonic
            "minor_pentatonic" -> intArrayOf(0, 3, 5, 7, 10) // Minor pentatonic
            else -> intArrayOf(0, 2, 4, 5, 7, 9, 11) // Major
        }
        
        return MusicScale(rootNote = rootNote, intervals = intervals)
    }
    
    /**
     * Generate chord progression based on genre and scale
     */
    private fun generateChordProgression(
        genre: String,
        scale: MusicScale,
        structureParts: List<MusicPart>
    ): List<Chord> {
        val progression = mutableListOf<Chord>()
        
        // Scale degrees for different chord progressions
        val progressions = when {
            genre.contains("bantengan", ignoreCase = true) -> {
                mapOf(
                    PartType.INTRO to listOf(1, 4, 6, 5),
                    PartType.BUILD to listOf(1, 5, 6, 4),
                    PartType.DROP to listOf(1, 5, 6, 4, 1, 5, 6, 4),
                    PartType.BREAKDOWN to listOf(6, 5, 4, 5),
                    PartType.OUTRO to listOf(1, 5, 6, 5)
                )
            }
            
            genre.contains("nrotok", ignoreCase = true) -> {
                mapOf(
                    PartType.INTRO to listOf(1, 3, 4, 5),
                    PartType.BUILD to listOf(1, 5, 1, 5),
                    PartType.DROP to listOf(1, 5, 6, 4, 1, 5, 6, 4),
                    PartType.BREAKDOWN to listOf(6, 5, 4, 1),
                    PartType.OUTRO to listOf(1, 5, 1, 5)
                )
            }
            
            genre.contains("koplo", ignoreCase = true) -> {
                mapOf(
                    PartType.INTRO to listOf(1, 4, 5, 1),
                    PartType.VERSE to listOf(1, 5, 6, 4, 1, 5, 6, 4),
                    PartType.CHORUS to listOf(1, 5, 6, 4, 1, 5, 4, 5),
                    PartType.OUTRO to listOf(1, 5, 1, 5)
                )
            }
            
            else -> {
                mapOf(
                    PartType.INTRO to listOf(1, 4, 5, 1),
                    PartType.BUILD to listOf(1, 5, 6, 4),
                    PartType.DROP to listOf(1, 5, 6, 4, 1, 5, 6, 4),
                    PartType.BREAKDOWN to listOf(6, 5, 4, 5),
                    PartType.VERSE to listOf(1, 5, 6, 4, 1, 5, 6, 4),
                    PartType.CHORUS to listOf(1, 5, 6, 4, 1, 5, 4, 5),
                    PartType.OUTRO to listOf(1, 5, 1, 5)
                )
            }
        }
        
        // Convert scale degrees to Chord objects
        var position = 0
        for (part in structureParts) {
            val partProgression = progressions[part.type] ?: progressions[PartType.DROP]!!
            val repetitions = ceil(part.lengthInBars / (partProgression.size / 2f)).toInt()
            
            for (i in 0 until repetitions) {
                for (degree in partProgression) {
                    // Get notes for this scale degree
                    val rootIndex = degree - 1
                    if (rootIndex >= 0 && rootIndex < scale.intervals.size) {
                        val chordRoot = scale.intervals[rootIndex]
                        
                        // Determine chord type based on scale degree
                        val chordType = getChordTypeForScaleDegree(degree, scale)
                        
                        // Create chord
                        progression.add(
                            Chord(
                                rootNote = chordRoot,
                                chordType = chordType,
                                position = position,
                                durationInBeats = 4 // 1 bar
                            )
                        )
                        
                        position += 4
                    }
                }
            }
        }
        
        return progression
    }
    
    /**
     * Get chord type based on scale degree
     */
    private fun getChordTypeForScaleDegree(degree: Int, scale: MusicScale): ChordType {
        // For major scale
        return if (scale.intervals.size == 7) { // Heptatonic scale
            when (degree) {
                1, 4, 5 -> ChordType.MAJOR
                2, 3, 6 -> ChordType.MINOR
                7 -> ChordType.DIMINISHED
                else -> ChordType.MAJOR
            }
        } else { // Pentatonic or other scales
            when (degree) {
                1, 5 -> ChordType.MAJOR
                2, 3, 6 -> ChordType.MINOR
                else -> ChordType.MAJOR
            }
        }
    }
    
    /**
     * Categorize samples by instrument type
     */
    private fun categorizeSamples(
        samples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String
    ): Map<String, List<AudioSampleExtractorAI.AudioSample>> {
        val categorized = mutableMapOf<String, MutableList<AudioSampleExtractorAI.AudioSample>>()
        
        // Initialize categories
        val categories = listOf("kick", "snare", "hihat", "percussion", "ethnic", "bass", "melody", "pad", "fx", "vocal")
        categories.forEach { categorized[it] = mutableListOf() }
        
        // Categorize based on sample name and metadata
        for (sample in samples) {
            val category = sample.category.toLowerCase()
            val name = sample.name.toLowerCase()
            
            when {
                category == "percussion" || category == "drum" -> {
                    when {
                        name.contains("kick") -> categorized["kick"]?.add(sample)
                        name.contains("snare") -> categorized["snare"]?.add(sample)
                        name.contains("hat") || name.contains("hi-hat") -> categorized["hihat"]?.add(sample)
                        name.contains("gamelan") || name.contains("kendang") || 
                        name.contains("ethnic") || name.contains("gong") -> categorized["ethnic"]?.add(sample)
                        else -> categorized["percussion"]?.add(sample)
                    }
                }
                
                category == "bass" -> categorized["bass"]?.add(sample)
                
                category == "melody" || category == "synth" || category == "lead" -> categorized["melody"]?.add(sample)
                
                category == "pad" || category == "ambient" -> categorized["pad"]?.add(sample)
                
                category == "fx" || category == "effect" -> categorized["fx"]?.add(sample)
                
                category == "vocal" || category == "voice" -> categorized["vocal"]?.add(sample)
                
                else -> {
                    // Try to categorize by name if category is unclear
                    when {
                        name.contains("kick") -> categorized["kick"]?.add(sample)
                        name.contains("snare") -> categorized["snare"]?.add(sample)
                        name.contains("hat") -> categorized["hihat"]?.add(sample)
                        name.contains("bass") -> categorized["bass"]?.add(sample)
                        name.contains("lead") || name.contains("melody") -> categorized["melody"]?.add(sample)
                        name.contains("pad") -> categorized["pad"]?.add(sample)
                        name.contains("fx") || name.contains("effect") -> categorized["fx"]?.add(sample)
                        name.contains("vocal") || name.contains("voice") -> categorized["vocal"]?.add(sample)
                        name.contains("gamelan") || name.contains("kendang") || 
                        name.contains("ethnic") || name.contains("gong") -> categorized["ethnic"]?.add(sample)
                        else -> categorized["percussion"]?.add(sample)
                    }
                }
            }
        }
        
        // If we don't have samples for important categories, use stock samples for the genre
        val stockSamples = genreSampleDatabase[genre] ?: emptyList()
        
        for (category in listOf("kick", "snare", "hihat", "bass", "ethnic")) {
            if (categorized[category]?.isEmpty() == true) {
                Log.d(TAG, "No samples found for $category, using stock samples")
                
                // Find stock samples for this category
                val categoryStockSamples = stockSamples.filter { it.type == category }
                if (categoryStockSamples.isNotEmpty()) {
                    // Convert stock samples to AudioSample format
                    val audioSamples = categoryStockSamples.map { ref ->
                        AudioSampleExtractorAI.AudioSample(
                            id = ref.path,
                            name = ref.name,
                            category = ref.type,
                            filePath = ref.path,
                            duration = 0.5f, // Default duration
                            transientPosition = 0f,
                            peakAmplitude = 0.9f,
                            rootNote = null,
                            tags = ref.tags,
                            metadata = mapOf("source" to "stock")
                        )
                    }
                    
                    categorized[category]?.addAll(audioSamples)
                }
            }
        }
        
        return categorized
    }
    
    /**
     * Create percussion tracks based on genre
     */
    private fun createPercussionTracks(
        genre: String,
        tempo: Float,
        structureParts: List<MusicPart>,
        categorizedSamples: Map<String, List<AudioSampleExtractorAI.AudioSample>>,
        complexity: Float
    ): List<Track> {
        val tracks = mutableListOf<Track>()
        
        // Convert tempo to milliseconds per beat
        val msPerBeat = 60000f / tempo
        val msPerBar = msPerBeat * 4
        
        // Get patterns for this genre
        val rhythmPatterns = RHYTHM_PATTERNS[getNormalizedGenre(genre)] ?: RHYTHM_PATTERNS["DJ Bantengan"]!!
        
        // Create kick track
        val kickSamples = categorizedSamples["kick"] ?: emptyList()
        if (kickSamples.isNotEmpty()) {
            val kickSample = kickSamples.first()
            val kickAudioClips = mutableListOf<AudioClip>()
            
            var position = 0f
            for (part in structureParts) {
                // Choose pattern based on part type
                val pattern = when (part.type) {
                    PartType.INTRO -> {
                        // Sparse pattern for intro
                        intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0)
                    }
                    PartType.BUILD -> {
                        // Gradually intensifying pattern
                        intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0)
                    }
                    PartType.DROP -> {
                        // Most intense pattern
                        intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
                    }
                    PartType.BREAKDOWN -> {
                        // Less intense than drop
                        intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0)
                    }
                    else -> {
                        // Default pattern
                        intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
                    }
                }
                
                // Place kick samples according to pattern
                for (bar in 0 until part.lengthInBars) {
                    for (step in 0 until pattern.size) {
                        if (pattern[step] > 0) {
                            val startTime = position + bar * msPerBar + step * (msPerBar / pattern.size)
                            kickAudioClips.add(
                                AudioClip(
                                    name = "Kick",
                                    filePath = kickSample.filePath,
                                    startTime = startTime / 1000f, // convert to seconds
                                    duration = kickSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
                
                position += part.lengthInBars * msPerBar
            }
            
            tracks.add(
                Track(
                    name = "Kick",
                    audioClips = kickAudioClips,
                    midiPatterns = emptyList()
                )
            )
        }
        
        // Create snare track
        val snareSamples = categorizedSamples["snare"] ?: emptyList()
        if (snareSamples.isNotEmpty()) {
            val snareSample = snareSamples.first()
            val snareAudioClips = mutableListOf<AudioClip>()
            
            var position = 0f
            for (part in structureParts) {
                // Choose pattern based on part type
                val pattern = when (part.type) {
                    PartType.INTRO -> {
                        // Sparse pattern for intro
                        intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0)
                    }
                    PartType.DROP -> {
                        // Standard snare on 2 and 4
                        intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0)
                    }
                    PartType.BUILD -> {
                        // Gradually intensifying pattern
                        intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0)
                    }
                    else -> {
                        // Default pattern
                        intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0)
                    }
                }
                
                // Place snare samples according to pattern
                for (bar in 0 until part.lengthInBars) {
                    for (step in 0 until pattern.size) {
                        if (pattern[step] > 0) {
                            val startTime = position + bar * msPerBar + step * (msPerBar / pattern.size)
                            snareAudioClips.add(
                                AudioClip(
                                    name = "Snare",
                                    filePath = snareSample.filePath,
                                    startTime = startTime / 1000f,
                                    duration = snareSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
                
                position += part.lengthInBars * msPerBar
            }
            
            tracks.add(
                Track(
                    name = "Snare",
                    audioClips = snareAudioClips,
                    midiPatterns = emptyList()
                )
            )
        }
        
        // Create hi-hat track
        val hihatSamples = categorizedSamples["hihat"] ?: emptyList()
        if (hihatSamples.isNotEmpty()) {
            val hihatSample = hihatSamples.first()
            val hihatAudioClips = mutableListOf<AudioClip>()
            
            var position = 0f
            for (part in structureParts) {
                // Choose pattern based on part type and genre
                val pattern = when {
                    genre.contains("nrotok", ignoreCase = true) && part.type == PartType.DROP -> {
                        // Fast hi-hats for Nrotok drop
                        intArrayOf(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
                    }
                    part.type == PartType.DROP -> {
                        // Standard hi-hat pattern for drop
                        intArrayOf(1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0)
                    }
                    part.type == PartType.INTRO || part.type == PartType.OUTRO -> {
                        // Sparse pattern for intro/outro
                        intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
                    }
                    else -> {
                        // Default pattern
                        intArrayOf(1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0)
                    }
                }
                
                // Place hi-hat samples according to pattern
                for (bar in 0 until part.lengthInBars) {
                    for (step in 0 until pattern.size) {
                        if (pattern[step] > 0) {
                            val startTime = position + bar * msPerBar + step * (msPerBar / pattern.size)
                            hihatAudioClips.add(
                                AudioClip(
                                    name = "HiHat",
                                    filePath = hihatSample.filePath,
                                    startTime = startTime / 1000f,
                                    duration = hihatSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
                
                position += part.lengthInBars * msPerBar
            }
            
            tracks.add(
                Track(
                    name = "HiHat",
                    audioClips = hihatAudioClips,
                    midiPatterns = emptyList()
                )
            )
        }
        
        // Add ethnic percussion if needed for Indonesian genres
        if (genre.contains("bantengan", ignoreCase = true) || 
            genre.contains("nrotok", ignoreCase = true) || 
            genre.contains("koplo", ignoreCase = true)) {
            
            val ethnicSamples = categorizedSamples["ethnic"] ?: emptyList()
            if (ethnicSamples.isNotEmpty()) {
                val ethnicSample = ethnicSamples.first()
                val ethnicAudioClips = mutableListOf<AudioClip>()
                
                var position = 0f
                for (part in structureParts) {
                    // Get appropriate ethnic percussion pattern
                    val patternKey = when {
                        genre.contains("bantengan", ignoreCase = true) -> "gamelan"
                        genre.contains("nrotok", ignoreCase = true) -> "tribal"
                        else -> "kendang"
                    }
                    
                    val patterns = rhythmPatterns[patternKey] ?: listOf(
                        intArrayOf(1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0)
                    )
                    
                    // Choose pattern based on part type
                    val patternIndex = when (part.type) {
                        PartType.DROP -> 1 % patterns.size
                        else -> 0
                    }
                    
                    val pattern = patterns[patternIndex]
                    
                    // Place ethnic samples according to pattern
                    for (bar in 0 until part.lengthInBars) {
                        for (step in 0 until pattern.size) {
                            if (pattern[step] > 0) {
                                val startTime = position + bar * msPerBar + step * (msPerBar / pattern.size)
                                ethnicAudioClips.add(
                                    AudioClip(
                                        name = "Ethnic",
                                        filePath = ethnicSample.filePath,
                                        startTime = startTime / 1000f,
                                        duration = ethnicSample.duration,
                                        isLooping = false
                                    )
                                )
                            }
                        }
                    }
                    
                    position += part.lengthInBars * msPerBar
                }
                
                tracks.add(
                    Track(
                        name = if (genre.contains("bantengan", ignoreCase = true)) "Gamelan" else "Ethnic",
                        audioClips = ethnicAudioClips,
                        midiPatterns = emptyList()
                    )
                )
            }
        }
        
        return tracks
    }
    
    /**
     * Create bass track based on genre
     */
    private fun createBassTrack(
        genre: String,
        tempo: Float,
        structureParts: List<MusicPart>,
        chordProgression: List<Chord>,
        categorizedSamples: Map<String, List<AudioSampleExtractorAI.AudioSample>>,
        complexity: Float
    ): Track? {
        val bassSamples = categorizedSamples["bass"] ?: emptyList()
        if (bassSamples.isEmpty()) {
            return null
        }
        
        val bassSample = bassSamples.first()
        val midiPatterns = mutableListOf<MidiPattern>()
        
        // Convert tempo to seconds per beat
        val secPerBeat = 60f / tempo
        
        // Get bass patterns for this genre from RHYTHM_PATTERNS
        val rhythmPatterns = RHYTHM_PATTERNS[getNormalizedGenre(genre)]?.get("bass") ?: listOf(
            intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
        )
        
        var position = 0f
        for (part in structureParts) {
            // Choose pattern based on part type
            val patternIndex = when (part.type) {
                PartType.INTRO, PartType.OUTRO -> 0
                PartType.DROP -> 2 % rhythmPatterns.size
                else -> 1 % rhythmPatterns.size
            }
            
            val rhythmPattern = rhythmPatterns[patternIndex]
            
            // Create MIDI notes for this part
            val midiNotes = mutableListOf<MidiNote>()
            
            for (bar in 0 until part.lengthInBars) {
                // Find the chord for this bar
                val chordIndex = ((position / 4f) + bar) % chordProgression.size
                val chord = chordProgression[chordIndex.toInt()]
                
                // Get the root note from chord
                val rootNote = chord.rootNote + 36 // 36 = C1, good bass range
                
                // Create bass pattern based on rhythm pattern
                for (step in 0 until rhythmPattern.size) {
                    if (rhythmPattern[step] > 0) {
                        // Add note on the rhythm hit
                        val noteStartBeat = bar * 4f + step * (4f / rhythmPattern.size)
                        val noteLength = when {
                            genre.contains("trap", ignoreCase = true) -> 0.8f // Longer notes for trap
                            else -> 0.25f // Shorter for other genres
                        }
                        
                        midiNotes.add(
                            MidiNote(
                                note = rootNote,
                                startTime = noteStartBeat,
                                duration = noteLength,
                                velocity = 100
                            )
                        )
                    }
                }
            }
            
            // Create a pattern for this part
            if (midiNotes.isNotEmpty()) {
                midiPatterns.add(
                    MidiPattern(
                        name = "Bass ${part.type}",
                        notes = midiNotes,
                        duration = part.lengthInBars * 4f,
                        startTime = position,
                        isLooping = false
                    )
                )
            }
            
            position += part.lengthInBars * 4f
        }
        
        return Track(
            name = "Bass",
            audioClips = emptyList(),
            midiPatterns = midiPatterns
        )
    }
    
    /**
     * Create melodic tracks based on genre
     */
    private fun createMelodicTracks(
        genre: String,
        tempo: Float,
        structureParts: List<MusicPart>,
        chordProgression: List<Chord>,
        categorizedSamples: Map<String, List<AudioSampleExtractorAI.AudioSample>>,
        complexity: Float
    ): List<Track> {
        val tracks = mutableListOf<Track>()
        
        // Get samples
        val melodySamples = categorizedSamples["melody"] ?: emptyList()
        val padSamples = categorizedSamples["pad"] ?: emptyList()
        
        // Create lead track if we have melody samples
        if (melodySamples.isNotEmpty()) {
            val melodySample = melodySamples.first()
            val midiPatterns = mutableListOf<MidiPattern>()
            
            // Get melodic patterns for this genre
            val melodicPatterns = MELODIC_PATTERNS[getNormalizedGenre(genre)] ?: MELODIC_PATTERNS["DJ Bantengan"]!!
            
            var position = 0f
            for (part in structureParts) {
                // Only add melody for certain parts
                if (part.type != PartType.INTRO && part.type != PartType.OUTRO) {
                    // Choose pattern based on part
                    val patternIndex = when (part.type) {
                        PartType.DROP -> 1 % melodicPatterns.size
                        PartType.VERSE -> 0
                        PartType.CHORUS -> 2 % melodicPatterns.size
                        else -> Random().nextInt(melodicPatterns.size)
                    }
                    
                    val melodicPattern = melodicPatterns[patternIndex]
                    
                    // Create MIDI notes for this part
                    val midiNotes = mutableListOf<MidiNote>()
                    
                    for (bar in 0 until part.lengthInBars) {
                        // Find the chord for this bar
                        val chordIndex = ((position / 4f) + bar) % chordProgression.size
                        val chord = chordProgression[chordIndex.toInt()]
                        
                        // Get the root note from chord
                        val rootNote = chord.rootNote + 60 // 60 = C4, good melody range
                        
                        // Create melody based on pattern
                        for (step in 0 until melodicPattern.size) {
                            val interval = melodicPattern[step]
                            if (interval >= 0) {
                                // Add note according to pattern
                                val noteStartBeat = bar * 4f + step * (4f / melodicPattern.size)
                                
                                midiNotes.add(
                                    MidiNote(
                                        note = rootNote + interval,
                                        startTime = noteStartBeat,
                                        duration = 0.25f,
                                        velocity = 90
                                    )
                                )
                            }
                        }
                    }
                    
                    // Create a pattern for this part
                    if (midiNotes.isNotEmpty()) {
                        midiPatterns.add(
                            MidiPattern(
                                name = "Melody ${part.type}",
                                notes = midiNotes,
                                duration = part.lengthInBars * 4f,
                                startTime = position,
                                isLooping = false
                            )
                        )
                    }
                }
                
                position += part.lengthInBars * 4f
            }
            
            // Add the melody track
            if (midiPatterns.isNotEmpty()) {
                tracks.add(
                    Track(
                        name = "Melody",
                        audioClips = emptyList(),
                        midiPatterns = midiPatterns
                    )
                )
            }
        }
        
        // Create pad track if we have pad samples
        if (padSamples.isNotEmpty()) {
            val padSample = padSamples.first()
            val midiPatterns = mutableListOf<MidiPattern>()
            
            var position = 0f
            for (part in structureParts) {
                // Only add pads for certain parts
                if (part.type == PartType.INTRO || part.type == PartType.BREAKDOWN || 
                    part.type == PartType.VERSE || part.type == PartType.OUTRO) {
                    
                    // Create MIDI notes for this part - simple chord pads
                    val midiNotes = mutableListOf<MidiNote>()
                    
                    for (bar in 0 until part.lengthInBars) {
                        // Find the chord for this bar
                        val chordIndex = ((position / 4f) + bar) % chordProgression.size
                        val chord = chordProgression[chordIndex.toInt()]
                        
                        // Get the root note from chord
                        val rootNote = chord.rootNote + 60 // 60 = C4
                        
                        // Add chord notes
                        val chordNotes = getChordNotes(chord.chordType, rootNote)
                        for (note in chordNotes) {
                            midiNotes.add(
                                MidiNote(
                                    note = note,
                                    startTime = bar * 4f,
                                    duration = 4f, // Full bar
                                    velocity = 70
                                )
                            )
                        }
                    }
                    
                    // Create a pattern for this part
                    if (midiNotes.isNotEmpty()) {
                        midiPatterns.add(
                            MidiPattern(
                                name = "Pad ${part.type}",
                                notes = midiNotes,
                                duration = part.lengthInBars * 4f,
                                startTime = position,
                                isLooping = false
                            )
                        )
                    }
                }
                
                position += part.lengthInBars * 4f
            }
            
            // Add the pad track
            if (midiPatterns.isNotEmpty()) {
                tracks.add(
                    Track(
                        name = "Pad",
                        audioClips = emptyList(),
                        midiPatterns = midiPatterns
                    )
                )
            }
        }
        
        return tracks
    }
    
    /**
     * Create FX track with transition effects
     */
    private fun createFXTrack(
        genre: String,
        tempo: Float,
        structureParts: List<MusicPart>,
        categorizedSamples: Map<String, List<AudioSampleExtractorAI.AudioSample>>
    ): Track? {
        val fxSamples = categorizedSamples["fx"] ?: emptyList()
        if (fxSamples.isEmpty()) {
            return null
        }
        
        // Try to find specific FX types
        val riserSamples = fxSamples.filter { it.name.contains("rise", ignoreCase = true) || it.name.contains("sweep", ignoreCase = true) }
        val impactSamples = fxSamples.filter { it.name.contains("impact", ignoreCase = true) || it.name.contains("hit", ignoreCase = true) }
        val downlifterSamples = fxSamples.filter { it.name.contains("down", ignoreCase = true) || it.name.contains("fall", ignoreCase = true) }
        
        val audioClips = mutableListOf<AudioClip>()
        
        // Convert tempo to milliseconds per beat
        val msPerBeat = 60000f / tempo
        val msPerBar = msPerBeat * 4
        
        var position = 0f
        for (i in 0 until structureParts.size - 1) {
            val part = structureParts[i]
            val nextPart = structureParts[i + 1]
            
            // Add transition effects between parts
            if (nextPart.type == PartType.DROP || nextPart.type == PartType.CHORUS) {
                // Add a riser before drop/chorus
                if (riserSamples.isNotEmpty()) {
                    val riser = riserSamples.random()
                    val startTime = position + (part.lengthInBars * msPerBar) - min(8000f, riser.duration * 1000f)
                    
                    audioClips.add(
                        AudioClip(
                            name = "Riser",
                            filePath = riser.filePath,
                            startTime = startTime / 1000f,
                            duration = riser.duration,
                            isLooping = false
                        )
                    )
                }
                
                // Add an impact at the start of drop/chorus
                if (impactSamples.isNotEmpty()) {
                    val impact = impactSamples.random()
                    val startTime = position + (part.lengthInBars * msPerBar)
                    
                    audioClips.add(
                        AudioClip(
                            name = "Impact",
                            filePath = impact.filePath,
                            startTime = startTime / 1000f,
                            duration = impact.duration,
                            isLooping = false
                        )
                    )
                }
            } else if (nextPart.type == PartType.BREAKDOWN || nextPart.type == PartType.OUTRO) {
                // Add a downlifter before breakdown/outro
                if (downlifterSamples.isNotEmpty()) {
                    val downlifter = downlifterSamples.random()
                    val startTime = position + (part.lengthInBars * msPerBar) - 500f // Small offset
                    
                    audioClips.add(
                        AudioClip(
                            name = "Downlifter",
                            filePath = downlifter.filePath,
                            startTime = startTime / 1000f,
                            duration = downlifter.duration,
                            isLooping = false
                        )
                    )
                }
            }
            
            position += part.lengthInBars * msPerBar
        }
        
        // Add a final FX at the end if needed
        if (fxSamples.isNotEmpty() && structureParts.isNotEmpty()) {
            val lastPart = structureParts.last()
            val endPosition = position
            
            val finalFx = fxSamples.random()
            audioClips.add(
                AudioClip(
                    name = "Final FX",
                    filePath = finalFx.filePath,
                    startTime = endPosition / 1000f - 0.5f, // Half second before end
                    duration = finalFx.duration,
                    isLooping = false
                )
            )
        }
        
        if (audioClips.isEmpty()) {
            return null
        }
        
        return Track(
            name = "FX",
            audioClips = audioClips,
            midiPatterns = emptyList()
        )
    }
    
    /**
     * Apply genre-specific effects to tracks
     */
    private fun applyGenreSpecificEffects(
        tracks: List<Track>,
        genre: String
    ): List<Track> {
        return tracks.map { track ->
            val effects = mutableListOf<Effect>()
            
            // Add effects based on track type and genre
            when {
                track.name.contains("kick", ignoreCase = true) -> {
                    // EQ for kick
                    effects.add(
                        Effect(
                            name = "Kick EQ",
                            type = "eq",
                            settings = mapOf(
                                "high_pass" to 0.2f,
                                "low_boost" to 0.6f
                            )
                        )
                    )
                    
                    // Compression for kick
                    effects.add(
                        Effect(
                            name = "Kick Comp",
                            type = "compressor",
                            settings = mapOf(
                                "threshold" to 0.7f,
                                "ratio" to 0.4f,
                                "attack" to 0.1f,
                                "release" to 0.3f
                            )
                        )
                    )
                    
                    // Genre-specific processing
                    if (genre.contains("trap", ignoreCase = true)) {
                        effects.add(
                            Effect(
                                name = "Kick Distortion",
                                type = "distortion",
                                settings = mapOf(
                                    "drive" to 0.3f,
                                    "tone" to 0.6f
                                )
                            )
                        )
                    }
                }
                
                track.name.contains("bass", ignoreCase = true) -> {
                    // EQ for bass
                    effects.add(
                        Effect(
                            name = "Bass EQ",
                            type = "eq",
                            settings = mapOf(
                                "high_pass" to 0.15f,
                                "low_boost" to 0.6f,
                                "high_cut" to 0.6f
                            )
                        )
                    )
                    
                    // Compression for bass
                    effects.add(
                        Effect(
                            name = "Bass Comp",
                            type = "compressor",
                            settings = mapOf(
                                "threshold" to 0.65f,
                                "ratio" to 0.5f,
                                "attack" to 0.4f,
                                "release" to 0.4f
                            )
                        )
                    )
                    
                    // Genre-specific processing
                    if (genre.contains("trap", ignoreCase = true)) {
                        effects.add(
                            Effect(
                                name = "Bass Saturation",
                                type = "saturation",
                                settings = mapOf(
                                    "drive" to 0.4f,
                                    "tone" to 0.6f
                                )
                            )
                        )
                    }
                }
                
                track.name.contains("gamelan", ignoreCase = true) ||
                track.name.contains("ethnic", ignoreCase = true) -> {
                    // EQ for ethnic instruments
                    effects.add(
                        Effect(
                            name = "Ethnic EQ",
                            type = "eq",
                            settings = mapOf(
                                "mid_boost" to 0.55f,
                                "high_mid_boost" to 0.6f
                            )
                        )
                    )
                    
                    // Reverb for ethnic instruments
                    effects.add(
                        Effect(
                            name = "Ethnic Reverb",
                            type = "reverb",
                            settings = mapOf(
                                "size" to 0.6f,
                                "decay" to 0.7f,
                                "mix" to 0.35f
                            )
                        )
                    )
                }
                
                track.name.contains("melody", ignoreCase = true) -> {
                    // EQ for melody
                    effects.add(
                        Effect(
                            name = "Melody EQ",
                            type = "eq",
                            settings = mapOf(
                                "low_cut" to 0.4f,
                                "mid_boost" to 0.55f,
                                "high_boost" to 0.6f
                            )
                        )
                    )
                    
                    // Delay for melody
                    effects.add(
                        Effect(
                            name = "Melody Delay",
                            type = "delay",
                            settings = mapOf(
                                "time" to 0.375f,
                                "feedback" to 0.35f,
                                "mix" to 0.3f
                            )
                        )
                    )
                }
                
                track.name.contains("pad", ignoreCase = true) -> {
                    // EQ for pad
                    effects.add(
                        Effect(
                            name = "Pad EQ",
                            type = "eq",
                            settings = mapOf(
                                "low_cut" to 0.35f,
                                "high_cut" to 0.7f
                            )
                        )
                    )
                    
                    // Reverb for pad
                    effects.add(
                        Effect(
                            name = "Pad Reverb",
                            type = "reverb",
                            settings = mapOf(
                                "size" to 0.8f,
                                "decay" to 0.7f,
                                "mix" to 0.5f
                            )
                        )
                    )
                }
                
                track.name.contains("fx", ignoreCase = true) -> {
                    // Reverb for FX
                    effects.add(
                        Effect(
                            name = "FX Reverb",
                            type = "reverb",
                            settings = mapOf(
                                "size" to 0.7f,
                                "decay" to 0.6f,
                                "mix" to 0.4f
                            )
                        )
                    )
                }
            }
            
            track.copy(effects = track.effects + effects)
        }
    }
    
    /**
     * Calculate project duration in seconds
     */
    private fun calculateProjectDuration(bars: Int, tempo: Float): Float {
        // Duration of a bar in seconds
        val secondsPerBar = (60f / tempo) * 4
        return bars * secondsPerBar
    }
    
    /**
     * Create simple project (fallback if generation fails)
     */
    private fun createSimpleProject(
        genre: String,
        samples: List<AudioSampleExtractorAI.AudioSample>
    ): Project {
        // Determine tempo based on genre
        val tempo = when {
            genre.contains("bantengan", ignoreCase = true) -> 100f
            genre.contains("nrotok", ignoreCase = true) -> 150f
            genre.contains("koplo", ignoreCase = true) -> 140f
            genre.contains("trap", ignoreCase = true) -> 140f
            else -> 128f
        }
        
        val tracks = mutableListOf<Track>()
        
        // Categorize samples
        val percussionSamples = samples.filter { 
            it.category.equals("percussion", ignoreCase = true) || 
            it.name.contains("kick", ignoreCase = true) || 
            it.name.contains("drum", ignoreCase = true) 
        }
        
        // Basic percussion track
        if (percussionSamples.isNotEmpty()) {
            val audioClips = mutableListOf<AudioClip>()
            val sample = percussionSamples.first()
            
            // Simple pattern: hit on every beat for 16 beats
            for (i in 0 until 16) {
                audioClips.add(
                    AudioClip(
                        name = "Beat",
                        filePath = sample.filePath,
                        startTime = i * (60f / tempo),
                        duration = sample.duration,
                        isLooping = false
                    )
                )
            }
            
            tracks.add(
                Track(
                    name = "Basic Rhythm",
                    audioClips = audioClips,
                    midiPatterns = emptyList()
                )
            )
        }
        
        return Project(
            name = "Simple $genre",
            tempo = tempo,
            tracks = tracks,
            duration = 16 * (60f / tempo) // 16 beats
        )
    }
    
    /**
     * Get chord notes based on chord type and root note
     */
    private fun getChordNotes(chordType: ChordType, rootNote: Int): List<Int> {
        return when (chordType) {
            ChordType.MAJOR -> listOf(rootNote, rootNote + 4, rootNote + 7)
            ChordType.MINOR -> listOf(rootNote, rootNote + 3, rootNote + 7)
            ChordType.DIMINISHED -> listOf(rootNote, rootNote + 3, rootNote + 6)
            ChordType.AUGMENTED -> listOf(rootNote, rootNote + 4, rootNote + 8)
            ChordType.DOMINANT7 -> listOf(rootNote, rootNote + 4, rootNote + 7, rootNote + 10)
            ChordType.MAJOR7 -> listOf(rootNote, rootNote + 4, rootNote + 7, rootNote + 11)
            ChordType.MINOR7 -> listOf(rootNote, rootNote + 3, rootNote + 7, rootNote + 10)
        }
    }
    
    /**
     * Extract features for genre detection
     */
    private fun extractGenreFeatures(audioData: FloatArray): ByteBuffer {
        // Extract MFCC, spectral features, rhythm features, etc.
        // In real implementation this would do actual feature extraction
        
        // For this implementation, create a dummy feature buffer
        val featureSize = 128
        val featureBuffer = ByteBuffer.allocateDirect(featureSize * 4)
        featureBuffer.order(ByteOrder.nativeOrder())
        
        // Fill with zeros
        for (i in 0 until featureSize) {
            featureBuffer.putFloat(0f)
        }
        
        featureBuffer.rewind()
        return featureBuffer
    }
    
    /**
     * Extract project features for genre analysis
     */
    private fun extractProjectFeatures(project: Project): ByteBuffer {
        // In real implementation, this would extract meaningful features
        // from track patterns, effects, instruments, etc.
        
        // For this implementation, create a dummy feature buffer
        val featureSize = 128
        val featureBuffer = ByteBuffer.allocateDirect(featureSize * 4)
        featureBuffer.order(ByteOrder.nativeOrder())
        
        // Fill with zeros
        for (i in 0 until featureSize) {
            featureBuffer.putFloat(0f)
        }
        
        featureBuffer.rewind()
        return featureBuffer
    }
    
    /**
     * Classify project tracks by role
     */
    private fun classifyProjectTracks(project: Project): Map<String, List<Track>> {
        val classified = mutableMapOf<String, MutableList<Track>>()
        
        // Initialize categories
        val categories = listOf("percussion", "bass", "melodic", "fx", "vocal")
        categories.forEach { classified[it] = mutableListOf() }
        
        // Classify each track
        for (track in project.tracks) {
            val name = track.name.toLowerCase()
            
            when {
                name.contains("kick") || name.contains("snare") || 
                name.contains("hat") || name.contains("drum") || 
                name.contains("percussion") || track.isDrumTrack -> {
                    classified["percussion"]?.add(track)
                }
                
                name.contains("bass") || name.contains("808") -> {
                    classified["bass"]?.add(track)
                }
                
                name.contains("melody") || name.contains("lead") || 
                name.contains("pad") || name.contains("synth") || 
                name.contains("piano") || name.contains("gamelan") || 
                name.contains("ethnic") -> {
                    classified["melodic"]?.add(track)
                }
                
                name.contains("fx") || name.contains("effect") -> {
                    classified["fx"]?.add(track)
                }
                
                name.contains("vocal") || name.contains("voice") -> {
                    classified["vocal"]?.add(track)
                }
                
                else -> {
                    // Try to guess based on content
                    if (track.midiPatterns.isNotEmpty()) {
                        // Look at MIDI notes
                        val avgNote = track.midiPatterns.flatMap { it.notes }.map { it.note }.average()
                        
                        when {
                            avgNote < 48 -> classified["bass"]?.add(track) // Low notes = bass
                            avgNote > 60 -> classified["melodic"]?.add(track) // High notes = melodic
                            else -> classified["melodic"]?.add(track) // Default to melodic
                        }
                    } else if (track.audioClips.isNotEmpty()) {
                        // Default to percussion for audio clips
                        classified["percussion"]?.add(track)
                    }
                }
            }
        }
        
        return classified
    }
    
    /**
     * Transform percussion tracks to target genre
     */
    private fun transformPercussionTracks(
        tracks: List<Track>,
        sourceGenre: String,
        targetGenre: String,
        tempo: Float
    ): List<Track> {
        return tracks.map { track ->
            // Apply genre-specific effects and transformations
            val effects = mutableListOf<Effect>()
            
            // Add new effects based on target genre
            when {
                targetGenre.contains("bantengan", ignoreCase = true) -> {
                    if (track.name.contains("kick", ignoreCase = true)) {
                        effects.add(
                            Effect(
                                name = "Kick Mystic",
                                type = "eq",
                                settings = mapOf(
                                    "low_boost" to 0.65f,
                                    "high_cut" to 0.45f
                                )
                            )
                        )
                    }
                }
                
                targetGenre.contains("nrotok", ignoreCase = true) -> {
                    if (track.name.contains("kick", ignoreCase = true) || 
                       track.name.contains("snare", ignoreCase = true)) {
                        effects.add(
                            Effect(
                                name = "Percussion Drive",
                                type = "distortion",
                                settings = mapOf(
                                    "drive" to 0.4f,
                                    "tone" to 0.6f
                                )
                            )
                        )
                    }
                }
                
                targetGenre.contains("trap", ignoreCase = true) -> {
                    if (track.name.contains("hat", ignoreCase = true)) {
                        effects.add(
                            Effect(
                                name = "Hat Roll",
                                type = "stereo",
                                settings = mapOf(
                                    "width" to 0.7f
                                )
                            )
                        )
                    }
                }
            }
            
            // Return transformed track
            track.copy(effects = track.effects + effects)
        }
    }
    
    /**
     * Transform bass tracks to target genre
     */
    private fun transformBassTracks(
        tracks: List<Track>,
        sourceGenre: String,
        targetGenre: String,
        tempo: Float,
        key: String?
    ): List<Track> {
        return tracks.map { track ->
            // Apply genre-specific effects and transformations
            val effects = mutableListOf<Effect>()
            
            // Add new effects based on target genre
            when {
                targetGenre.contains("bantengan", ignoreCase = true) -> {
                    effects.add(
                        Effect(
                            name = "Bass Mystic",
                            type = "eq",
                            settings = mapOf(
                                "low_boost" to 0.6f,
                                "low_mid_cut" to 0.4f
                            )
                        )
                    )
                }
                
                targetGenre.contains("nrotok", ignoreCase = true) -> {
                    effects.add(
                        Effect(
                            name = "Bass Drive",
                            type = "distortion",
                            settings = mapOf(
                                "drive" to 0.45f,
                                "tone" to 0.5f
                            )
                        )
                    )
                }
                
                targetGenre.contains("trap", ignoreCase = true) -> {
                    effects.add(
                        Effect(
                            name = "808 Boost",
                            type = "saturation",
                            settings = mapOf(
                                "drive" to 0.5f,
                                "tone" to 0.4f
                            )
                        )
                    )
                }
            }
            
            // Return transformed track
            track.copy(effects = track.effects + effects)
        }
    }
    
    /**
     * Transform melodic tracks to target genre
     */
    private fun transformMelodicTracks(
        tracks: List<Track>,
        sourceGenre: String,
        targetGenre: String,
        tempo: Float,
        key: String?
    ): List<Track> {
        return tracks.map { track ->
            // Apply genre-specific effects and transformations
            val effects = mutableListOf<Effect>()
            
            // Add new effects based on target genre
            when {
                targetGenre.contains("bantengan", ignoreCase = true) -> {
                    effects.add(
                        Effect(
                            name = "Ethnic Vibe",
                            type = "reverb",
                            settings = mapOf(
                                "size" to 0.7f,
                                "decay" to 0.6f,
                                "mix" to 0.4f
                            )
                        )
                    )
                }
                
                targetGenre.contains("nrotok", ignoreCase = true) -> {
                    effects.add(
                        Effect(
                            name = "Lead Delay",
                            type = "delay",
                            settings = mapOf(
                                "time" to 0.33f,
                                "feedback" to 0.4f,
                                "mix" to 0.35f
                            )
                        )
                    )
                }
                
                targetGenre.contains("trap", ignoreCase = true) -> {
                    effects.add(
                        Effect(
                            name = "Half-time",
                            type = "time_fx",
                            settings = mapOf(
                                "rate" to 0.5f,
                                "mix" to 0.7f
                            )
                        )
                    )
                }
            }
            
            // Return transformed track
            track.copy(effects = track.effects + effects)
        }
    }
    
    /**
     * Transform FX tracks to target genre
     */
    private fun transformFXTracks(
        tracks: List<Track>,
        sourceGenre: String,
        targetGenre: String,
        tempo: Float
    ): List<Track> {
        return tracks.map { track ->
            // Apply genre-specific effects and transformations
            val effects = mutableListOf<Effect>()
            
            // Add new effects based on target genre
            when {
                targetGenre.contains("bantengan", ignoreCase = true) -> {
                    effects.add(
                        Effect(
                            name = "Mystic Reverb",
                            type = "reverb",
                            settings = mapOf(
                                "size" to 0.8f,
                                "decay" to 0.75f,
                                "mix" to 0.5f
                            )
                        )
                    )
                }
                
                targetGenre.contains("nrotok", ignoreCase = true) -> {
                    effects.add(
                        Effect(
                            name = "Energetic Delay",
                            type = "delay",
                            settings = mapOf(
                                "time" to 0.25f,
                                "feedback" to 0.5f,
                                "mix" to 0.4f
                            )
                        )
                    )
                }
            }
            
            // Return transformed track
            track.copy(effects = track.effects + effects)
        }
    }
    
    /**
     * Transform vocal tracks to target genre
     */
    private fun transformVocalTracks(
        tracks: List<Track>,
        sourceGenre: String,
        targetGenre: String
    ): List<Track> {
        return tracks.map { track ->
            // For vocals, we keep most of the original character
            // but add genre-specific effects
            val effects = mutableListOf<Effect>()
            
            // Add new effects based on target genre
            when {
                targetGenre.contains("bantengan", ignoreCase = true) -> {
                    effects.add(
                        Effect(
                            name = "Vocal Echo",
                            type = "delay",
                            settings = mapOf(
                                "time" to 0.5f,
                                "feedback" to 0.3f,
                                "mix" to 0.3f
                            )
                        )
                    )
                }
                
                targetGenre.contains("nrotok", ignoreCase = true) -> {
                    effects.add(
                        Effect(
                            name = "Vocal Chop",
                            type = "stutter",
                            settings = mapOf(
                                "rate" to 0.25f,
                                "mix" to 0.4f
                            )
                        )
                    )
                }
                
                targetGenre.contains("trap", ignoreCase = true) -> {
                    effects.add(
                        Effect(
                            name = "Vocal Autotune",
                            type = "pitch_correction",
                            settings = mapOf(
                                "amount" to 0.7f,
                                "speed" to 0.8f
                            )
                        )
                    )
                }
            }
            
            // Return transformed track
            track.copy(effects = track.effects + effects)
        }
    }
    
    /**
     * Create genre-specific tracks
     */
    private fun createGenreSpecificTracks(
        genre: String,
        tempo: Float,
        key: String?
    ): List<Track> {
        val tracks = mutableListOf<Track>()
        
        // Add ethnic instruments for Indonesian genres
        when {
            genre.contains("bantengan", ignoreCase = true) -> {
                // Add gamelan track (simple placeholder)
                val midiNotes = mutableListOf<MidiNote>()
                
                // Create simple pattern - 16 bars
                for (bar in 0 until 16) {
                    // Add notes on beats 1 and 3
                    midiNotes.add(
                        MidiNote(
                            note = 60, // C4
                            startTime = bar * 4f,
                            duration = 0.5f,
                            velocity = 90
                        )
                    )
                    
                    midiNotes.add(
                        MidiNote(
                            note = 64, // E4
                            startTime = bar * 4f + 2,
                            duration = 0.5f,
                            velocity = 80
                        )
                    )
                }
                
                val gamelanPattern = MidiPattern(
                    name = "Gamelan Pattern",
                    notes = midiNotes,
                    duration = 16 * 4f,
                    startTime = 0f,
                    isLooping = false
                )
                
                // Create gamelan track
                tracks.add(
                    Track(
                        name = "Gamelan",
                        audioClips = emptyList(),
                        midiPatterns = listOf(gamelanPattern),
                        effects = listOf(
                            Effect(
                                name = "Gamelan Reverb",
                                type = "reverb",
                                settings = mapOf(
                                    "size" to 0.7f,
                                    "decay" to 0.6f,
                                    "mix" to 0.4f
                                )
                            )
                        )
                    )
                )
            }
            
            genre.contains("nrotok", ignoreCase = true) -> {
                // Add tribal percussion track (placeholder)
                val midiNotes = mutableListOf<MidiNote>()
                
                // Create simple pattern - 16 bars
                for (bar in 0 until 16) {
                    // Tribal rhythm pattern
                    val pattern = intArrayOf(1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0)
                    
                    for (step in 0 until pattern.size) {
                        if (pattern[step] > 0) {
                            midiNotes.add(
                                MidiNote(
                                    note = 60, // C4
                                    startTime = bar * 4f + step * 0.25f,
                                    duration = 0.25f,
                                    velocity = if (step % 4 == 0) 100 else 85
                                )
                            )
                        }
                    }
                }
                
                val tribalPattern = MidiPattern(
                    name = "Tribal Pattern",
                    notes = midiNotes,
                    duration = 16 * 4f,
                    startTime = 0f,
                    isLooping = false
                )
                
                // Create tribal percussion track
                tracks.add(
                    Track(
                        name = "Tribal",
                        audioClips = emptyList(),
                        midiPatterns = listOf(tribalPattern),
                        effects = listOf(
                            Effect(
                                name = "Tribal Reverb",
                                type = "reverb",
                                settings = mapOf(
                                    "size" to 0.5f,
                                    "decay" to 0.4f,
                                    "mix" to 0.3f
                                )
                            )
                        )
                    )
                )
            }
        }
        
        return tracks
    }
    
    /**
     * Adjust tempo for genre
     */
    private fun adjustTempoForGenre(currentTempo: Float, targetGenre: String): Float {
        // Get target genre parameters
        val genreParams = GENRE_PARAMETERS[getNormalizedGenre(targetGenre)]
        if (genreParams != null) {
            val tempoRange = genreParams["tempo_range"] as Pair<Float, Float>
            
            // Check if current tempo is in range
            if (currentTempo < tempoRange.first || currentTempo > tempoRange.second) {
                // Calculate a suitable tempo in the target range
                val targetTempo = if (currentTempo < tempoRange.first) {
                    tempoRange.first
                } else if (currentTempo > tempoRange.second) {
                    tempoRange.second
                } else {
                    currentTempo
                }
                
                return targetTempo
            }
        }
        
        // Keep current tempo if it's within range
        return currentTempo
    }
    
    /**
     * Extract musical parameters from project
     */
    private fun extractMusicParameters(project: Project): Map<String, Any> {
        // This would extract key musical parameters for genre transformation
        val parameters = mutableMapOf<String, Any>()
        
        // Basic parameters
        parameters["tempo"] = project.tempo
        parameters["key"] = project.key ?: "C"
        
        // Track analysis
        val trackTypes = mutableMapOf<String, Int>()
        for (track in project.tracks) {
            val type = when {
                track.isDrumTrack -> "drum"
                track.name.contains("bass", ignoreCase = true) -> "bass"
                track.name.contains("lead", ignoreCase = true) || 
                track.name.contains("melody", ignoreCase = true) -> "melodic"
                track.name.contains("pad", ignoreCase = true) -> "pad"
                track.name.contains("fx", ignoreCase = true) -> "fx"
                track.name.contains("vocal", ignoreCase = true) -> "vocal"
                track.name.contains("ethnic", ignoreCase = true) || 
                track.name.contains("gamelan", ignoreCase = true) -> "ethnic"
                else -> "other"
            }
            
            trackTypes[type] = (trackTypes[type] ?: 0) + 1
        }
        
        parameters["track_types"] = trackTypes
        
        // More detailed analysis would extract harmony, rhythm patterns, etc.
        
        return parameters
    }
    
    /**
     * Prepare input for genre transformer model
     */
    private fun prepareGenreTransformInput(
        musicParameters: Map<String, Any>,
        sourceGenre: String,
        targetGenre: String
    ): ByteBuffer {
        // In real implementation, this would encode project parameters
        // for the genre transformer model
        
        // Dummy implementation
        val inputSize = 128
        val inputBuffer = ByteBuffer.allocateDirect(inputSize * 4)
        inputBuffer.order(ByteOrder.nativeOrder())
        
        // Fill with zeros
        for (i in 0 until inputSize) {
            inputBuffer.putFloat(0f)
        }
        
        inputBuffer.rewind()
        return inputBuffer
    }
    
    /**
     * Process output from genre transformer model
     */
    private fun processGenreTransformOutput(
        outputBuffer: ByteBuffer,
        project: Project,
        targetGenre: String
    ): Project {
        // In real implementation, this would decode model output
        // and apply transformations to the project
        
        // For demo, use the manual conversion method
        return convertToGenre(project, targetGenre)
    }
    
    /**
     * Scale description
     */
    data class MusicScale(
        val rootNote: String,
        val intervals: IntArray
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false
            
            other as MusicScale
            
            if (rootNote != other.rootNote) return false
            if (!intervals.contentEquals(other.intervals)) return false
            
            return true
        }
        
        override fun hashCode(): Int {
            var result = rootNote.hashCode()
            result = 31 * result + intervals.contentHashCode()
            return result
        }
    }
    
    /**
     * Chord in music
     */
    data class Chord(
        val rootNote: Int,
        val chordType: ChordType,
        val position: Int = 0,
        val durationInBeats: Int = 4
    )
    
    /**
     * Chord type
     */
    enum class ChordType {
        MAJOR,
        MINOR,
        DIMINISHED,
        AUGMENTED,
        DOMINANT7,
        MAJOR7,
        MINOR7
    }
    
    /**
     * Music part type
     */
    enum class PartType {
        INTRO,
        VERSE,
        CHORUS,
        DROP,
        BUILD,
        BREAKDOWN,
        OUTRO
    }
    
    /**
     * Music part information
     */
    data class MusicPart(
        val type: PartType,
        val lengthInBars: Int
    )
    
    /**
     * Reference to a sample in the database
     */
    data class SampleReference(
        val name: String,
        val path: String,
        val type: String,
        val tags: List<String>
    )
}