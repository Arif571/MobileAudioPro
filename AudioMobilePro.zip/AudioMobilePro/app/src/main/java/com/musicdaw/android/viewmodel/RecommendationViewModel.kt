package com.musicdaw.android.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicdaw.android.ai.RecommendationManager
import com.musicdaw.android.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.*

/**
 * ViewModel untuk mengelola data dan logika rekomendasi musik
 */
class RecommendationViewModel(
    private val recommendationManager: RecommendationManager = RecommendationManager(),
    private val userId: String = "user_" + UUID.randomUUID().toString()
) : ViewModel() {

    // UI state
    private val _uiState = MutableStateFlow<RecommendationUiState>(RecommendationUiState.Loading)
    val uiState: StateFlow<RecommendationUiState> = _uiState
    
    // User profile
    private val _userProfile = MutableStateFlow<UserMusicProfile?>(null)
    val userProfile: StateFlow<UserMusicProfile?> = _userProfile
    
    // Recommendations
    private val _recommendations = MutableStateFlow<List<MusicRecommendation>>(emptyList())
    val recommendations: StateFlow<List<MusicRecommendation>> = _recommendations
    
    // Filter types
    private val _selectedFilterTypes = MutableStateFlow<Set<RecommendationType>>(emptySet())
    val selectedFilterTypes: StateFlow<Set<RecommendationType>> = _selectedFilterTypes
    
    // Currently playing preview
    private val _currentlyPlayingId = MutableStateFlow<String?>(null)
    val currentlyPlayingId: StateFlow<String?> = _currentlyPlayingId
    
    /**
     * Menganalisis proyek musik pengguna untuk rekomendasi
     */
    fun analyzeProject(project: Project) {
        viewModelScope.launch {
            try {
                _uiState.value = RecommendationUiState.Loading
                
                // Analisis proyek dan perbarui profil pengguna
                val profile = recommendationManager.analyzeUserProject(project, userId)
                _userProfile.value = profile
                
                // Dapatkan rekomendasi berdasarkan profil yang diperbarui
                refreshRecommendations()
                
                _uiState.value = RecommendationUiState.Success
            } catch (e: Exception) {
                _uiState.value = RecommendationUiState.Error(e.message ?: "Failed to analyze project")
            }
        }
    }
    
    /**
     * Memperbarui rekomendasi
     */
    fun refreshRecommendations(forceRefresh: Boolean = true) {
        viewModelScope.launch {
            try {
                _uiState.value = RecommendationUiState.Loading
                
                // Dapatkan rekomendasi dengan filter yang dipilih
                val types = _selectedFilterTypes.value.ifEmpty { null }?.toList()
                val newRecommendations = recommendationManager.getRecommendations(
                    count = 10,
                    types = types,
                    forceRefresh = forceRefresh
                )
                
                _recommendations.value = newRecommendations
                _uiState.value = RecommendationUiState.Success
            } catch (e: Exception) {
                _uiState.value = RecommendationUiState.Error(e.message ?: "Failed to get recommendations")
            }
        }
    }
    
    /**
     * Set filter untuk tipe rekomendasi
     */
    fun setFilterTypes(types: Set<RecommendationType>) {
        _selectedFilterTypes.value = types
        viewModelScope.launch {
            refreshRecommendations(forceRefresh = false)
        }
    }
    
    /**
     * Memperbarui rating untuk rekomendasi
     */
    fun rateRecommendation(recommendationId: String, rating: Int) {
        viewModelScope.launch {
            try {
                recommendationManager.submitFeedback(
                    recommendationId = recommendationId,
                    rating = rating
                )
                
                // Perbarui rekomendasi di UI
                val updatedRecommendations = _recommendations.value.map { recommendation ->
                    if (recommendation.id == recommendationId) {
                        recommendation.copy(userRating = rating)
                    } else {
                        recommendation
                    }
                }
                _recommendations.value = updatedRecommendations
                
            } catch (e: Exception) {
                // Handle error (bisa diperbarui ke UI state jika diperlukan)
            }
        }
    }
    
    /**
     * Mengontrol pemutaran musik preview
     */
    fun togglePlayback(recommendationId: String?) {
        // Jika sama dengan yang sedang diputar, hentikan pemutaran
        if (recommendationId == _currentlyPlayingId.value) {
            _currentlyPlayingId.value = null
        } else {
            _currentlyPlayingId.value = recommendationId
        }
    }
    
    /**
     * Menandai interaksi dengan rekomendasi
     */
    fun markInteraction(recommendationId: String, interactionType: String) {
        viewModelScope.launch {
            try {
                // Update rekomendasi di UI untuk menandai interaksi
                val updatedRecommendations = _recommendations.value.map { recommendation ->
                    if (recommendation.id == recommendationId) {
                        recommendation.copy(userInteracted = true)
                    } else {
                        recommendation
                    }
                }
                _recommendations.value = updatedRecommendations
                
            } catch (e: Exception) {
                // Handle error (bisa diperbarui ke UI state jika diperlukan)
            }
        }
    }
    
    /**
     * Menyesuaikan preferensi secara manual untuk rekomendasi yang lebih baik
     */
    fun customizePreferences(
        likedGenres: List<String>? = null,
        dislikedGenres: List<String>? = null,
        favoriteTempo: Float? = null,
        preferredInfluences: List<String>? = null
    ) {
        viewModelScope.launch {
            try {
                _uiState.value = RecommendationUiState.Loading
                
                // Perbarui preferensi
                val success = recommendationManager.improveRecommendations(
                    likedGenres = likedGenres,
                    dislikedGenres = dislikedGenres,
                    favoriteTempo = favoriteTempo,
                    preferredInfluences = preferredInfluences
                )
                
                if (success) {
                    // Dapatkan profil yang diperbarui
                    _userProfile.value = recommendationManager.getCurrentUserProfile()
                    
                    // Refresh rekomendasi
                    refreshRecommendations()
                } else {
                    _uiState.value = RecommendationUiState.Error("Failed to update preferences")
                }
                
            } catch (e: Exception) {
                _uiState.value = RecommendationUiState.Error(e.message ?: "Failed to update preferences")
            }
        }
    }
}

/**
 * State untuk UI rekomendasi
 */
sealed class RecommendationUiState {
    object Loading : RecommendationUiState()
    object Success : RecommendationUiState()
    data class Error(val message: String) : RecommendationUiState()
}