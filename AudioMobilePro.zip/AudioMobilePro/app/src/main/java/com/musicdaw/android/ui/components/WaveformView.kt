package com.musicdaw.android.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.musicdaw.android.model.AudioClip
import kotlin.math.sin

@Composable
fun WaveformView(
    audioClip: AudioClip,
    isSelected: Boolean,
    trackColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp)
        ) {
            val width = size.width
            val height = size.height
            val centerY = height / 2f
            
            // Draw waveform background
            drawRect(
                color = trackColor.copy(alpha = 0.15f),
                size = size
            )
            
            // Draw waveform border
            drawRect(
                color = trackColor.copy(alpha = if (isSelected) 0.8f else 0.4f),
                size = size,
                style = Stroke(width = if (isSelected) 2f else 1f)
            )
            
            // Now draw the waveform
            if (audioClip.waveformData.isNotEmpty()) {
                // Use actual waveform data if available
                val path = Path()
                val step = width / audioClip.waveformData.size
                
                // Top half of waveform
                path.moveTo(0f, centerY)
                audioClip.waveformData.forEachIndexed { index, amplitude ->
                    path.lineTo(
                        index * step,
                        centerY - amplitude * (height / 2f)
                    )
                }
                path.lineTo(width, centerY)
                
                // Bottom half of waveform (mirror)
                audioClip.waveformData.asReversed().forEachIndexed { index, amplitude ->
                    path.lineTo(
                        width - index * step,
                        centerY + amplitude * (height / 2f)
                    )
                }
                path.close()
                
                drawPath(
                    path = path,
                    color = trackColor.copy(alpha = 0.5f)
                )
            } else {
                // Generate a dummy waveform if no data is provided
                val primaryWaveColor = trackColor.copy(alpha = 0.5f)
                val secondaryWaveColor = trackColor.copy(alpha = 0.3f)
                
                // Sample points for drawing the waveform
                val numPoints = 200
                
                // Draw primary waveform shape
                val path = Path()
                path.moveTo(0f, centerY)
                
                // Generate a sine wave for visualization
                for (i in 0..numPoints) {
                    val x = i * (width / numPoints)
                    
                    // Create a more natural-looking waveform with multiple frequencies
                    val amplitude1 = 0.3f * sin(i * 0.1f + audioClip.startTime * 10)
                    val amplitude2 = 0.2f * sin(i * 0.2f + audioClip.startTime * 5)
                    val amplitude3 = 0.1f * sin(i * 0.3f + audioClip.startTime * 7)
                    
                    // Combine the waves and scale to fit the height
                    val y = centerY - (amplitude1 + amplitude2 + amplitude3) * (height / 3f)
                    
                    path.lineTo(x, y)
                }
                
                // Complete the path to the end
                path.lineTo(width, centerY)
                
                // Bottom half of waveform (mirror)
                for (i in numPoints downTo 0) {
                    val x = i * (width / numPoints)
                    
                    val amplitude1 = 0.3f * sin(i * 0.1f + audioClip.startTime * 10)
                    val amplitude2 = 0.2f * sin(i * 0.2f + audioClip.startTime * 5)
                    val amplitude3 = 0.1f * sin(i * 0.3f + audioClip.startTime * 7)
                    
                    val y = centerY + (amplitude1 + amplitude2 + amplitude3) * (height / 3f)
                    
                    path.lineTo(x, y)
                }
                
                path.close()
                
                drawPath(
                    path = path,
                    color = primaryWaveColor
                )
                
                // Draw secondary highlights
                for (i in 0 until 10) {
                    val x = width * (i / 10f)
                    val barHeight = height * 0.3f * (0.5f + 0.5f * sin(i * 0.7f + audioClip.startTime * 3))
                    
                    drawRect(
                        color = secondaryWaveColor,
                        topLeft = Offset(x, centerY - barHeight / 2),
                        size = Size(width * 0.03f, barHeight)
                    )
                }
            }
            
            // Draw clip name if there's space
            if (height > 40) {
                drawContext.canvas.nativeCanvas.drawText(
                    audioClip.name,
                    10f,
                    20f,
                    android.graphics.Paint().apply {
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f).toArgb()
                        textSize = 14.dp.toPx()
                    }
                )
            }
        }
    }
}
