package com.musicdaw.android.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.musicdaw.android.R
import com.musicdaw.android.model.Track
import com.musicdaw.android.ui.theme.MeterGreen
import com.musicdaw.android.ui.theme.MeterRed
import com.musicdaw.android.ui.theme.MeterYellow

@Composable
fun MixerChannel(
    track: Track,
    trackColor: Color,
    level: Float,
    isSelected: Boolean,
    onVolumeChange: (Float) -> Unit,
    onPanChange: (Float) -> Unit,
    onMuteToggle: () -> Unit,
    onSoloToggle: () -> Unit,
    onSelect: () -> Unit,
    onEffectsEdit: () -> Unit
) {
    val animatedLevel by animateFloatAsState(targetValue = level)
    
    Card(
        modifier = Modifier
            .width(90.dp)
            .height(380.dp)
            .clickable(onClick = onSelect),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) 
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
            else 
                MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(8.dp),
        border = if (isSelected) 
            BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
        else 
            null
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Track color indicator and name
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(trackColor)
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = track.name,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Level meter
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.7f))
                    .padding(4.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                // Level meter background grid
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceEvenly
                ) {
                    // Draw level markers
                    repeat(10) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(Color.Gray.copy(alpha = 0.3f))
                        )
                    }
                }
                
                // Actual level indicator
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(animatedLevel.coerceIn(0f, 1f))
                        .background(
                            when {
                                animatedLevel > 0.8f -> MeterRed
                                animatedLevel > 0.6f -> MeterYellow
                                else -> MeterGreen
                            }
                        )
                )
                
                // Level marks
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(end = 2.dp)
                ) {
                    Text(
                        text = "0",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )
                }
                
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 2.dp)
                ) {
                    Text(
                        text = "-∞",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )
                }
            }
            
            // Mute/Solo buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(
                    onClick = onMuteToggle,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = ImageVector.vectorResource(id = R.drawable.ic_mute),
                        contentDescription = "Mute",
                        tint = if (track.isMuted) MaterialTheme.colorScheme.primary else Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                }
                
                IconButton(
                    onClick = onSoloToggle,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = ImageVector.vectorResource(id = R.drawable.ic_solo),
                        contentDescription = "Solo",
                        tint = if (track.isSolo) MaterialTheme.colorScheme.primary else Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            
            // Pan control
            Text(
                text = when {
                    track.pan < 0 -> "L ${(-track.pan * 100).toInt()}%"
                    track.pan > 0 -> "R ${(track.pan * 100).toInt()}%"
                    else -> "C"
                },
                style = MaterialTheme.typography.labelSmall
            )
            
            Slider(
                value = track.pan,
                onValueChange = onPanChange,
                valueRange = -1f..1f,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(24.dp)
            )
            
            // Volume fader
            Box(
                modifier = Modifier
                    .width(28.dp)
                    .height(70.dp)
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.3f))
            ) {
                Slider(
                    value = track.volume,
                    onValueChange = onVolumeChange,
                    valueRange = 0f..1f,
                    modifier = Modifier
                        .width(70.dp)
                        .height(28.dp)
                        .rotate(270f)
                        .offset(y = 21.dp, x = -21.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${(track.volume * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall
                )
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            
            OutlinedButton(
                onClick = onEffectsEdit,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = ImageVector.vectorResource(id = R.drawable.ic_audio_effects),
                    contentDescription = "Edit Effects",
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "FX",
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
fun VolumeSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    // Volume slider with curve for better control
    // (logarithmic mapping for more natural volume control)
    
    val transformedValue = remember(value) {
        // Convert linear slider value (0-1) to logarithmic scale for better volume control
        // This approximates human perceived loudness
        if (value > 0) (kotlin.math.ln(value * 99 + 1) / kotlin.math.ln(100)) else 0f
    }
    
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "${(value * 100).toInt()}%",
            style = MaterialTheme.typography.labelSmall
        )
        
        Box(
            modifier = Modifier
                .width(28.dp)
                .height(100.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color.Black.copy(alpha = 0.3f))
        ) {
            Slider(
                value = transformedValue,
                onValueChange = { newValue ->
                    // Convert back from logarithmic to linear (0-1 range)
                    val linearValue = (kotlin.math.exp(newValue * kotlin.math.ln(100)) - 1) / 99
                    onValueChange(linearValue)
                },
                modifier = Modifier
                    .width(100.dp)
                    .height(28.dp)
                    .rotate(270f)
                    .offset(y = 36.dp, x = -36.dp)
            )
        }
    }
}

@Composable
fun PanKnob(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    // Pan control showing center, left, right position
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = when {
                value < -0.05f -> "L ${(-value * 100).toInt()}%"
                value > 0.05f -> "R ${(value * 100).toInt()}%"
                else -> "C"
            },
            style = MaterialTheme.typography.labelSmall
        )
        
        // Simple pan slider representation
        Slider(
            value = (value + 1f) / 2f, // Convert -1..1 to 0..1 for the slider
            onValueChange = { onValueChange(it * 2f - 1f) },
            valueRange = 0f..1f,
            modifier = Modifier.width(80.dp)
        )
    }
}

@Composable
fun MixerChannelCompact(
    track: Track,
    trackColor: Color,
    onSelect: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    onToggleMute: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    
    Column(
        modifier = modifier
            .width(54.dp)
            .clickable(onClick = onSelect),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Track indicator
        Box(
            modifier = Modifier
                .size(16.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(trackColor)
        )
        
        Spacer(modifier = Modifier.height(2.dp))
        
        // Track name
        Text(
            text = track.name,
            style = MaterialTheme.typography.labelSmall,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 2.dp)
        )
        
        // Fader
        Slider(
            value = track.volume,
            onValueChange = onVolumeChange,
            modifier = Modifier
                .height(80.dp)
                .width(24.dp)
                .rotate(270f)
                .offset(y = 28.dp, x = -28.dp),
            thumbSize = 10.dp
        )
        
        // Expand/collapse button
        IconButton(
            onClick = { expanded = !expanded },
            modifier = Modifier.size(24.dp)
        ) {
            Icon(
                imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                contentDescription = if (expanded) "Collapse" else "Expand",
                modifier = Modifier.size(16.dp)
            )
        }
        
        // Expanded section
        if (expanded) {
            IconButton(
                onClick = onToggleMute,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = ImageVector.vectorResource(id = R.drawable.ic_mute),
                    contentDescription = "Mute",
                    tint = if (track.isMuted) MaterialTheme.colorScheme.primary else Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
