package com.musicdaw.android.model

import java.util.*

/**
 * Represents a music recommendation from the AI recommendation engine
 */
data class MusicRecommendation(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val artist: String,
    val genre: String,
    val similarityScore: Float, // 0.0 to 1.0, how similar to user's style
    val matchingAttributes: List<MatchingAttribute>,
    val previewUrl: String? = null,
    val albumArtUrl: String? = null,
    val releaseDate: Date? = null,
    val sourcePlatform: String? = null, // e.g., "Spotify", "Apple Music"
    val externalUrl: String? = null, // link to the track on external platform
    val recommendation: RecommendationType,
    val description: String? = null,
    val dateRecommended: Date = Date(),
    val userInteracted: Boolean = false, // whether user has interacted with this recommendation
    val userRating: Int = 0, // 0=unrated, 1-5 star rating
    val isPremium: Boolean = false // whether this recommendation needs premium to access fully
)

/**
 * Represents a musical attribute that matched between the user's composition and the recommendation
 */
data class MatchingAttribute(
    val name: String, // e.g., "tempo", "key", "chord progression"
    val value: String, // e.g., "120 BPM", "C minor", "I-IV-V-I"
    val matchStrength: Float, // 0.0 to 1.0
    val description: String? = null
)

/**
 * Represents the type of recommendation
 */
enum class RecommendationType {
    INSPIRATION, // Track might inspire new ideas
    REFERENCE, // Track can be used as a reference for mix/master
    SIMILAR_STYLE, // Track with similar style to user's composition
    LEARNING_RESOURCE, // Educational recommendation to improve user's technique
    TRENDING, // Popular track in the same style
    COMPLEMENTARY, // Track with elements complementary to user's style
    EXPERIMENTAL // Track that pushes boundaries of user's style
}

/**
 * User's musical preference profile built from their compositions
 */
data class UserMusicProfile(
    val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val favoriteGenres: Map<String, Float>, // genre -> weight (0.0 to 1.0)
    val favoriteKeys: Map<String, Float>, // key -> weight
    val tempoPreference: TempoPreference,
    val rhythmComplexity: Float, // 0.0 (simple) to 1.0 (complex)
    val harmonicComplexity: Float, // 0.0 (simple) to 1.0 (complex)
    val melodicTraits: List<String>, // e.g., "stepwise motion", "large intervals"
    val instrumentPreferences: Map<String, Float>, // instrument -> weight
    val productionStyle: Map<String, Float>, // style attribute -> weight
    val creationTimestamps: Map<TimeOfDay, Float>, // when user typically creates music
    val sessionDuration: Float, // average session time in minutes
    val musicalInfluences: List<String>, // inferred musical influences
    val experimentalness: Float, // 0.0 (conventional) to 1.0 (experimental)
    val consistencyScore: Float, // 0.0 (diverse styles) to 1.0 (consistent style)
    val lastUpdated: Date = Date()
)

/**
 * Tempo preference ranges
 */
data class TempoPreference(
    val meanTempo: Float, // average BPM
    val minTempo: Float, // minimum BPM used
    val maxTempo: Float, // maximum BPM used
    val favoriteTempoRanges: List<Pair<Float, Float>> // list of (start, end) tempo ranges
)

/**
 * Time of day periods
 */
enum class TimeOfDay {
    EARLY_MORNING, // 5-8 AM
    MORNING, // 8-11 AM
    MIDDAY, // 11 AM-2 PM
    AFTERNOON, // 2-5 PM
    EVENING, // 5-8 PM
    NIGHT, // 8-11 PM
    LATE_NIGHT // 11 PM-5 AM
}

/**
 * Repository of music recommendation data
 */
class MusicRecommendationRepository {
    /**
     * Get recommendations based on a user's musical profile
     */
    suspend fun getRecommendations(
        userProfile: UserMusicProfile,
        count: Int = 5,
        types: List<RecommendationType>? = null
    ): List<MusicRecommendation> {
        // In a real implementation, this would call to an API
        // For now, we return mock data
        return generateMockRecommendations(userProfile, count, types)
    }
    
    /**
     * Update a user's music profile based on a new project
     */
    suspend fun updateUserProfile(
        currentProfile: UserMusicProfile,
        project: Project
    ): UserMusicProfile {
        // In a real implementation, this would analyze the project
        // and update the user profile accordingly
        return currentProfile
    }
    
    /**
     * Track user interaction with a recommendation
     */
    suspend fun trackInteraction(
        recommendationId: String,
        interactionType: String,
        rating: Int? = null
    ) {
        // In a real implementation, this would send analytics data
        // to improve future recommendations
    }
    
    // For demonstration purposes only
    private fun generateMockRecommendations(
        userProfile: UserMusicProfile,
        count: Int,
        types: List<RecommendationType>?
    ): List<MusicRecommendation> {
        val recommendations = mutableListOf<MusicRecommendation>()
        
        // Filter recommendation types or use all
        val recommendationTypes = types ?: RecommendationType.values().toList()
        
        // Get top genre
        val topGenre = userProfile.favoriteGenres.entries
            .maxByOrNull { it.value }?.key ?: "Electronic"
        
        // Create sample recommendations based on genre and types
        val sampleRecommendations = when (topGenre) {
            "Electronic" -> listOf(
                createRecommendation(
                    "Nova Cascade",
                    "Ethereal Minds",
                    "Electronic",
                    listOf(
                        MatchingAttribute("tempo", "128 BPM", 0.92f),
                        MatchingAttribute("key", "A minor", 0.85f),
                        MatchingAttribute("instruments", "Synthesizers", 0.9f)
                    ),
                    RecommendationType.SIMILAR_STYLE,
                    "This track uses similar synth textures and rhythmic patterns to your recent compositions."
                ),
                createRecommendation(
                    "Digital Horizon",
                    "Byte Shift",
                    "Electronic",
                    listOf(
                        MatchingAttribute("production", "Wide stereo field", 0.88f),
                        MatchingAttribute("melody", "Arpeggiated patterns", 0.78f)
                    ),
                    RecommendationType.INSPIRATION,
                    "The innovative use of arpeggios might inspire new melodic ideas for your tracks."
                )
            )
            
            "Hip-Hop" -> listOf(
                createRecommendation(
                    "Rhythm & Poetry",
                    "Urban Verse",
                    "Hip-Hop",
                    listOf(
                        MatchingAttribute("beat pattern", "Boom bap", 0.94f),
                        MatchingAttribute("tempo", "90 BPM", 0.88f)
                    ),
                    RecommendationType.SIMILAR_STYLE,
                    "Classic boom bap beat structure similar to your recent productions."
                ),
                createRecommendation(
                    "Midnight Flow",
                    "Lyrical Current",
                    "Hip-Hop",
                    listOf(
                        MatchingAttribute("samples", "Jazz samples", 0.86f),
                        MatchingAttribute("bass", "Deep sub bass", 0.91f)
                    ),
                    RecommendationType.REFERENCE,
                    "The bass mixing technique in this track could be a good reference for your productions."
                )
            )
            
            else -> listOf(
                createRecommendation(
                    "Harmonic Convergence",
                    "Tonal Architects",
                    "Contemporary",
                    listOf(
                        MatchingAttribute("chord progression", "ii-V-I variations", 0.89f),
                        MatchingAttribute("arrangement", "Layered complexity", 0.82f)
                    ),
                    RecommendationType.LEARNING_RESOURCE,
                    "Study how this track develops complex chord progressions while maintaining accessibility."
                ),
                createRecommendation(
                    "Rhythmic Patterns",
                    "Pulse Collective",
                    "Fusion",
                    listOf(
                        MatchingAttribute("rhythm", "Polyrhythms", 0.85f),
                        MatchingAttribute("percussion", "Layered percussion", 0.93f)
                    ),
                    RecommendationType.COMPLEMENTARY,
                    "The rhythmic approach here would complement your melodic style nicely."
                )
            )
        }
        
        // Add additional varied recommendations
        val additionalRecommendations = listOf(
            createRecommendation(
                "Sonic Textures",
                "Waveform Theory",
                "Ambient",
                listOf(
                    MatchingAttribute("atmosphere", "Ethereal pads", 0.87f),
                    MatchingAttribute("processing", "Reverb techniques", 0.94f)
                ),
                RecommendationType.EXPERIMENTAL,
                "This track pushes boundaries in sound design while maintaining melodic elements similar to your style."
            ),
            createRecommendation(
                "Structural Dynamics",
                "Form & Function",
                "Instrumental",
                listOf(
                    MatchingAttribute("form", "Non-standard song structure", 0.76f),
                    MatchingAttribute("dynamics", "Dramatic dynamic range", 0.89f)
                ),
                RecommendationType.LEARNING_RESOURCE,
                "Study how this track uses dynamic range to create emotional impact."
            ),
            createRecommendation(
                "Melodic Journey",
                "Interval Exploration",
                "Cinematic",
                listOf(
                    MatchingAttribute("melody", "Thematic development", 0.91f),
                    MatchingAttribute("orchestration", "Layered instrumentation", 0.85f)
                ),
                RecommendationType.INSPIRATION,
                "The melodic development techniques could inspire new approaches to your compositions."
            ),
            createRecommendation(
                "Pulse Wave",
                "Frequency Modulators",
                "Techno",
                listOf(
                    MatchingAttribute("rhythm", "Four-on-the-floor", 0.96f),
                    MatchingAttribute("sounds", "Analog synthesis", 0.88f)
                ),
                RecommendationType.TRENDING,
                "Currently trending track that aligns with your production style."
            )
        )
        
        // Combine all recommendations
        val allRecommendations = (sampleRecommendations + additionalRecommendations)
            .filter { it.recommendation in recommendationTypes }
            .shuffled()
        
        // Return requested number of recommendations
        return allRecommendations.take(count)
    }
    
    private fun createRecommendation(
        title: String,
        artist: String,
        genre: String,
        matchingAttributes: List<MatchingAttribute>,
        recommendationType: RecommendationType,
        description: String
    ): MusicRecommendation {
        return MusicRecommendation(
            title = title,
            artist = artist,
            genre = genre,
            similarityScore = 0.7f + (Math.random() * 0.3).toFloat(),
            matchingAttributes = matchingAttributes,
            previewUrl = "https://musicdaw.com/api/previews/$title".replace(" ", "_").lowercase(),
            albumArtUrl = "https://musicdaw.com/api/covers/$title".replace(" ", "_").lowercase(),
            sourcePlatform = listOf("Spotify", "Apple Music", "TIDAL").random(),
            recommendation = recommendationType,
            description = description
        )
    }
}