package com.musicdaw.android.ai

import com.musicdaw.android.model.*
import kotlin.math.sin
import kotlin.random.Random
import java.util.*

/**
 * Generator yang menghasilkan proyek, pattern, dan sampel berdasarkan genre spesifik
 */
class GenreBasedGenerator(
    private val genreSpecialist: GenreSpecialistAI = GenreSpecialistAI()
) {
    /**
     * Menghasilkan proyek baru berdasarkan genre yang dipilih
     */
    fun generateProject(genreName: String, projectName: String): Project {
        // Dapatkan karakteristik genre
        val characteristics = genreSpecialist.getGenreCharacteristics(genreName)
        
        // Buat track sesuai dengan karakteristik genre
        val tracks = mutableListOf<Track>()
        
        // 1. Tambahkan track drum
        tracks.add(createDrumTrack(characteristics))
        
        // 2. Tambahkan track bass
        tracks.add(createBassTrack(characteristics))
        
        // 3. Tambahkan track melodi utama
        tracks.add(createLeadTrack(characteristics))
        
        // 4. Tambahkan track perkusi sesuai genre
        characteristics.percussionElements.forEachIndexed { index, element ->
            if (index < 2) { // Batasi jumlah track perkusi
                tracks.add(createPercussionTrack(element, characteristics, index))
            }
        }
        
        // 5. Tambahkan track khusus genre (jika ada)
        val specialTrack = createSpecialTrackForGenre(genreName, characteristics)
        if (specialTrack != null) {
            tracks.add(specialTrack)
        }
        
        // Buat marker untuk struktur lagu
        val markers = createSongStructureMarkers()
        
        // Buat proyek dengan parameter yang sesuai
        return Project(
            name = projectName,
            tempo = characteristics.tempo,
            timeSignatureNumerator = 4,
            timeSignatureDenominator = 4,
            tracks = tracks,
            markers = markers,
            key = determineKeyForGenre(genreName),
            duration = 32f // 32 detik (8 bar @ 120 BPM)
        ).calculateDuration()
    }
    
    /**
     * Membuat track drum untuk genre tertentu
     */
    private fun createDrumTrack(characteristics: GenreCharacteristics): Track {
        // Buat pola drum berdasarkan jenis genre
        val drumPattern = when (characteristics.drumPattern) {
            DrumPattern.BANTENGAN_BEAT -> createBantenganDrumPattern()
            DrumPattern.NROTOK_PATTERN -> createNrotokDrumPattern()
            DrumPattern.KOPLO_KENDANG -> createKoploKendangPattern()
            DrumPattern.DANGDUT_GROOVE -> createDangdutGroovePattern()
            DrumPattern.TRAP_HIHAT -> createTrapHiHatPattern()
            DrumPattern.EDM_BUILDUP -> createEdmBuildupPattern()
            else -> createBasicDrumPattern()
        }
        
        // Buat track drum dengan pola yang sesuai
        return Track(
            name = "Drum Kit",
            type = TrackType.MIDI,
            isDrumTrack = true,
            color = 0xFFFF5722.toInt(), // Orange
            midiPatterns = listOf(drumPattern),
            volume = 0.8f
        )
    }
    
    /**
     * Membuat track bass untuk genre tertentu
     */
    private fun createBassTrack(characteristics: GenreCharacteristics): Track {
        // Buat pola bass berdasarkan jenis genre
        val bassPattern = when (characteristics.bassPattern) {
            BassPattern.BANTENGAN_STYLE -> createBantenganBassPattern()
            BassPattern.HEAVY_DROP -> createHeavyDropBassPattern()
            BassPattern.TRAP_808 -> createTrap808BassPattern()
            BassPattern.FOUR_ON_FLOOR -> createFourOnFloorBassPattern()
            BassPattern.STEADY_RHYTHMIC -> createSteadyRhythmicBassPattern()
            BassPattern.MELODIC_BASS -> createMelodicBassPattern()
            else -> createStandardBassPattern()
        }
        
        // Tambahkan efek yang sesuai dengan genre
        val bassEffects = listOf(
            Effect(
                name = "Bass EQ",
                type = "eq",
                settings = mapOf(
                    "low" to 0.8f,
                    "mid" to 0.5f,
                    "high" to 0.3f,
                    "low_freq" to characteristics.bassFrequency / 500f // Normalize to 0-1 range
                )
            ),
            Effect(
                name = "Bass Compressor",
                type = "compressor",
                settings = mapOf(
                    "threshold" to 0.6f,
                    "ratio" to 0.7f,
                    "attack" to 0.1f,
                    "release" to 0.4f,
                    "gain" to 0.6f
                )
            )
        )
        
        // Buat track bass dengan pola dan efek yang sesuai
        return Track(
            name = "Bass",
            type = TrackType.MIDI,
            color = 0xFF2196F3.toInt(), // Blue
            midiPatterns = listOf(bassPattern),
            effects = bassEffects,
            volume = 0.75f,
            instrument = Instrument(
                name = "Bass Synth",
                type = "synth",
                parameters = mapOf(
                    "cutoff" to 0.4f,
                    "resonance" to 0.3f,
                    "attack" to 0.1f,
                    "decay" to 0.3f,
                    "sustain" to 0.8f,
                    "release" to 0.5f
                )
            )
        )
    }
    
    /**
     * Membuat track melodi utama untuk genre tertentu
     */
    private fun createLeadTrack(characteristics: GenreCharacteristics): Track {
        // Tentukan pola melodi berdasarkan scale preference
        val leadPattern = when (characteristics.scalePreference) {
            "pelog" -> createPelogMelodicPattern()
            "slendro" -> createSlendroMelodicPattern()
            "arabic" -> createArabicMelodicPattern()
            "minor" -> createMinorMelodicPattern()
            "major" -> createMajorMelodicPattern()
            else -> createDiatonicMelodicPattern()
        }
        
        // Buat track melodi dengan pola yang sesuai
        return Track(
            name = "Lead Melody",
            type = TrackType.MIDI,
            color = 0xFF9C27B0.toInt(), // Purple
            midiPatterns = listOf(leadPattern),
            volume = 0.7f,
            effects = listOf(
                Effect(
                    name = "Lead Reverb",
                    type = "reverb",
                    settings = mapOf(
                        "mix" to 0.4f,
                        "decay" to 0.5f,
                        "predelay" to 0.1f,
                        "size" to 0.6f,
                        "damping" to 0.5f
                    )
                ),
                Effect(
                    name = "Lead Delay",
                    type = "delay",
                    settings = mapOf(
                        "time" to 0.3f,
                        "feedback" to 0.3f,
                        "mix" to 0.25f
                    )
                )
            ),
            instrument = Instrument(
                name = "Lead Synth",
                type = "synth",
                parameters = mapOf(
                    "cutoff" to 0.7f,
                    "resonance" to 0.4f,
                    "attack" to 0.05f,
                    "decay" to 0.2f,
                    "sustain" to 0.7f,
                    "release" to 0.4f
                )
            )
        )
    }
    
    /**
     * Membuat track perkusi untuk elemen tertentu
     */
    private fun createPercussionTrack(element: String, characteristics: GenreCharacteristics, index: Int): Track {
        // Buat audio clip berdasarkan elemen perkusi
        val sampleFileName = "${element.capitalize()}_Sample.wav"
        
        // Buat audio clip dengan pola berbeda berdasarkan indeks
        val clips = if (index == 0) {
            listOf(
                AudioClip(
                    name = element.capitalize(),
                    filePath = "/samples/percussion/$sampleFileName",
                    startTime = 0f,
                    duration = 4f,
                    isLooping = true,
                    loopCount = 8
                )
            )
        } else {
            listOf(
                AudioClip(
                    name = element.capitalize(),
                    filePath = "/samples/percussion/$sampleFileName",
                    startTime = 1f,
                    duration = 2f,
                    isLooping = true,
                    loopCount = 16
                )
            )
        }
        
        // Buat track perkusi dengan audio clip yang sesuai
        return Track(
            name = element.capitalize(),
            type = TrackType.AUDIO,
            color = 0xFF4CAF50.toInt() + (index * 100), // Green variants
            audioClips = clips,
            volume = 0.6f
        )
    }
    
    /**
     * Membuat track khusus untuk genre tertentu
     */
    private fun createSpecialTrackForGenre(genreName: String, characteristics: GenreCharacteristics): Track? {
        return when (genreName.toLowerCase()) {
            "dj bantengan" -> {
                // Track gamelan khusus untuk DJ Bantengan
                Track(
                    name = "Gamelan Accent",
                    type = TrackType.AUDIO,
                    color = 0xFFFFEB3B.toInt(), // Yellow
                    audioClips = listOf(
                        AudioClip(
                            name = "Gong Accent",
                            filePath = "/samples/gamelan/Gong_Ageng.wav",
                            startTime = 0f,
                            duration = 2f,
                            isLooping = false
                        ),
                        AudioClip(
                            name = "Kempul Ornament",
                            filePath = "/samples/gamelan/Kempul_Fill.wav",
                            startTime = 4f,
                            duration = 1f,
                            isLooping = false
                        ),
                        AudioClip(
                            name = "Bonang Pattern",
                            filePath = "/samples/gamelan/Bonang_Pattern.wav",
                            startTime = 8f,
                            duration = 4f,
                            isLooping = true,
                            loopCount = 4
                        )
                    ),
                    volume = 0.75f,
                    effects = listOf(
                        Effect(
                            name = "Gamelan Reverb",
                            type = "reverb",
                            settings = mapOf(
                                "mix" to 0.6f,
                                "decay" to 0.7f,
                                "predelay" to 0.1f,
                                "size" to 0.9f,
                                "damping" to 0.3f
                            )
                        )
                    )
                )
            }
            
            "dj nrotok" -> {
                // Track vokal khusus untuk DJ Nrotok
                Track(
                    name = "Vocal Chops",
                    type = TrackType.AUDIO,
                    color = 0xFFF44336.toInt(), // Red
                    audioClips = listOf(
                        AudioClip(
                            name = "Vocal Chant",
                            filePath = "/samples/vocals/Nrotok_Vocal_Chant.wav",
                            startTime = 2f,
                            duration = 1f,
                            isLooping = true,
                            loopCount = 8
                        ),
                        AudioClip(
                            name = "Vocal Phrase",
                            filePath = "/samples/vocals/Nrotok_Vocal_Phrase.wav",
                            startTime = 16f,
                            duration = 2f,
                            isLooping = false
                        )
                    ),
                    volume = 0.7f,
                    effects = listOf(
                        Effect(
                            name = "Vocal Delay",
                            type = "delay",
                            settings = mapOf(
                                "time" to 0.125f,
                                "feedback" to 0.6f,
                                "mix" to 0.4f
                            )
                        ),
                        Effect(
                            name = "Vocal Filter",
                            type = "filter",
                            settings = mapOf(
                                "cutoff" to 0.7f,
                                "resonance" to 0.5f,
                                "type" to 0.0f // 0.0 = lowpass
                            )
                        )
                    )
                )
            }
            
            else -> null
        }
    }
    
    /**
     * Membuat marker untuk struktur lagu
     */
    private fun createSongStructureMarkers(): List<Marker> {
        return listOf(
            Marker(name = "Intro", position = 0f),
            Marker(name = "Buildup", position = 8f),
            Marker(name = "Drop", position = 16f),
            Marker(name = "Breakdown", position = 24f)
        )
    }
    
    /**
     * Menentukan kunci musik yang sesuai untuk genre
     */
    private fun determineKeyForGenre(genreName: String): String {
        return when (genreName.toLowerCase()) {
            "dj bantengan" -> "A Minor" // Cocok dengan skala pelog
            "dj nrotok" -> "G Minor"    // Memberikan nuansa energik
            "koplo" -> "C Major"        // Bright, energik
            "dangdut" -> "D Minor"      // Nuansa Timur Tengah
            "trap" -> "F Minor"         // Gelap, menekan
            "edm" -> "A Major"          // Cerah, enerjik
            else -> "C Major"           // Default
        }
    }
    
    // =========== DRUM PATTERN GENERATORS ===========
    
    private fun createBantenganDrumPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Kick pattern (note 36)
        for (i in 0 until 16 step 4) {
            notes.add(MidiNote(note = 36, startTime = i/4f, duration = 0.25f, velocity = 100))
        }
        notes.add(MidiNote(note = 36, startTime = 2.5f, duration = 0.25f, velocity = 90))
        
        // Snare pattern (note 38) - syncopated
        for (i in 0 until 16 step 8) {
            notes.add(MidiNote(note = 38, startTime = (i + 4)/4f, duration = 0.25f, velocity = 90))
        }
        notes.add(MidiNote(note = 38, startTime = 3.5f, duration = 0.25f, velocity = 85))
        
        // Hi-hat pattern (note 42) - rapid, energetic
        for (i in 0 until 32) {
            val velocity = if (i % 2 == 0) 80 else 60
            notes.add(MidiNote(note = 42, startTime = i/8f, duration = 0.1f, velocity = velocity))
        }
        
        // Tom fills (notes 45, 47, 50)
        notes.add(MidiNote(note = 45, startTime = 3.75f, duration = 0.1f, velocity = 85))
        notes.add(MidiNote(note = 47, startTime = 3.875f, duration = 0.1f, velocity = 85))
        notes.add(MidiNote(note = 50, startTime = 4.0f, duration = 0.1f, velocity = 90))
        
        return MidiPattern(
            name = "Bantengan Beat",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createNrotokDrumPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Very intense kick pattern (note 36)
        for (i in 0 until 16) {
            if (i % 4 == 0 || i % 8 == 6) { // Downbeats and syncopated accent
                notes.add(MidiNote(note = 36, startTime = i/4f, duration = 0.25f, velocity = 110))
            }
        }
        
        // Snare pattern (note 38) - fast and energetic
        for (i in 0 until 16) {
            if (i % 4 == 2 || i % 8 == 7) {
                notes.add(MidiNote(note = 38, startTime = i/4f, duration = 0.25f, 
                                 velocity = if (i % 4 == 2) 95 else 85))
            }
        }
        
        // Hi-hat pattern (note 42) - extremely rapid
        for (i in 0 until 64) {
            val velocity = if (i % 4 == 0) 90 else if (i % 2 == 0) 70 else 50
            notes.add(MidiNote(note = 42, startTime = i/16f, duration = 0.05f, velocity = velocity))
        }
        
        // Crash accents (note 49)
        notes.add(MidiNote(note = 49, startTime = 0.0f, duration = 0.5f, velocity = 100))
        notes.add(MidiNote(note = 49, startTime = 2.0f, duration = 0.5f, velocity = 90))
        
        return MidiPattern(
            name = "Nrotok Beat",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createKoploKendangPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Kendang base pattern (custom mapping: 36=low, 38=mid, 40=high)
        // Characteristic "tak-dung-tak-dung" pattern with fillers
        val kendangPattern = listOf(
            Pair(36, 0.0f), // dung
            Pair(40, 0.25f), // tak
            Pair(38, 0.5f), // mid
            Pair(40, 0.75f), // tak
            Pair(36, 1.0f), // dung
            Pair(40, 1.25f), // tak
            Pair(38, 1.5f), // mid
            Pair(38, 1.75f), // mid
            
            Pair(36, 2.0f), // dung
            Pair(40, 2.25f), // tak
            Pair(38, 2.5f), // mid
            Pair(40, 2.75f), // tak
            Pair(36, 3.0f), // dung
            Pair(40, 3.25f), // tak
            Pair(38, 3.375f), // mid (filler)
            Pair(40, 3.5f), // tak
            Pair(38, 3.625f), // mid (filler)
            Pair(40, 3.75f), // tak
            Pair(38, 3.875f)  // mid (filler)
        )
        
        // Add kendang notes
        for (note in kendangPattern) {
            notes.add(MidiNote(
                note = note.first,
                startTime = note.second,
                duration = 0.125f,
                velocity = if (note.first == 36) 100 else if (note.first == 40) 90 else 85
            ))
        }
        
        // Add hi-hat-like sounds (note 42)
        for (i in 0 until 16) {
            notes.add(MidiNote(note = 42, startTime = i/4f, duration = 0.1f, velocity = if (i % 2 == 0) 80 else 60))
        }
        
        return MidiPattern(
            name = "Koplo Kendang",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createDangdutGroovePattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Ketipung/tabla pattern (custom mapping: 36=low, 37=dum, 38=tak, 39=slap)
        val ketipungPattern = listOf(
            Pair(37, 0.0f),   // dum
            Pair(38, 0.5f),   // tak
            Pair(37, 1.0f),   // dum
            Pair(38, 1.5f),   // tak
            
            Pair(37, 2.0f),   // dum
            Pair(38, 2.5f),   // tak
            Pair(39, 2.75f),  // slap (ornament)
            Pair(37, 3.0f),   // dum
            Pair(38, 3.5f),   // tak
            Pair(39, 3.75f)   // slap (ornament)
        )
        
        // Add ketipung/tabla notes
        for (note in ketipungPattern) {
            notes.add(MidiNote(
                note = note.first,
                startTime = note.second,
                duration = 0.25f,
                velocity = if (note.first == 39) 85 else if (note.first == 37) 95 else 90
            ))
        }
        
        // Add tambourine/percussion accents (note 54)
        for (i in 0 until 8) {
            notes.add(MidiNote(note = 54, startTime = i/2f, duration = 0.1f, velocity = 70))
        }
        
        // Add cymbals for emphasis (note 49)
        notes.add(MidiNote(note = 49, startTime = 0.0f, duration = 0.5f, velocity = 85))
        notes.add(MidiNote(note = 49, startTime = 2.0f, duration = 0.5f, velocity = 85))
        
        return MidiPattern(
            name = "Dangdut Groove",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createTrapHiHatPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // 808 kick pattern (note 36)
        notes.add(MidiNote(note = 36, startTime = 0.0f, duration = 0.5f, velocity = 110))
        notes.add(MidiNote(note = 36, startTime = 1.0f, duration = 0.5f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 2.0f, duration = 0.5f, velocity = 110))
        notes.add(MidiNote(note = 36, startTime = 3.0f, duration = 0.5f, velocity = 100))
        
        // Snare pattern (note 38)
        notes.add(MidiNote(note = 38, startTime = 1.0f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 38, startTime = 3.0f, duration = 0.25f, velocity = 90))
        
        // Hi-hat pattern (note 42) - trademark trap triplets and rolls
        // 16th notes
        for (i in 0 until 16) {
            if (i % 4 != 1) { // Skip certain positions for rhythm
                notes.add(MidiNote(note = 42, startTime = i/4f, duration = 0.1f, 
                                 velocity = if (i % 4 == 0) 85 else 70))
            }
        }
        
        // Triplet hi-hats
        for (i in 0 until 3) {
            val startTime = 1.0f + (i / 6.0f)
            notes.add(MidiNote(note = 42, startTime = startTime, duration = 0.1f, velocity = 75))
        }
        
        for (i in 0 until 3) {
            val startTime = 3.0f + (i / 6.0f)
            notes.add(MidiNote(note = 42, startTime = startTime, duration = 0.1f, velocity = 75))
        }
        
        // Hi-hat rolls (32nd notes)
        for (i in 0 until 8) {
            val startTime = 2.5f + (i / 16.0f)
            notes.add(MidiNote(note = 42, startTime = startTime, duration = 0.05f, velocity = 65))
        }
        
        return MidiPattern(
            name = "Trap Beat",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createEdmBuildupPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Four-on-the-floor kick pattern (note 36)
        for (i in 0 until 4) {
            notes.add(MidiNote(note = 36, startTime = i.toFloat(), duration = 0.25f, velocity = 100))
        }
        
        // Clap/snare on the offbeats (note 39)
        for (i in 0 until 2) {
            notes.add(MidiNote(note = 39, startTime = 1.0f + (i * 2), duration = 0.25f, velocity = 90))
        }
        
        // Open hi-hat (note 46) on offbeats
        for (i in 0 until 4) {
            notes.add(MidiNote(note = 46, startTime = 0.5f + i.toFloat(), duration = 0.25f, velocity = 80))
        }
        
        // 16th note hi-hats (note 42)
        for (i in 0 until 16) {
            notes.add(MidiNote(note = 42, startTime = i/4f, duration = 0.1f, 
                             velocity = if (i % 4 == 0) 85 else if (i % 2 == 0) 75 else 65))
        }
        
        // Crash during the last beat for transition (note 49)
        notes.add(MidiNote(note = 49, startTime = 3.0f, duration = 1.0f, velocity = 100))
        
        // Rising toms for buildup effect (notes 45, 47, 50)
        notes.add(MidiNote(note = 45, startTime = 2.0f, duration = 0.25f, velocity = 85))
        notes.add(MidiNote(note = 47, startTime = 2.5f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 50, startTime = 3.0f, duration = 0.25f, velocity = 95))
        notes.add(MidiNote(note = 50, startTime = 3.5f, duration = 0.25f, velocity = 100))
        
        return MidiPattern(
            name = "EDM Buildup",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createBasicDrumPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Basic kick pattern (note 36)
        notes.add(MidiNote(note = 36, startTime = 0.0f, duration = 0.25f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 1.0f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 36, startTime = 2.0f, duration = 0.25f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 3.0f, duration = 0.25f, velocity = 90))
        
        // Basic snare pattern (note 38)
        notes.add(MidiNote(note = 38, startTime = 1.0f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 38, startTime = 3.0f, duration = 0.25f, velocity = 90))
        
        // Basic hi-hat pattern (note 42)
        for (i in 0 until 8) {
            notes.add(MidiNote(note = 42, startTime = i/2f, duration = 0.25f, velocity = 80))
        }
        
        return MidiPattern(
            name = "Basic Beat",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    // =========== BASS PATTERN GENERATORS ===========
    
    private fun createBantenganBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Root note (A1 = 33) with energetic rhythm
        notes.add(MidiNote(note = 33, startTime = 0.0f, duration = 0.5f, velocity = 100))
        notes.add(MidiNote(note = 33, startTime = 1.0f, duration = 0.25f, velocity = 95))
        notes.add(MidiNote(note = 33, startTime = 1.5f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 33, startTime = 2.0f, duration = 0.5f, velocity = 100))
        notes.add(MidiNote(note = 33, startTime = 3.0f, duration = 0.25f, velocity = 95))
        notes.add(MidiNote(note = 33, startTime = 3.5f, duration = 0.25f, velocity = 90))
        
        // Fifth accent (E1 = 40)
        notes.add(MidiNote(note = 40, startTime = 1.75f, duration = 0.25f, velocity = 85))
        notes.add(MidiNote(note = 40, startTime = 3.75f, duration = 0.25f, velocity = 85))
        
        return MidiPattern(
            name = "Bantengan Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createHeavyDropBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Root note (G0 = 31) with heavy rhythm
        notes.add(MidiNote(note = 31, startTime = 0.0f, duration = 0.5f, velocity = 110))
        notes.add(MidiNote(note = 31, startTime = 1.0f, duration = 0.5f, velocity = 100))
        
        // "Drop" effect with sliding bass
        notes.add(MidiNote(note = 31, startTime = 2.0f, duration = 0.125f, velocity = 110))
        notes.add(MidiNote(note = 29, startTime = 2.125f, duration = 0.125f, velocity = 105))
        notes.add(MidiNote(note = 27, startTime = 2.25f, duration = 0.125f, velocity = 100))
        notes.add(MidiNote(note = 26, startTime = 2.375f, duration = 0.125f, velocity = 105))
        notes.add(MidiNote(note = 24, startTime = 2.5f, duration = 0.25f, velocity = 110))
        notes.add(MidiNote(note = 24, startTime = 3.0f, duration = 0.5f, velocity = 110))
        notes.add(MidiNote(note = 24, startTime = 3.5f, duration = 0.25f, velocity = 100))
        notes.add(MidiNote(note = 26, startTime = 3.75f, duration = 0.25f, velocity = 100))
        
        return MidiPattern(
            name = "Heavy Drop Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createTrap808BassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // 808-style bass with slides and long sustained notes
        notes.add(MidiNote(note = 36, startTime = 0.0f, duration = 0.75f, velocity = 110))
        notes.add(MidiNote(note = 36, startTime = 1.0f, duration = 0.5f, velocity = 100))
        
        // Sliding effect
        notes.add(MidiNote(note = 36, startTime = 2.0f, duration = 0.1f, velocity = 110))
        notes.add(MidiNote(note = 35, startTime = 2.1f, duration = 0.1f, velocity = 105))
        notes.add(MidiNote(note = 34, startTime = 2.2f, duration = 0.1f, velocity = 100))
        notes.add(MidiNote(note = 32, startTime = 2.3f, duration = 0.8f, velocity = 105))
        
        notes.add(MidiNote(note = 36, startTime = 3.25f, duration = 0.75f, velocity = 100))
        
        return MidiPattern(
            name = "Trap 808 Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createFourOnFloorBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Classic four-on-the-floor bass pattern
        for (i in 0 until 4) {
            notes.add(MidiNote(note = 36, startTime = i.toFloat(), duration = 0.5f, velocity = 100))
        }
        
        // Add some variation on the offbeats
        notes.add(MidiNote(note = 38, startTime = 1.5f, duration = 0.25f, velocity = 85))
        notes.add(MidiNote(note = 38, startTime = 3.5f, duration = 0.25f, velocity = 85))
        
        return MidiPattern(
            name = "Four On Floor Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createSteadyRhythmicBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Steady rhythmic pattern with some syncopation
        notes.add(MidiNote(note = 36, startTime = 0.0f, duration = 0.25f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 0.5f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 36, startTime = 1.0f, duration = 0.25f, velocity = 95))
        notes.add(MidiNote(note = 36, startTime = 1.5f, duration = 0.25f, velocity = 90))
        
        notes.add(MidiNote(note = 36, startTime = 2.0f, duration = 0.25f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 2.5f, duration = 0.25f, velocity = 90))
        notes.add(MidiNote(note = 36, startTime = 3.0f, duration = 0.25f, velocity = 95))
        notes.add(MidiNote(note = 36, startTime = 3.5f, duration = 0.125f, velocity = 90))
        notes.add(MidiNote(note = 36, startTime = 3.75f, duration = 0.125f, velocity = 90))
        
        return MidiPattern(
            name = "Steady Rhythmic Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createMelodicBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Melodic bass line
        val bassLine = listOf(
            Pair(36, 0.0f),   // Root
            Pair(36, 0.5f),   // Root
            Pair(40, 1.0f),   // Fifth
            Pair(38, 1.5f),   // Third
            
            Pair(36, 2.0f),   // Root
            Pair(36, 2.5f),   // Root
            Pair(41, 3.0f),   // Sixth
            Pair(43, 3.5f)    // Seventh
        )
        
        for (note in bassLine) {
            notes.add(MidiNote(
                note = note.first,
                startTime = note.second,
                duration = 0.4f,
                velocity = if (note.second.toInt() % 2 == 0) 95 else 85
            ))
        }
        
        return MidiPattern(
            name = "Melodic Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createStandardBassPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Standard bass pattern (root-fifth)
        notes.add(MidiNote(note = 36, startTime = 0.0f, duration = 0.5f, velocity = 100))
        notes.add(MidiNote(note = 36, startTime = 1.0f, duration = 0.5f, velocity = 90))
        notes.add(MidiNote(note = 43, startTime = 2.0f, duration = 0.5f, velocity = 95)) // Fifth
        notes.add(MidiNote(note = 36, startTime = 3.0f, duration = 0.5f, velocity = 90))
        
        return MidiPattern(
            name = "Standard Bass",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    // =========== MELODIC PATTERN GENERATORS ===========
    
    private fun createPelogMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Pelog scale approximation (A minor with adjusted notes)
        // A(57) B(59) C(60) E(64) F#(66) G#(68) B(71)
        val pelogScale = listOf(57, 59, 60, 64, 66, 68, 71)
        
        // Create a melodic pattern using the scale
        val melodicSequence = listOf(
            Pair(0, 0.0f),    // A
            Pair(2, 0.5f),    // C
            Pair(0, 1.0f),    // A
            Pair(3, 1.5f),    // E
            
            Pair(4, 2.0f),    // F#
            Pair(3, 2.5f),    // E
            Pair(2, 3.0f),    // C
            Pair(0, 3.5f)     // A
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = pelogScale[note.first], 
                startTime = note.second,
                duration = 0.4f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Pelog Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createSlendroMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Slendro scale approximation (pentatonic-like)
        // G(55) A(57) C(60) D(62) E(64)
        val slendroScale = listOf(55, 57, 60, 62, 64, 67, 69)
        
        // Create a melodic pattern using the scale
        val melodicSequence = listOf(
            Pair(1, 0.0f),    // A
            Pair(2, 0.5f),    // C
            Pair(4, 1.0f),    // E
            Pair(2, 1.5f),    // C
            
            Pair(1, 2.0f),    // A
            Pair(0, 2.5f),    // G
            Pair(1, 3.0f),    // A
            Pair(3, 3.5f)     // D
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = slendroScale[note.first], 
                startTime = note.second,
                duration = 0.4f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Slendro Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createArabicMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // Arabic scale approximation (D harmonic minor with some adjustments)
        // D(62) E(64) F(65) G#(68) A(69) Bb(70) C#(73) D(74)
        val arabicScale = listOf(62, 64, 65, 68, 69, 70, 73, 74)
        
        // Create a melodic pattern using the scale
        val melodicSequence = listOf(
            Pair(0, 0.0f),    // D
            Pair(1, 0.5f),    // E
            Pair(2, 0.75f),   // F
            Pair(4, 1.0f),    // A
            Pair(3, 1.5f),    // G#
            Pair(2, 1.75f),   // F
            
            Pair(1, 2.0f),    // E
            Pair(2, 2.25f),   // F
            Pair(3, 2.5f),    // G#
            Pair(4, 2.75f),   // A
            Pair(5, 3.0f),    // Bb
            Pair(4, 3.25f),   // A
            Pair(3, 3.5f),    // G#
            Pair(1, 3.75f)    // E
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = arabicScale[note.first], 
                startTime = note.second,
                duration = 0.2f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Arabic Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createMinorMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // F minor scale
        // F(65) G(67) Ab(68) Bb(70) C(72) Db(73) Eb(75) F(77)
        val minorScale = listOf(65, 67, 68, 70, 72, 73, 75, 77)
        
        // Create a trap-like melody
        val melodicSequence = listOf(
            Pair(0, 0.0f),    // F
            Pair(0, 0.5f),    // F
            Pair(2, 1.0f),    // Ab
            Pair(0, 1.5f),    // F
            
            Pair(3, 2.0f),    // Bb
            Pair(2, 2.5f),    // Ab
            Pair(0, 3.0f),    // F
            Pair(4, 3.5f)     // C
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = minorScale[note.first], 
                startTime = note.second,
                duration = 0.4f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Minor Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createMajorMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // A major scale
        // A(69) B(71) C#(73) D(74) E(76) F#(78) G#(80) A(81)
        val majorScale = listOf(69, 71, 73, 74, 76, 78, 80, 81)
        
        // Create an uplifting EDM-style melody
        val melodicSequence = listOf(
            Pair(0, 0.0f),    // A
            Pair(2, 0.5f),    // C#
            Pair(4, 1.0f),    // E
            Pair(4, 1.5f),    // E
            
            Pair(2, 2.0f),    // C#
            Pair(4, 2.5f),    // E
            Pair(5, 3.0f),    // F#
            Pair(4, 3.5f)     // E
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = majorScale[note.first], 
                startTime = note.second,
                duration = 0.4f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Major Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun createDiatonicMelodicPattern(): MidiPattern {
        val notes = mutableListOf<MidiNote>()
        
        // C major scale
        // C(60) D(62) E(64) F(65) G(67) A(69) B(71) C(72)
        val majorScale = listOf(60, 62, 64, 65, 67, 69, 71, 72)
        
        // Create a simple melody
        val melodicSequence = listOf(
            Pair(0, 0.0f),    // C
            Pair(2, 0.5f),    // E
            Pair(4, 1.0f),    // G
            Pair(2, 1.5f),    // E
            
            Pair(4, 2.0f),    // G
            Pair(5, 2.5f),    // A
            Pair(4, 3.0f),    // G
            Pair(2, 3.5f)     // E
        )
        
        for (note in melodicSequence) {
            notes.add(MidiNote(
                note = majorScale[note.first], 
                startTime = note.second,
                duration = 0.4f,
                velocity = 85
            ))
        }
        
        return MidiPattern(
            name = "Diatonic Melody",
            notes = notes,
            duration = 4.0f,
            isLooping = true,
            loopCount = 8
        )
    }
    
    private fun String.capitalize(): String {
        return this.replaceFirstChar { 
            if (it.isLowerCase()) it.titlecase() else it.toString() 
        }
    }
}