package com.musicdaw.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.musicdaw.android.model.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun RecommendationScreen(
    currentProject: Project?
) {
    // ViewModel
    val viewModel = remember { RecommendationViewModel() }
    
    // Collect states from ViewModel
    val uiState by viewModel.uiState.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val recommendations by viewModel.recommendations.collectAsState()
    val selectedFilterTypes by viewModel.selectedFilterTypes.collectAsState()
    val currentlyPlayingId by viewModel.currentlyPlayingId.collectAsState()
    
    // Local UI states
    var selectedRecommendation by remember { mutableStateOf<MusicRecommendation?>(null) }
    var showFilterDialog by remember { mutableStateOf(false) }
    
    // Analyze current project on first load
    LaunchedEffect(currentProject) {
        currentProject?.let {
            viewModel.analyzeProject(it)
        }
    }
    
    val coroutineScope = rememberCoroutineScope()
    
    // Loading state
    val isLoading = uiState is RecommendationUiState.Loading
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // App bar
        TopAppBar(
            title = {
                Text(
                    text = "AI Music Recommendations",
                    fontWeight = FontWeight.Bold
                )
            },
            backgroundColor = MaterialTheme.colors.primarySurface,
            actions = {
                // Filter button
                IconButton(onClick = { showFilterDialog = true }) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = "Filter"
                    )
                }
                
                // Refresh button
                IconButton(onClick = { viewModel.refreshRecommendations() }) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh"
                    )
                }
            }
        )
        
        // Profile overview
        UserProfileOverview(userProfile = userProfile)
        
        // Recommendations section
        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            if (isLoading) {
                // Loading indicator
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (recommendations.isEmpty()) {
                // Empty state
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = "No recommendations",
                        modifier = Modifier.size(64.dp),
                        tint = Color.Gray
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text(
                        text = "No recommendations found",
                        style = MaterialTheme.typography.h6,
                        color = Color.Gray
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "Create more music to improve your recommendations",
                        style = MaterialTheme.typography.body1,
                        color = Color.Gray
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Button(onClick = { refreshTrigger++ }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh"
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Refresh")
                    }
                }
            } else {
                // Recommendation list
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    items(recommendations) { recommendation ->
                        RecommendationItem(
                            recommendation = recommendation,
                            onClick = {
                                selectedRecommendation = recommendation
                            }
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                    
                    item {
                        Spacer(modifier = Modifier.height(32.dp))
                    }
                }
            }
        }
    }
    
    // Filter dialog
    if (showFilterDialog) {
        RecommendationFilterDialog(
            selectedTypes = selectedFilterTypes,
            onTypesSelected = { selectedFilterTypes = it },
            onDismiss = { showFilterDialog = false },
            onApply = {
                showFilterDialog = false
                refreshTrigger++
            }
        )
    }
    
    // Detail dialog
    selectedRecommendation?.let { recommendation ->
        RecommendationDetailDialog(
            recommendation = recommendation,
            isPlaying = isPlayingPreview,
            onPlayPause = { isPlayingPreview = !isPlayingPreview },
            onDismiss = { selectedRecommendation = null },
            onRate = { rating ->
                // In a real app, submit the rating to the backend
                coroutineScope.launch {
                    repository.trackInteraction(
                        recommendationId = recommendation.id,
                        interactionType = "rating",
                        rating = rating
                    )
                }
            }
        )
    }
}

@Composable
fun UserProfileOverview(userProfile: UserMusicProfile) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        elevation = 4.dp,
        backgroundColor = MaterialTheme.colors.surface
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Your Music Profile",
                style = MaterialTheme.typography.h6,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Top genres
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = "Genres",
                    tint = MaterialTheme.colors.primary,
                    modifier = Modifier.size(20.dp)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "Top Genres: ",
                    fontWeight = FontWeight.Medium
                )
                
                Text(
                    text = userProfile.favoriteGenres.entries
                        .sortedByDescending { it.value }
                        .take(3)
                        .joinToString(", ") { it.key },
                    style = MaterialTheme.typography.body2
                )
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            
            // Tempo preference
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Speed,
                    contentDescription = "Tempo",
                    tint = MaterialTheme.colors.primary,
                    modifier = Modifier.size(20.dp)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "Preferred Tempo: ",
                    fontWeight = FontWeight.Medium
                )
                
                Text(
                    text = "${userProfile.tempoPreference.meanTempo.toInt()} BPM",
                    style = MaterialTheme.typography.body2
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Style complexity
            val complexityText = when {
                userProfile.harmonicComplexity > 0.7f -> "Complex"
                userProfile.harmonicComplexity > 0.4f -> "Moderate"
                else -> "Simple"
            }
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Complexity",
                    tint = MaterialTheme.colors.primary,
                    modifier = Modifier.size(20.dp)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "Style: ",
                    fontWeight = FontWeight.Medium
                )
                
                Text(
                    text = "$complexityText harmonies, " +
                           "${if (userProfile.experimentalness > 0.5f) "Experimental" else "Traditional"} approach",
                    style = MaterialTheme.typography.body2
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Profile completeness
            val completeness = 0.75f // In a real app, calculate from profile data
            
            Text(
                text = "Profile Completeness",
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            LinearProgressIndicator(
                progress = completeness,
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colors.primary
            )
            
            Spacer(modifier = Modifier.height(2.dp))
            
            Text(
                text = "Create more music to improve recommendations",
                style = MaterialTheme.typography.caption,
                color = Color.Gray
            )
        }
    }
}

@Composable
fun RecommendationItem(
    recommendation: MusicRecommendation,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = 2.dp,
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Album art (placeholder)
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        Brush.linearGradient(
                            when (recommendation.genre) {
                                "Electronic" -> listOf(Color(0xFF3F51B5), Color(0xFF2196F3))
                                "Hip-Hop" -> listOf(Color(0xFF9C27B0), Color(0xFFE91E63))
                                "Ambient" -> listOf(Color(0xFF009688), Color(0xFF4CAF50))
                                else -> listOf(Color(0xFF607D8B), Color(0xFF9E9E9E))
                            }
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Album,
                    contentDescription = "Album Cover",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Track information
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Recommendation type icon
                    val (icon, iconColor) = when (recommendation.recommendation) {
                        RecommendationType.INSPIRATION -> Pair(Icons.Default.EmojiObjects, Color(0xFFFFA000))
                        RecommendationType.REFERENCE -> Pair(Icons.Default.Bookmark, Color(0xFF2196F3))
                        RecommendationType.SIMILAR_STYLE -> Pair(Icons.Default.Style, Color(0xFF4CAF50))
                        RecommendationType.LEARNING_RESOURCE -> Pair(Icons.Default.School, Color(0xFF9C27B0))
                        RecommendationType.TRENDING -> Pair(Icons.Default.Whatshot, Color(0xFFF44336))
                        RecommendationType.COMPLEMENTARY -> Pair(Icons.Default.Hub, Color(0xFF3F51B5))
                        RecommendationType.EXPERIMENTAL -> Pair(Icons.Default.Science, Color(0xFF607D8B))
                    }
                    
                    Icon(
                        imageVector = icon,
                        contentDescription = recommendation.recommendation.name,
                        tint = iconColor,
                        modifier = Modifier.size(16.dp)
                    )
                    
                    Spacer(modifier = Modifier.width(4.dp))
                    
                    // Track title
                    Text(
                        text = recommendation.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                
                Spacer(modifier = Modifier.height(2.dp))
                
                // Artist name
                Text(
                    text = recommendation.artist,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(2.dp))
                
                // Genre
                Text(
                    text = recommendation.genre,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                // Match score
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${(recommendation.similarityScore * 100).toInt()}% match",
                        fontSize = 12.sp,
                        color = MaterialTheme.colors.primary,
                        fontWeight = FontWeight.Medium
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    // Source platform
                    recommendation.sourcePlatform?.let { platform ->
                        Text(
                            text = "• $platform",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
            
            // Play button
            IconButton(
                onClick = onClick,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colors.primary.copy(alpha = 0.1f))
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Play",
                    tint = MaterialTheme.colors.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun RecommendationDetailDialog(
    recommendation: MusicRecommendation,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onDismiss: () -> Unit,
    onRate: (Int) -> Unit
) {
    var userRating by remember { mutableStateOf(recommendation.userRating) }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Header with album art
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Album art (placeholder)
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                Brush.linearGradient(
                                    when (recommendation.genre) {
                                        "Electronic" -> listOf(Color(0xFF3F51B5), Color(0xFF2196F3))
                                        "Hip-Hop" -> listOf(Color(0xFF9C27B0), Color(0xFFE91E63))
                                        "Ambient" -> listOf(Color(0xFF009688), Color(0xFF4CAF50))
                                        else -> listOf(Color(0xFF607D8B), Color(0xFF9E9E9E))
                                    }
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Album,
                            contentDescription = "Album Cover",
                            tint = Color.White,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = recommendation.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        Text(
                            text = recommendation.artist,
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = recommendation.genre,
                                fontSize = 14.sp,
                                color = Color.Gray
                            )
                            
                            recommendation.sourcePlatform?.let { platform ->
                                Text(
                                    text = " • $platform",
                                    fontSize = 14.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Play controls
                Button(
                    onClick = onPlayPause,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = MaterialTheme.colors.primary
                    )
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play"
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = if (isPlaying) "Pause Preview" else "Play Preview",
                        fontWeight = FontWeight.Medium
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Recommendation type and description
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colors.primary.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val (icon, iconColor, label) = when (recommendation.recommendation) {
                                RecommendationType.INSPIRATION -> Triple(
                                    Icons.Default.EmojiObjects,
                                    Color(0xFFFFA000),
                                    "Inspiration"
                                )
                                RecommendationType.REFERENCE -> Triple(
                                    Icons.Default.Bookmark,
                                    Color(0xFF2196F3),
                                    "Reference Track"
                                )
                                RecommendationType.SIMILAR_STYLE -> Triple(
                                    Icons.Default.Style,
                                    Color(0xFF4CAF50),
                                    "Similar Style"
                                )
                                RecommendationType.LEARNING_RESOURCE -> Triple(
                                    Icons.Default.School,
                                    Color(0xFF9C27B0),
                                    "Learning Resource"
                                )
                                RecommendationType.TRENDING -> Triple(
                                    Icons.Default.Whatshot,
                                    Color(0xFFF44336),
                                    "Trending"
                                )
                                RecommendationType.COMPLEMENTARY -> Triple(
                                    Icons.Default.Hub,
                                    Color(0xFF3F51B5),
                                    "Complementary Style"
                                )
                                RecommendationType.EXPERIMENTAL -> Triple(
                                    Icons.Default.Science,
                                    Color(0xFF607D8B),
                                    "Experimental"
                                )
                            }
                            
                            Icon(
                                imageVector = icon,
                                contentDescription = recommendation.recommendation.name,
                                tint = iconColor,
                                modifier = Modifier.size(24.dp)
                            )
                            
                            Spacer(modifier = Modifier.width(8.dp))
                            
                            Text(
                                text = label,
                                fontWeight = FontWeight.Bold,
                                color = iconColor
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        recommendation.description?.let { description ->
                            Text(
                                text = description,
                                style = MaterialTheme.typography.body2,
                                fontStyle = FontStyle.Italic
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Matching attributes
                Text(
                    text = "Why We Recommended This",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    recommendation.matchingAttributes.forEach { attribute ->
                        MatchingAttributeItem(attribute = attribute)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Rating
                Text(
                    text = "Rate This Recommendation",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Star rating
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    for (i in 1..5) {
                        IconButton(
                            onClick = {
                                userRating = if (userRating == i) 0 else i
                                onRate(userRating)
                            }
                        ) {
                            Icon(
                                imageVector = if (i <= userRating) 
                                    Icons.Default.Star else Icons.Default.StarOutline,
                                contentDescription = "Rate $i",
                                tint = if (i <= userRating) 
                                    Color(0xFFFFB400) else Color.Gray,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // External link button
                recommendation.externalUrl?.let { url ->
                    OutlinedButton(
                        onClick = { /* Open external url */ },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = "Open"
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        Text(
                            text = "Open in ${recommendation.sourcePlatform ?: "Music Service"}",
                            fontWeight = FontWeight.Medium
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                }
                
                // Close button
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Close")
                }
            }
        }
    }
}

@Composable
fun MatchingAttributeItem(attribute: MatchingAttribute) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Match strength indicator
        val color = when {
            attribute.matchStrength > 0.8f -> Color(0xFF4CAF50) // Green
            attribute.matchStrength > 0.5f -> Color(0xFFFFC107) // Amber
            else -> Color(0xFFFF9800) // Orange
        }
        
        Box(
            modifier = Modifier
                .size(16.dp)
                .clip(CircleShape)
                .background(color)
        )
        
        Spacer(modifier = Modifier.width(8.dp))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Row {
                Text(
                    text = attribute.name.capitalize(),
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp
                )
                
                Spacer(modifier = Modifier.width(4.dp))
                
                Text(
                    text = attribute.value,
                    fontSize = 14.sp
                )
            }
            
            attribute.description?.let { description ->
                Text(
                    text = description,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }
        
        // Match percentage
        Text(
            text = "${(attribute.matchStrength * 100).toInt()}%",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = color
        )
    }
}

@Composable
fun RecommendationFilterDialog(
    selectedTypes: Set<RecommendationType>,
    onTypesSelected: (Set<RecommendationType>) -> Unit,
    onDismiss: () -> Unit,
    onApply: () -> Unit
) {
    var currentSelection by remember { mutableStateOf(selectedTypes) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Filter Recommendations") },
        text = {
            Column {
                Text(
                    text = "Recommendation Types",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                RecommendationType.values().forEach { type ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                currentSelection = if (currentSelection.contains(type)) {
                                    currentSelection - type
                                } else {
                                    currentSelection + type
                                }
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = currentSelection.contains(type),
                            onCheckedChange = { checked ->
                                currentSelection = if (checked) {
                                    currentSelection + type
                                } else {
                                    currentSelection - type
                                }
                            }
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        val (icon, label) = when (type) {
                            RecommendationType.INSPIRATION -> Pair(
                                Icons.Default.EmojiObjects,
                                "Inspiration"
                            )
                            RecommendationType.REFERENCE -> Pair(
                                Icons.Default.Bookmark,
                                "Reference Tracks"
                            )
                            RecommendationType.SIMILAR_STYLE -> Pair(
                                Icons.Default.Style,
                                "Similar Style"
                            )
                            RecommendationType.LEARNING_RESOURCE -> Pair(
                                Icons.Default.School,
                                "Learning Resources"
                            )
                            RecommendationType.TRENDING -> Pair(
                                Icons.Default.Whatshot,
                                "Trending Tracks"
                            )
                            RecommendationType.COMPLEMENTARY -> Pair(
                                Icons.Default.Hub,
                                "Complementary Styles"
                            )
                            RecommendationType.EXPERIMENTAL -> Pair(
                                Icons.Default.Science,
                                "Experimental"
                            )
                        }
                        
                        Icon(
                            imageVector = icon,
                            contentDescription = type.name,
                            modifier = Modifier.size(20.dp)
                        )
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        Text(label)
                    }
                }
                
                if (currentSelection.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    OutlinedButton(
                        onClick = {
                            currentSelection = emptySet()
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Clear All")
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onTypesSelected(currentSelection)
                onApply()
            }) {
                Text("Apply Filters")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

private fun String.capitalize(): String {
    return this.replaceFirstChar { 
        if (it.isLowerCase()) it.titlecase() else it.toString() 
    }
}