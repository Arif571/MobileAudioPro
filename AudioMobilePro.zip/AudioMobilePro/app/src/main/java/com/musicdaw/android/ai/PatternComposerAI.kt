package com.musicdaw.android.ai

import com.musicdaw.android.model.*
import java.io.File
import kotlin.math.*
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.*
import org.json.JSONArray
import org.json.JSONObject
import android.util.Log

/**
 * AI untuk menghasilkan pola musik berkualitas tinggi berdasarkan sampel dan genre
 */
class PatternComposerAI(private val context: Context) {

    companion object {
        private const val TAG = "PatternComposerAI"
        private const val GRID_RESOLUTION = 16 // 16th notes
        private const val MAX_PATTERN_LENGTH = 4 // 4 bars
        private const val MAX_MIDI_VALUE = 127
        private const val MIDDLE_C = 60 // MIDI note for middle C
        
        // Definisi struktur musik untuk berbagai genre
        private val GENRE_PATTERNS = mapOf(
            "DJ Bantengan" to mapOf(
                "kickPatterns" to listOf(
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0),
                    intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
                ),
                "snarePatterns" to listOf(
                    intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0),
                    intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0),
                    intArrayOf(0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1)
                ),
                "hihatPatterns" to listOf(
                    intArrayOf(1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0),
                    intArrayOf(1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0),
                    intArrayOf(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
                ),
                "ethnicPercussionPatterns" to listOf(
                    intArrayOf(0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0),
                    intArrayOf(1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0),
                    intArrayOf(0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0)
                ),
                "bassPatterns" to listOf(
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0)
                ),
                "gamelanPatterns" to listOf(
                    intArrayOf(1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0),
                    intArrayOf(0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0),
                    intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
                ),
                "gongPatterns" to listOf(
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
                ),
                "scalePatterns" to listOf(
                    intArrayOf(0, 2, 4, 5, 7, 9, 10, 12), // Pelog scale
                    intArrayOf(0, 1, 3, 5, 7, 8, 10, 12)  // Slendro scale
                )
            ),
            "DJ Nrotok" to mapOf(
                "kickPatterns" to listOf(
                    intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0),
                    intArrayOf(1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0),
                    intArrayOf(1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0)
                ),
                "snarePatterns" to listOf(
                    intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0),
                    intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1),
                    intArrayOf(0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0)
                ),
                "hihatPatterns" to listOf(
                    intArrayOf(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
                    intArrayOf(1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0),
                    intArrayOf(1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1)
                ),
                "ethnicPercussionPatterns" to listOf(
                    intArrayOf(1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0),
                    intArrayOf(1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1),
                    intArrayOf(0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1)
                ),
                "bassPatterns" to listOf(
                    intArrayOf(1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
                ),
                "leadPatterns" to listOf(
                    intArrayOf(1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0),
                    intArrayOf(0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0),
                    intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
                ),
                "scalePatterns" to listOf(
                    intArrayOf(0, 2, 3, 5, 7, 8, 11, 12), // Minor pentatonic
                    intArrayOf(0, 2, 4, 7, 9, 12)         // Major pentatonic
                )
            ),
            "Trap" to mapOf(
                "kickPatterns" to listOf(
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0)
                ),
                "snarePatterns" to listOf(
                    intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0),
                    intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1),
                    intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0)
                ),
                "hihatPatterns" to listOf(
                    intArrayOf(1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0),
                    intArrayOf(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
                    intArrayOf(1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0)
                ),
                "bassPatterns" to listOf(
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
                    intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0)
                ),
                "scalePatterns" to listOf(
                    intArrayOf(0, 2, 3, 5, 7, 8, 10, 12), // Natural minor
                    intArrayOf(0, 2, 3, 5, 7, 9, 10, 12)  // Harmonic minor
                )
            )
        )
    }
    
    // Model sequence generator
    private var sequenceModel: Interpreter? = null
    
    // Model chord progression generator
    private var chordModel: Interpreter? = null
    
    // Model untuk variasi dan ornamentation
    private var variationModel: Interpreter? = null
    
    // Vector embedding untuk genre
    private val genreEmbeddings = mutableMapOf<String, FloatArray>()
    
    init {
        try {
            // Load TensorFlow Lite models
            sequenceModel = loadTfliteModel("models/sequence_generator.tflite")
            chordModel = loadTfliteModel("models/chord_progression.tflite")
            variationModel = loadTfliteModel("models/pattern_variation.tflite")
            
            // Load genre embeddings
            loadGenreEmbeddings()
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing models", e)
        }
    }
    
    /**
     * Membuat proyek lengkap berdasarkan sampel dan genre
     */
    suspend fun composeFullProject(
        samples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String,
        projectName: String,
        tempoRange: Pair<Float, Float> = Pair(70f, 180f)
    ): Project = withContext(Dispatchers.Default) {
        try {
            // 1. Tentukan tempo berdasarkan genre dan analisis sampel
            val tempo = determineTempo(samples, genre, tempoRange)
            
            // 2. Tentukan time signature (4/4 default, bisa diubah berdasarkan genre)
            val timeSignature = determineTimeSignature(genre)
            
            // 3. Tentukan key dan scale
            val keyAndScale = determineKeyAndScale(samples, genre)
            val key = keyAndScale.first
            val scale = keyAndScale.second
            
            // 4. Hasilkan chord progression
            val chordProgression = generateChordProgression(key, scale, genre)
            
            // 5. Bangun struktur proyek (intro, verse, chorus, dll)
            val projectStructure = buildProjectStructure(genre)
            
            // 6. Buat tracks dan patterns untuk setiap instrument
            val tracks = createTracksWithPatterns(
                samples = samples,
                genre = genre,
                tempo = tempo,
                key = key,
                scale = scale,
                chordProgression = chordProgression,
                structure = projectStructure
            )
            
            // 7. Terapkan automation dan efek
            val tracksWithEffects = applyEffectsAndAutomation(tracks, genre)
            
            // 8. Finalisasi dan kembalikan proyek
            return@withContext Project(
                name = projectName,
                tempo = tempo,
                key = key,
                timeSignatureNumerator = timeSignature.first,
                timeSignatureDenominator = timeSignature.second,
                tracks = tracksWithEffects,
                duration = calculateProjectDuration(tracksWithEffects, tempo)
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error composing project", e)
            
            // Fallback: buat proyek sederhana jika terjadi error
            return@withContext createBasicProject(samples, genre, projectName)
        }
    }
    
    /**
     * Memuat model TensorFlow Lite dari assets
     */
    private fun loadTfliteModel(modelPath: String): Interpreter? {
        try {
            val assetManager = context.assets
            val fileDescriptor = assetManager.openFd(modelPath)
            val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
            val fileChannel = inputStream.channel
            val startOffset = fileDescriptor.startOffset
            val declaredLength = fileDescriptor.declaredLength
            val mappedBuffer = fileChannel.map(
                FileChannel.MapMode.READ_ONLY,
                startOffset,
                declaredLength
            )
            
            val options = Interpreter.Options()
            options.setNumThreads(4)
            
            return Interpreter(mappedBuffer, options)
        } catch (e: Exception) {
            Log.e(TAG, "Error loading model: $modelPath", e)
            return null
        }
    }
    
    /**
     * Memuat embedding vector untuk berbagai genre musik
     */
    private fun loadGenreEmbeddings() {
        try {
            val inputStream = context.assets.open("models/genre_embeddings.json")
            val size = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            
            val json = String(buffer, Charsets.UTF_8)
            val jsonObject = JSONObject(json)
            
            val genres = jsonObject.keys()
            while (genres.hasNext()) {
                val genre = genres.next()
                val embeddingArray = jsonObject.getJSONArray(genre)
                val embedding = FloatArray(embeddingArray.length())
                
                for (i in 0 until embeddingArray.length()) {
                    embedding[i] = embeddingArray.getDouble(i).toFloat()
                }
                
                genreEmbeddings[genre] = embedding
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading genre embeddings", e)
            
            // Fallback: buat embedding sederhana jika gagal memuat
            genreEmbeddings["DJ Bantengan"] = FloatArray(16) { if (it % 2 == 0) 1f else 0f }
            genreEmbeddings["DJ Nrotok"] = FloatArray(16) { if (it % 3 == 0) 1f else 0f }
            genreEmbeddings["Koplo"] = FloatArray(16) { if (it % 4 == 0) 1f else 0f }
            genreEmbeddings["Trap"] = FloatArray(16) { if (it % 5 == 0) 1f else 0f }
            genreEmbeddings["EDM"] = FloatArray(16) { if (it % 6 == 0) 1f else 0f }
        }
    }
    
    /**
     * Tentukan tempo proyek berdasarkan genre dan analisis sampel
     */
    private fun determineTempo(
        samples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String,
        tempoRange: Pair<Float, Float>
    ): Float {
        // Gunakan rentang tempo yang sesuai dengan genre
        val defaultTempo = when {
            genre.contains("bantengan", ignoreCase = true) -> 100f
            genre.contains("nrotok", ignoreCase = true) -> 150f
            genre.contains("koplo", ignoreCase = true) -> 140f
            genre.contains("dangdut", ignoreCase = true) -> 120f
            genre.contains("trap", ignoreCase = true) -> 140f
            genre.contains("edm", ignoreCase = true) -> 128f
            else -> 120f
        }
        
        // Analisis tempo dari sampel perkusi jika tersedia
        val percussionSamples = samples.filter { it.category.equals("percussion", ignoreCase = true) }
        if (percussionSamples.isNotEmpty()) {
            // Ekstrak metadata tempo jika tersedia
            val tempoHints = percussionSamples
                .mapNotNull { it.metadata["tempo"]?.toFloatOrNull() }
                .filter { it in tempoRange.first..tempoRange.second }
            
            if (tempoHints.isNotEmpty()) {
                // Gunakan median tempo dari sampel
                val sortedTempos = tempoHints.sorted()
                return sortedTempos[sortedTempos.size / 2]
            }
        }
        
        // Jika tidak ada petunjuk tempo dari sampel, gunakan nilai default untuk genre
        return defaultTempo.coerceIn(tempoRange.first, tempoRange.second)
    }
    
    /**
     * Tentukan time signature berdasarkan genre
     */
    private fun determineTimeSignature(genre: String): Pair<Int, Int> {
        // Default 4/4 untuk mayoritas genre
        return when {
            genre.contains("waltz", ignoreCase = true) -> Pair(3, 4)
            genre.contains("odd", ignoreCase = true) -> Pair(5, 4)
            genre.contains("experimental", ignoreCase = true) -> Pair(7, 8)
            else -> Pair(4, 4)
        }
    }
    
    /**
     * Tentukan kunci musik dan skala berdasarkan sampel dan genre
     */
    private fun determineKeyAndScale(
        samples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String
    ): Pair<String, IntArray> {
        // Analisis sampel melodi dan bass untuk menentukan kunci
        val melodicSamples = samples.filter { 
            it.category.equals("melody", ignoreCase = true) || 
            it.category.equals("bass", ignoreCase = true) 
        }
        
        // Jika ada sampel melodi dengan root note, prioritaskan informasi ini
        val rootNotes = melodicSamples
            .mapNotNull { it.rootNote }
            .groupBy { it }
            .mapValues { it.value.size }
        
        if (rootNotes.isNotEmpty()) {
            // Gunakan root note yang paling sering muncul
            val mostCommonRoot = rootNotes.maxByOrNull { it.value }?.key ?: MIDDLE_C
            
            // Konversi MIDI note number ke nama kunci
            val keyName = getKeyNameFromMidiNote(mostCommonRoot)
            
            // Tentukan skala berdasarkan genre
            val scale = when {
                genre.contains("bantengan", ignoreCase = true) -> intArrayOf(0, 2, 4, 5, 7, 9, 10, 12) // Pelog-inspired
                genre.contains("nrotok", ignoreCase = true) -> intArrayOf(0, 2, 3, 5, 7, 8, 10, 12) // Natural minor
                genre.contains("koplo", ignoreCase = true) -> intArrayOf(0, 2, 4, 5, 7, 9, 11, 12) // Major
                genre.contains("dangdut", ignoreCase = true) -> intArrayOf(0, 2, 3, 5, 7, 8, 10, 12) // Natural minor
                genre.contains("trap", ignoreCase = true) -> intArrayOf(0, 2, 3, 5, 7, 8, 10, 12) // Natural minor
                genre.contains("edm", ignoreCase = true) -> intArrayOf(0, 2, 4, 5, 7, 9, 11, 12) // Major
                else -> intArrayOf(0, 2, 4, 5, 7, 9, 11, 12) // Major scale default
            }
            
            return Pair(keyName, scale)
        }
        
        // Default jika tidak ada petunjuk kunci
        return when {
            genre.contains("bantengan", ignoreCase = true) -> Pair("C", intArrayOf(0, 2, 4, 5, 7, 9, 10, 12))
            genre.contains("nrotok", ignoreCase = true) -> Pair("F#m", intArrayOf(0, 2, 3, 5, 7, 8, 10, 12))
            genre.contains("koplo", ignoreCase = true) -> Pair("F", intArrayOf(0, 2, 4, 5, 7, 9, 11, 12))
            genre.contains("dangdut", ignoreCase = true) -> Pair("Dm", intArrayOf(0, 2, 3, 5, 7, 8, 10, 12))
            genre.contains("trap", ignoreCase = true) -> Pair("Cm", intArrayOf(0, 2, 3, 5, 7, 8, 10, 12))
            genre.contains("edm", ignoreCase = true) -> Pair("G", intArrayOf(0, 2, 4, 5, 7, 9, 11, 12))
            else -> Pair("C", intArrayOf(0, 2, 4, 5, 7, 9, 11, 12))
        }
    }
    
    /**
     * Dapatkan nama kunci musik dari MIDI note number
     */
    private fun getKeyNameFromMidiNote(midiNote: Int): String {
        val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
        val noteIndex = midiNote % 12
        
        return noteNames[noteIndex]
    }
    
    /**
     * Hasilkan chord progression berdasarkan kunci, skala, dan genre
     */
    private fun generateChordProgression(
        key: String,
        scale: IntArray,
        genre: String
    ): List<Chord> {
        try {
            if (chordModel != null) {
                // Encode key, scale, dan genre untuk input model
                val keyIndex = encodeKeyToIndex(key)
                val scaleType = encodeScaleType(scale)
                val genreEmbedding = genreEmbeddings[genre] ?: FloatArray(16) { 0f }
                
                // Siapkan input untuk model
                val inputBuffer = ByteBuffer.allocateDirect(4 * (1 + 1 + genreEmbedding.size))
                inputBuffer.order(ByteOrder.nativeOrder())
                
                // Input format: [keyIndex, scaleType, genreEmbedding[0], genreEmbedding[1], ...]
                inputBuffer.putFloat(keyIndex)
                inputBuffer.putFloat(scaleType)
                for (value in genreEmbedding) {
                    inputBuffer.putFloat(value)
                }
                inputBuffer.rewind()
                
                // Output: 8 progresif chord dengan durasi
                val outputBuffer = ByteBuffer.allocateDirect(4 * 16) // 8 chord x 2 values (chord, duration)
                outputBuffer.order(ByteOrder.nativeOrder())
                
                // Jalankan model
                chordModel!!.run(inputBuffer, outputBuffer)
                
                // Decode hasil
                outputBuffer.rewind()
                val chords = mutableListOf<Chord>()
                val chordsCount = 8
                
                for (i in 0 until chordsCount) {
                    val chordIndex = outputBuffer.float.toInt()
                    val durationInBeats = outputBuffer.float.toInt()
                    
                    // Convert chord index to actual chord
                    val chord = createChordFromIndex(chordIndex, key, scale)
                    chords.add(chord.copy(durationInBeats = durationInBeats))
                }
                
                return chords
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error generating chord progression", e)
        }
        
        // Fallback: gunakan chord progression dasar jika model gagal
        return createDefaultChordProgression(key, scale, genre)
    }
    
    /**
     * Encode kunci musik menjadi indeks
     */
    private fun encodeKeyToIndex(key: String): Float {
        val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
        val isMinor = key.endsWith("m")
        
        val rootName = if (isMinor) key.substring(0, key.length - 1) else key
        val rootIndex = noteNames.indexOf(rootName)
        
        return if (rootIndex >= 0) {
            rootIndex + (if (isMinor) 12f else 0f)
        } else {
            0f // default to C major
        }
    }
    
    /**
     * Encode tipe skala menjadi indeks
     */
    private fun encodeScaleType(scale: IntArray): Float {
        // 0 = major, 1 = natural minor, 2 = harmonic minor, 3 = melodic minor, 4 = pelog, 5 = slendro
        return when {
            Arrays.equals(scale, intArrayOf(0, 2, 4, 5, 7, 9, 11, 12)) -> 0f
            Arrays.equals(scale, intArrayOf(0, 2, 3, 5, 7, 8, 10, 12)) -> 1f
            Arrays.equals(scale, intArrayOf(0, 2, 3, 5, 7, 8, 11, 12)) -> 2f
            Arrays.equals(scale, intArrayOf(0, 2, 3, 5, 7, 9, 11, 12)) -> 3f
            Arrays.equals(scale, intArrayOf(0, 2, 4, 5, 7, 9, 10, 12)) -> 4f
            Arrays.equals(scale, intArrayOf(0, 1, 3, 5, 7, 8, 10, 12)) -> 5f
            else -> 0f
        }
    }
    
    /**
     * Buat chord dari indeks
     */
    private fun createChordFromIndex(chordIndex: Int, key: String, scale: IntArray): Chord {
        val rootNoteOffset = encodeKeyToIndex(key).toInt() % 12
        val isMinor = encodeKeyToIndex(key).toInt() >= 12
        
        // Chord index: 0-6 for diatonic chords I-VII, 7-13 for secondary dominants, etc.
        val chordType = when {
            isMinor -> when (chordIndex % 7) {
                0 -> ChordType.MINOR // i
                1 -> ChordType.DIMINISHED // ii°
                2 -> ChordType.MAJOR // III
                3 -> ChordType.MINOR // iv
                4 -> ChordType.MINOR // v
                5 -> ChordType.MAJOR // VI
                6 -> ChordType.MAJOR // VII
                else -> ChordType.MINOR
            }
            else -> when (chordIndex % 7) {
                0 -> ChordType.MAJOR // I
                1 -> ChordType.MINOR // ii
                2 -> ChordType.MINOR // iii
                3 -> ChordType.MAJOR // IV
                4 -> ChordType.MAJOR // V
                5 -> ChordType.MINOR // vi
                6 -> ChordType.DIMINISHED // vii°
                else -> ChordType.MAJOR
            }
        }
        
        // Get root note from scale
        val rootStep = chordIndex % 7
        val rootNote = (rootNoteOffset + scale[rootStep]) % 12
        
        return Chord(
            rootNote = rootNote,
            chordType = chordType,
            durationInBeats = 4 // Default 1 bar
        )
    }
    
    /**
     * Buat chord progression default jika model gagal
     */
    private fun createDefaultChordProgression(
        key: String,
        scale: IntArray,
        genre: String
    ): List<Chord> {
        val rootNoteOffset = encodeKeyToIndex(key).toInt() % 12
        val isMinor = encodeKeyToIndex(key).toInt() >= 12
        
        // Chord progression patterns based on genre
        val progressionPattern = when {
            genre.contains("bantengan", ignoreCase = true) -> if (isMinor) 
                listOf(0, 5, 3, 4) else listOf(0, 5, 3, 4)
            genre.contains("nrotok", ignoreCase = true) -> if (isMinor) 
                listOf(0, 5, 3, 4, 0, 5, 0, 4) else listOf(0, 5, 3, 4, 0, 5, 0, 4)
            genre.contains("trap", ignoreCase = true) -> if (isMinor) 
                listOf(0, 0, 5, 5, 3, 3, 4, 4) else listOf(0, 0, 5, 5, 3, 3, 4, 4)
            genre.contains("edm", ignoreCase = true) -> if (isMinor) 
                listOf(0, 5, 3, 4, 0, 5, 3, 4) else listOf(0, 3, 4, 5, 0, 3, 4, 5)
            else -> if (isMinor) 
                listOf(0, 3, 4, 0, 5, 0, 4, 5) else listOf(0, 4, 5, 3, 0, 4, 5, 3)
        }
        
        return progressionPattern.map { chordIndex ->
            createChordFromIndex(chordIndex, key, scale).copy(durationInBeats = 4)
        }
    }
    
    /**
     * Bangun struktur proyek (intro, verse, chorus, dll)
     */
    private fun buildProjectStructure(genre: String): SongStructure {
        // Struktur default berdasarkan genre
        return when {
            genre.contains("bantengan", ignoreCase = true) || 
            genre.contains("nrotok", ignoreCase = true) -> {
                SongStructure(
                    parts = listOf(
                        SongPart(type = PartType.INTRO, lengthInBars = 8),
                        SongPart(type = PartType.BUILD, lengthInBars = 8),
                        SongPart(type = PartType.DROP, lengthInBars = 16),
                        SongPart(type = PartType.BREAKDOWN, lengthInBars = 8),
                        SongPart(type = PartType.BUILD, lengthInBars = 8),
                        SongPart(type = PartType.DROP, lengthInBars = 16),
                        SongPart(type = PartType.OUTRO, lengthInBars = 8)
                    )
                )
            }
            genre.contains("koplo", ignoreCase = true) || 
            genre.contains("dangdut", ignoreCase = true) -> {
                SongStructure(
                    parts = listOf(
                        SongPart(type = PartType.INTRO, lengthInBars = 8),
                        SongPart(type = PartType.VERSE, lengthInBars = 16),
                        SongPart(type = PartType.CHORUS, lengthInBars = 16),
                        SongPart(type = PartType.VERSE, lengthInBars = 16),
                        SongPart(type = PartType.CHORUS, lengthInBars = 16),
                        SongPart(type = PartType.BRIDGE, lengthInBars = 8),
                        SongPart(type = PartType.CHORUS, lengthInBars = 16),
                        SongPart(type = PartType.OUTRO, lengthInBars = 8)
                    )
                )
            }
            genre.contains("trap", ignoreCase = true) -> {
                SongStructure(
                    parts = listOf(
                        SongPart(type = PartType.INTRO, lengthInBars = 8),
                        SongPart(type = PartType.VERSE, lengthInBars = 16),
                        SongPart(type = PartType.CHORUS, lengthInBars = 8),
                        SongPart(type = PartType.VERSE, lengthInBars = 16),
                        SongPart(type = PartType.CHORUS, lengthInBars = 8),
                        SongPart(type = PartType.BRIDGE, lengthInBars = 8),
                        SongPart(type = PartType.CHORUS, lengthInBars = 16),
                        SongPart(type = PartType.OUTRO, lengthInBars = 4)
                    )
                )
            }
            genre.contains("edm", ignoreCase = true) -> {
                SongStructure(
                    parts = listOf(
                        SongPart(type = PartType.INTRO, lengthInBars = 16),
                        SongPart(type = PartType.BUILD, lengthInBars = 8),
                        SongPart(type = PartType.DROP, lengthInBars = 16),
                        SongPart(type = PartType.BREAKDOWN, lengthInBars = 8),
                        SongPart(type = PartType.BUILD, lengthInBars = 8),
                        SongPart(type = PartType.DROP, lengthInBars = 16),
                        SongPart(type = PartType.OUTRO, lengthInBars = 8)
                    )
                )
            }
            else -> {
                SongStructure(
                    parts = listOf(
                        SongPart(type = PartType.INTRO, lengthInBars = 8),
                        SongPart(type = PartType.VERSE, lengthInBars = 16),
                        SongPart(type = PartType.CHORUS, lengthInBars = 16),
                        SongPart(type = PartType.VERSE, lengthInBars = 16),
                        SongPart(type = PartType.CHORUS, lengthInBars = 16),
                        SongPart(type = PartType.BRIDGE, lengthInBars = 8),
                        SongPart(type = PartType.CHORUS, lengthInBars = 16),
                        SongPart(type = PartType.OUTRO, lengthInBars = 8)
                    )
                )
            }
        }
    }
    
    /**
     * Buat tracks dan patterns untuk proyek
     */
    private fun createTracksWithPatterns(
        samples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String,
        tempo: Float,
        key: String,
        scale: IntArray,
        chordProgression: List<Chord>,
        structure: SongStructure
    ): List<Track> {
        val tracks = mutableListOf<Track>()
        
        // Kategorikan sampel berdasarkan tipe
        val percussionSamples = samples.filter { it.category.equals("percussion", ignoreCase = true) }
        val bassSamples = samples.filter { it.category.equals("bass", ignoreCase = true) }
        val melodySamples = samples.filter { it.category.equals("melody", ignoreCase = true) }
        val padSamples = samples.filter { it.category.equals("pad", ignoreCase = true) }
        val fxSamples = samples.filter { it.category.equals("effect", ignoreCase = true) }
        val vocalSamples = samples.filter { it.category.equals("vocal", ignoreCase = true) }
        
        // Pilih sampel terbaik untuk setiap kategori
        val kickSamples = percussionSamples.filter { it.name.contains("kick", ignoreCase = true) }
        val snareSamples = percussionSamples.filter { it.name.contains("snare", ignoreCase = true) }
        val hihatSamples = percussionSamples.filter { 
            it.name.contains("hat", ignoreCase = true) || it.name.contains("hi-hat", ignoreCase = true) 
        }
        val cymbalSamples = percussionSamples.filter { it.name.contains("cymbal", ignoreCase = true) }
        val percOtherSamples = percussionSamples.filter { 
            !it.name.contains("kick", ignoreCase = true) && 
            !it.name.contains("snare", ignoreCase = true) && 
            !it.name.contains("hat", ignoreCase = true) && 
            !it.name.contains("hi-hat", ignoreCase = true) && 
            !it.name.contains("cymbal", ignoreCase = true) 
        }
        
        // Tambahkan track drum
        if (percussionSamples.isNotEmpty()) {
            tracks.add(createDrumTrack(
                kickSamples = kickSamples,
                snareSamples = snareSamples,
                hihatSamples = hihatSamples,
                cymbalSamples = cymbalSamples,
                otherPercSamples = percOtherSamples,
                genre = genre,
                structure = structure,
                tempo = tempo
            ))
        }
        
        // Tambahkan track bass
        if (bassSamples.isNotEmpty()) {
            tracks.add(createBassTrack(
                bassSamples = bassSamples,
                genre = genre,
                structure = structure,
                tempo = tempo,
                key = key,
                scale = scale,
                chordProgression = chordProgression
            ))
        }
        
        // Tambahkan track melodi
        if (melodySamples.isNotEmpty()) {
            tracks.add(createMelodyTrack(
                melodySamples = melodySamples,
                genre = genre,
                structure = structure,
                tempo = tempo,
                key = key,
                scale = scale,
                chordProgression = chordProgression
            ))
        }
        
        // Tambahkan track pad
        if (padSamples.isNotEmpty()) {
            tracks.add(createPadTrack(
                padSamples = padSamples,
                genre = genre,
                structure = structure,
                tempo = tempo,
                key = key,
                scale = scale,
                chordProgression = chordProgression
            ))
        }
        
        // Tambahkan track FX
        if (fxSamples.isNotEmpty()) {
            tracks.add(createFXTrack(
                fxSamples = fxSamples,
                genre = genre,
                structure = structure,
                tempo = tempo
            ))
        }
        
        // Tambahkan track vokal jika ada
        if (vocalSamples.isNotEmpty()) {
            tracks.add(createVocalTrack(
                vocalSamples = vocalSamples,
                genre = genre,
                structure = structure,
                tempo = tempo,
                key = key
            ))
        }
        
        // Tambahkan track etnik untuk genre Indonesia
        if (genre.contains("bantengan", ignoreCase = true) || 
            genre.contains("nrotok", ignoreCase = true) || 
            genre.contains("koplo", ignoreCase = true) || 
            genre.contains("dangdut", ignoreCase = true)) {
            
            val ethnicSamples = percussionSamples.filter { 
                it.name.contains("gamelan", ignoreCase = true) || 
                it.name.contains("kendang", ignoreCase = true) || 
                it.name.contains("gong", ignoreCase = true) || 
                it.name.contains("ethnic", ignoreCase = true) 
            }
            
            if (ethnicSamples.isNotEmpty()) {
                tracks.add(createEthnicTrack(
                    ethnicSamples = ethnicSamples,
                    genre = genre,
                    structure = structure,
                    tempo = tempo,
                    key = key,
                    scale = scale
                ))
            }
        }
        
        return tracks
    }
    
    /**
     * Buat track drum
     */
    private fun createDrumTrack(
        kickSamples: List<AudioSampleExtractorAI.AudioSample>,
        snareSamples: List<AudioSampleExtractorAI.AudioSample>,
        hihatSamples: List<AudioSampleExtractorAI.AudioSample>,
        cymbalSamples: List<AudioSampleExtractorAI.AudioSample>,
        otherPercSamples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String,
        structure: SongStructure,
        tempo: Float
    ): Track {
        val audioClips = mutableListOf<AudioClip>()
        val midiPatterns = mutableListOf<MidiPattern>()
        var currentPosition = 0f
        
        // Pilih sampel
        val kickSample = kickSamples.firstOrNull() ?: return Track(name = "Drums", audioClips = emptyList(), midiPatterns = emptyList())
        val snareSample = snareSamples.firstOrNull()
        val hihatSample = hihatSamples.firstOrNull()
        val cymbalSample = cymbalSamples.firstOrNull()
        val otherSample = otherPercSamples.firstOrNull()
        
        // Konversi tempo ke milidetik per beat
        val msPerBeat = 60000f / tempo
        val msPerBar = msPerBeat * 4
        
        // Bangun pattern untuk setiap bagian song structure
        for (part in structure.parts) {
            // Ambil pattern yang sesuai dengan genre dan bagian strukturnya
            val kickPattern = getPatternForPart(genre, "kick", part.type)
            val snarePattern = getPatternForPart(genre, "snare", part.type)
            val hihatPattern = getPatternForPart(genre, "hihat", part.type)
            val percPattern = getPatternForPart(genre, "ethnic", part.type)
            
            // Jumlah bar dalam bagian ini
            val numBars = part.lengthInBars
            
            // Tambahkan kick sample untuk pattern kick
            if (kickSample != null) {
                for (bar in 0 until numBars) {
                    for (step in 0 until GRID_RESOLUTION) {
                        if (kickPattern[step % kickPattern.size] > 0) {
                            val startTime = currentPosition + bar * msPerBar + step * (msPerBar / GRID_RESOLUTION)
                            audioClips.add(
                                AudioClip(
                                    name = "Kick",
                                    filePath = kickSample.filePath,
                                    startTime = startTime / 1000f, // convert to seconds
                                    duration = kickSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
            }
            
            // Tambahkan snare sample untuk pattern snare
            if (snareSample != null) {
                for (bar in 0 until numBars) {
                    for (step in 0 until GRID_RESOLUTION) {
                        if (snarePattern[step % snarePattern.size] > 0) {
                            val startTime = currentPosition + bar * msPerBar + step * (msPerBar / GRID_RESOLUTION)
                            audioClips.add(
                                AudioClip(
                                    name = "Snare",
                                    filePath = snareSample.filePath,
                                    startTime = startTime / 1000f,
                                    duration = snareSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
            }
            
            // Tambahkan hihat sample untuk pattern hihat
            if (hihatSample != null) {
                for (bar in 0 until numBars) {
                    for (step in 0 until GRID_RESOLUTION) {
                        if (hihatPattern[step % hihatPattern.size] > 0) {
                            val startTime = currentPosition + bar * msPerBar + step * (msPerBar / GRID_RESOLUTION)
                            audioClips.add(
                                AudioClip(
                                    name = "HiHat",
                                    filePath = hihatSample.filePath,
                                    startTime = startTime / 1000f,
                                    duration = hihatSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
            }
            
            // Tambahkan cymbal di setiap perubahan bagian
            if (cymbalSample != null) {
                val startTime = currentPosition
                audioClips.add(
                    AudioClip(
                        name = "Cymbal",
                        filePath = cymbalSample.filePath,
                        startTime = startTime / 1000f,
                        duration = cymbalSample.duration,
                        isLooping = false
                    )
                )
            }
            
            // Tambahkan percussion ethnik jika sesuai genre
            if (otherSample != null && 
                (genre.contains("bantengan", ignoreCase = true) || 
                 genre.contains("nrotok", ignoreCase = true) || 
                 genre.contains("koplo", ignoreCase = true))) {
                
                for (bar in 0 until numBars) {
                    for (step in 0 until GRID_RESOLUTION) {
                        if (percPattern[step % percPattern.size] > 0) {
                            val startTime = currentPosition + bar * msPerBar + step * (msPerBar / GRID_RESOLUTION)
                            audioClips.add(
                                AudioClip(
                                    name = "Ethnic",
                                    filePath = otherSample.filePath,
                                    startTime = startTime / 1000f,
                                    duration = otherSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
            }
            
            // Pindah ke posisi selanjutnya
            currentPosition += numBars * msPerBar
        }
        
        return Track(
            name = "Drums",
            audioClips = audioClips,
            midiPatterns = midiPatterns,
            isDrumTrack = true
        )
    }
    
    /**
     * Buat track bass
     */
    private fun createBassTrack(
        bassSamples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String,
        structure: SongStructure,
        tempo: Float,
        key: String,
        scale: IntArray,
        chordProgression: List<Chord>
    ): Track {
        val audioClips = mutableListOf<AudioClip>()
        val midiPatterns = mutableListOf<MidiPattern>()
        var currentPosition = 0f
        
        // Pilih sampel bass
        val bassSample = bassSamples.firstOrNull() ?: 
            return Track(name = "Bass", audioClips = emptyList(), midiPatterns = emptyList())
        
        // Konversi tempo ke milidetik per beat
        val msPerBeat = 60000f / tempo
        val msPerBar = msPerBeat * 4
        
        // Tentukan root note MIDI
        val rootMidi = keyNameToMidiNote(key)
        
        // Kalkulasi panjang total chord progression dalam beat
        val chordsLengthInBeats = chordProgression.sumOf { it.durationInBeats }
        
        // Bangun pattern untuk setiap bagian song structure
        for (part in structure.parts) {
            // Ambil pattern yang sesuai dengan genre dan bagian strukturnya
            val bassPattern = getPatternForPart(genre, "bass", part.type)
            
            // Jumlah bar dalam bagian ini
            val numBars = part.lengthInBars
            
            // Buat pattern MIDI sesuai dengan chord progression
            val midiNotes = mutableListOf<MidiNote>()
            var beatPosition = 0
            
            for (bar in 0 until numBars) {
                // Tentukan chord yang aktif untuk bar ini
                val chordIndex = ((currentPosition / msPerBar) + bar) % chordsLengthInBeats
                val activeChord = chordProgression[chordIndex.toInt() % chordProgression.size]
                
                // Ekstrak nada-nada dalam chord
                val chordNotes = getChordNotes(activeChord, rootMidi, scale)
                
                // Buat bass line mengikuti pattern
                for (step in 0 until GRID_RESOLUTION) {
                    if (bassPattern[step % bassPattern.size] > 0) {
                        // Tentukan nada yang akan dimainkan (biasanya root chord)
                        val note = chordNotes[0] // root note
                        
                        // Tentukan velocity (kekuatan nada)
                        val velocity = when (step % 4) {
                            0 -> 100 // beat pertama lebih kuat
                            else -> 80
                        }
                        
                        // Tambahkan note ke pattern MIDI
                        midiNotes.add(
                            MidiNote(
                                note = note,
                                startTime = bar * 4f + step * 0.25f, // dalam beats
                                duration = 0.25f,
                                velocity = velocity
                            )
                        )
                    }
                }
                
                beatPosition += 4 // 4 beats per bar
            }
            
            // Buat pattern MIDI untuk bagian ini
            if (midiNotes.isNotEmpty()) {
                midiPatterns.add(
                    MidiPattern(
                        name = "Bass ${part.type}",
                        notes = midiNotes,
                        duration = numBars * 4f, // dalam beats
                        startTime = currentPosition / msPerBeat, // konversi ms ke beats
                        isLooping = false
                    )
                )
            }
            
            // Pindah ke posisi selanjutnya
            currentPosition += numBars * msPerBar
        }
        
        return Track(
            name = "Bass",
            audioClips = audioClips,
            midiPatterns = midiPatterns
        )
    }
    
    /**
     * Buat track melodi
     */
    private fun createMelodyTrack(
        melodySamples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String,
        structure: SongStructure,
        tempo: Float,
        key: String,
        scale: IntArray,
        chordProgression: List<Chord>
    ): Track {
        val audioClips = mutableListOf<AudioClip>()
        val midiPatterns = mutableListOf<MidiPattern>()
        var currentPosition = 0f
        
        // Pilih sampel melodi
        val melodySample = melodySamples.firstOrNull() ?:
            return Track(name = "Melody", audioClips = emptyList(), midiPatterns = emptyList())
        
        // Konversi tempo ke milidetik per beat
        val msPerBeat = 60000f / tempo
        val msPerBar = msPerBeat * 4
        
        // Tentukan root note MIDI
        val rootMidi = keyNameToMidiNote(key)
        
        // Kalkulasi panjang total chord progression dalam beat
        val chordsLengthInBeats = chordProgression.sumOf { it.durationInBeats }
        
        // Bangun pattern untuk setiap bagian song structure
        for (part in structure.parts) {
            // Skip parts that don't need melody
            if (part.type == PartType.INTRO && part.lengthInBars <= 4) continue
            if (part.type == PartType.OUTRO && part.lengthInBars <= 4) continue
            
            // Ambil pattern yang sesuai dengan genre dan bagian strukturnya
            val leadPattern = getPatternForPart(genre, "lead", part.type)
            
            // Jumlah bar dalam bagian ini
            val numBars = part.lengthInBars
            
            // Buat pattern MIDI sesuai dengan chord progression
            val midiNotes = mutableListOf<MidiNote>()
            var beatPosition = 0
            
            for (bar in 0 until numBars) {
                // Tentukan chord yang aktif untuk bar ini
                val chordIndex = ((currentPosition / msPerBar) + bar) % chordsLengthInBeats
                val activeChord = chordProgression[chordIndex.toInt() % chordProgression.size]
                
                // Ekstrak nada-nada dalam chord dan skala
                val chordNotes = getChordNotes(activeChord, rootMidi, scale)
                val scaleNotes = getScaleNotes(rootMidi, scale)
                
                // Tentukan sequence melodi berdasarkan genre dan tipe bagian
                val melodySequence = when {
                    genre.contains("bantengan", ignoreCase = true) -> generateMelodicSequence(
                        scaleNotes, chordNotes, "pelog", part.type
                    )
                    genre.contains("nrotok", ignoreCase = true) -> generateMelodicSequence(
                        scaleNotes, chordNotes, "nrotok", part.type
                    )
                    genre.contains("trap", ignoreCase = true) -> generateMelodicSequence(
                        scaleNotes, chordNotes, "trap", part.type
                    )
                    else -> generateMelodicSequence(
                        scaleNotes, chordNotes, "default", part.type
                    )
                }
                
                // Tambahkan sequence ke pola MIDI
                for (step in 0 until melodySequence.size) {
                    val note = melodySequence[step]
                    if (note >= 0) {
                        // Durasi not bervariasi untuk melodi yang lebih natural
                        val duration = when {
                            step % 8 == 0 -> 0.5f  // not pertama lebih panjang
                            Random().nextFloat() > 0.8f -> 0.125f // kadang-kadang not pendek
                            else -> 0.25f // umumnya 1/16 not
                        }
                        
                        // Tentukan velocity (kekuatan nada)
                        val velocity = when {
                            step % 4 == 0 -> 90 + Random().nextInt(10) // aksen
                            else -> 70 + Random().nextInt(20) // variasi natural
                        }
                        
                        // Tambahkan not ke pattern MIDI
                        midiNotes.add(
                            MidiNote(
                                note = note,
                                startTime = bar * 4f + step * 0.25f, // dalam beats
                                duration = duration,
                                velocity = velocity
                            )
                        )
                    }
                }
                
                beatPosition += 4 // 4 beats per bar
            }
            
            // Buat pattern MIDI untuk bagian ini
            if (midiNotes.isNotEmpty()) {
                midiPatterns.add(
                    MidiPattern(
                        name = "Melody ${part.type}",
                        notes = midiNotes,
                        duration = numBars * 4f, // dalam beats
                        startTime = currentPosition / msPerBeat, // konversi ms ke beats
                        isLooping = false
                    )
                )
            }
            
            // Pindah ke posisi selanjutnya
            currentPosition += numBars * msPerBar
        }
        
        return Track(
            name = "Melody",
            audioClips = audioClips,
            midiPatterns = midiPatterns
        )
    }
    
    /**
     * Buat track pad
     */
    private fun createPadTrack(
        padSamples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String,
        structure: SongStructure,
        tempo: Float,
        key: String,
        scale: IntArray,
        chordProgression: List<Chord>
    ): Track {
        // Implementasi serupa dengan createMelodyTrack tetapi dengan pola pad
        // yang lebih panjang dan berkelanjutan
        
        // Simplifikasi: Menggunakan implementasi dummy
        return Track(
            name = "Pad",
            audioClips = emptyList(),
            midiPatterns = emptyList()
        )
    }
    
    /**
     * Buat track FX
     */
    private fun createFXTrack(
        fxSamples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String,
        structure: SongStructure,
        tempo: Float
    ): Track {
        val audioClips = mutableListOf<AudioClip>()
        var currentPosition = 0f
        
        // Konversi tempo ke milidetik per beat
        val msPerBeat = 60000f / tempo
        val msPerBar = msPerBeat * 4
        
        // Klasifikasi sampel FX
        val riserSamples = fxSamples.filter { it.name.contains("rise", ignoreCase = true) || it.name.contains("sweep", ignoreCase = true) }
        val impactSamples = fxSamples.filter { it.name.contains("impact", ignoreCase = true) || it.name.contains("hit", ignoreCase = true) }
        val downlifterSamples = fxSamples.filter { it.name.contains("down", ignoreCase = true) || it.name.contains("fall", ignoreCase = true) }
        
        // Bangun FX untuk setiap perubahan bagian song structure
        for (i in 0 until structure.parts.size) {
            val part = structure.parts[i]
            val numBars = part.lengthInBars
            
            // Tambahkan efek transisi sebelum bagian selanjutnya
            if (i < structure.parts.size - 1) {
                val nextPart = structure.parts[i + 1]
                
                // Riser sebelum drop atau chorus
                if (nextPart.type == PartType.DROP || nextPart.type == PartType.CHORUS) {
                    val riserSample = riserSamples.randomOrNull()
                    if (riserSample != null) {
                        // Posisikan riser 1-2 bar sebelum transisi
                        val startTime = (currentPosition + numBars * msPerBar) - (2 * msPerBar)
                        audioClips.add(
                            AudioClip(
                                name = "Riser",
                                filePath = riserSample.filePath,
                                startTime = startTime / 1000f, // convert to seconds
                                duration = riserSample.duration,
                                isLooping = false
                            )
                        )
                    }
                }
                
                // Impact pada awal drop atau chorus
                if (nextPart.type == PartType.DROP || nextPart.type == PartType.CHORUS) {
                    val impactSample = impactSamples.randomOrNull()
                    if (impactSample != null) {
                        // Posisikan impact tepat di awal transisi
                        val startTime = currentPosition + numBars * msPerBar
                        audioClips.add(
                            AudioClip(
                                name = "Impact",
                                filePath = impactSample.filePath,
                                startTime = startTime / 1000f,
                                duration = impactSample.duration,
                                isLooping = false
                            )
                        )
                    }
                }
                
                // Downlifter setelah drop atau chorus
                if (part.type == PartType.DROP || part.type == PartType.CHORUS) {
                    val downlifterSample = downlifterSamples.randomOrNull()
                    if (downlifterSample != null) {
                        // Posisikan downlifter tepat di akhir bagian
                        val startTime = currentPosition + numBars * msPerBar - msPerBar
                        audioClips.add(
                            AudioClip(
                                name = "Downlifter",
                                filePath = downlifterSample.filePath,
                                startTime = startTime / 1000f,
                                duration = downlifterSample.duration,
                                isLooping = false
                            )
                        )
                    }
                }
            }
            
            // Pindah ke posisi selanjutnya
            currentPosition += numBars * msPerBar
        }
        
        return Track(
            name = "FX",
            audioClips = audioClips,
            midiPatterns = emptyList()
        )
    }
    
    /**
     * Buat track vokal
     */
    private fun createVocalTrack(
        vocalSamples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String,
        structure: SongStructure,
        tempo: Float,
        key: String
    ): Track {
        val audioClips = mutableListOf<AudioClip>()
        var currentPosition = 0f
        
        // Konversi tempo ke milidetik per beat
        val msPerBeat = 60000f / tempo
        val msPerBar = msPerBeat * 4
        
        // Bangun pattern untuk setiap bagian song structure
        for (part in structure.parts) {
            // Tempatkan vokal hanya pada bagian tertentu
            if (part.type == PartType.CHORUS || part.type == PartType.VERSE) {
                // Cari sampel vokal yang cocok dengan genre
                val matchingSamples = vocalSamples.filter { sample ->
                    when {
                        genre.contains("bantengan", ignoreCase = true) -> 
                            sample.name.contains("ethnic", ignoreCase = true) || sample.name.contains("shout", ignoreCase = true)
                        genre.contains("nrotok", ignoreCase = true) -> 
                            sample.name.contains("chop", ignoreCase = true) || sample.name.contains("cut", ignoreCase = true)
                        genre.contains("trap", ignoreCase = true) -> 
                            sample.name.contains("trap", ignoreCase = true) || sample.name.contains("adlib", ignoreCase = true)
                        else -> true
                    }
                }
                
                if (matchingSamples.isNotEmpty()) {
                    // Pilih sampel vokal acak yang cocok
                    val vocalSample = matchingSamples.random()
                    
                    // Tentukan jumlah pengulangan dalam bagian ini
                    val repeatCount = if (part.lengthInBars >= 8) 4 else 2
                    
                    // Posisikan sampel vokal berulang kali
                    for (i in 0 until repeatCount) {
                        val startTime = currentPosition + (i * part.lengthInBars * msPerBar / repeatCount)
                        audioClips.add(
                            AudioClip(
                                name = "Vocal",
                                filePath = vocalSample.filePath,
                                startTime = startTime / 1000f, // convert to seconds
                                duration = vocalSample.duration,
                                isLooping = false
                            )
                        )
                    }
                }
            }
            
            // Pindah ke posisi selanjutnya
            currentPosition += part.lengthInBars * msPerBar
        }
        
        return Track(
            name = "Vocals",
            audioClips = audioClips,
            midiPatterns = emptyList()
        )
    }
    
    /**
     * Buat track ethnic untuk genre Indonesia
     */
    private fun createEthnicTrack(
        ethnicSamples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String,
        structure: SongStructure,
        tempo: Float,
        key: String,
        scale: IntArray
    ): Track {
        val audioClips = mutableListOf<AudioClip>()
        val midiPatterns = mutableListOf<MidiPattern>()
        var currentPosition = 0f
        
        // Konversi tempo ke milidetik per beat
        val msPerBeat = 60000f / tempo
        val msPerBar = msPerBeat * 4
        
        // Pilih sampel
        val gamelanSamples = ethnicSamples.filter { it.name.contains("gamelan", ignoreCase = true) }
        val gongSamples = ethnicSamples.filter { it.name.contains("gong", ignoreCase = true) }
        val kendangSamples = ethnicSamples.filter { it.name.contains("kendang", ignoreCase = true) }
        
        // Bangun pattern untuk setiap bagian song structure
        for (part in structure.parts) {
            // Ambil pattern yang sesuai dengan genre dan bagian strukturnya
            val ethnicPattern = when {
                genre.contains("bantengan", ignoreCase = true) -> getPatternForPart(genre, "gamelan", part.type)
                genre.contains("nrotok", ignoreCase = true) -> getPatternForPart(genre, "ethnic", part.type)
                genre.contains("koplo", ignoreCase = true) -> getPatternForPart(genre, "ethnic", part.type)
                else -> getPatternForPart(genre, "ethnic", part.type)
            }
            
            val gongPattern = getPatternForPart(genre, "gong", part.type)
            
            // Jumlah bar dalam bagian ini
            val numBars = part.lengthInBars
            
            // Tambahkan gamelan pattern jika ada sampel
            if (gamelanSamples.isNotEmpty()) {
                val gamelanSample = gamelanSamples.random()
                
                for (bar in 0 until numBars) {
                    for (step in 0 until GRID_RESOLUTION) {
                        if (ethnicPattern[step % ethnicPattern.size] > 0) {
                            val startTime = currentPosition + bar * msPerBar + step * (msPerBar / GRID_RESOLUTION)
                            audioClips.add(
                                AudioClip(
                                    name = "Gamelan",
                                    filePath = gamelanSample.filePath,
                                    startTime = startTime / 1000f, // convert to seconds
                                    duration = gamelanSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
            }
            
            // Tambahkan gong pattern
            if (gongSamples.isNotEmpty()) {
                val gongSample = gongSamples.random()
                
                for (bar in 0 until numBars) {
                    for (step in 0 until GRID_RESOLUTION) {
                        if (gongPattern[step % gongPattern.size] > 0) {
                            val startTime = currentPosition + bar * msPerBar + step * (msPerBar / GRID_RESOLUTION)
                            audioClips.add(
                                AudioClip(
                                    name = "Gong",
                                    filePath = gongSample.filePath,
                                    startTime = startTime / 1000f,
                                    duration = gongSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
            }
            
            // Tambahkan kendang pattern
            if (kendangSamples.isNotEmpty() && genre.contains("koplo", ignoreCase = true)) {
                val kendangSample = kendangSamples.random()
                val kendangPattern = getPatternForPart(genre, "ethnic", part.type)
                
                for (bar in 0 until numBars) {
                    for (step in 0 until GRID_RESOLUTION) {
                        if (kendangPattern[step % kendangPattern.size] > 0) {
                            val startTime = currentPosition + bar * msPerBar + step * (msPerBar / GRID_RESOLUTION)
                            audioClips.add(
                                AudioClip(
                                    name = "Kendang",
                                    filePath = kendangSample.filePath,
                                    startTime = startTime / 1000f,
                                    duration = kendangSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
            }
            
            // Pindah ke posisi selanjutnya
            currentPosition += numBars * msPerBar
        }
        
        return Track(
            name = if (genre.contains("bantengan", ignoreCase = true)) "Gamelan" else "Ethnic",
            audioClips = audioClips,
            midiPatterns = midiPatterns
        )
    }
    
    /**
     * Terapkan efek dan automation pada tracks
     */
    private fun applyEffectsAndAutomation(
        tracks: List<Track>,
        genre: String
    ): List<Track> {
        return tracks.map { track ->
            // Tambahkan efek dan automation yang sesuai dengan jenis track dan genre
            val effects = mutableListOf<Effect>()
            
            when {
                track.isDrumTrack -> {
                    // EQ untuk drum
                    effects.add(
                        Effect(
                            name = "DrumEQ",
                            type = "eq",
                            settings = mapOf(
                                "low_boost" to 0.6f,
                                "mid_cut" to 0.4f,
                                "high_boost" to 0.55f
                            )
                        )
                    )
                    
                    // Compression untuk drum
                    effects.add(
                        Effect(
                            name = "DrumComp",
                            type = "compressor",
                            settings = mapOf(
                                "threshold" to 0.65f,
                                "ratio" to 0.4f,
                                "attack" to 0.2f,
                                "release" to 0.4f
                            )
                        )
                    )
                    
                    // Tambahan efek untuk genre tertentu
                    if (genre.contains("nrotok", ignoreCase = true)) {
                        effects.add(
                            Effect(
                                name = "DrumDistortion",
                                type = "distortion",
                                settings = mapOf(
                                    "drive" to 0.3f,
                                    "tone" to 0.6f
                                )
                            )
                        )
                    }
                }
                
                track.name.contains("Bass", ignoreCase = true) -> {
                    // EQ untuk bass
                    effects.add(
                        Effect(
                            name = "BassEQ",
                            type = "eq",
                            settings = mapOf(
                                "low_boost" to 0.65f,
                                "low_mid_cut" to 0.5f,
                                "high_cut" to 0.3f
                            )
                        )
                    )
                    
                    // Compression untuk bass
                    effects.add(
                        Effect(
                            name = "BassComp",
                            type = "compressor",
                            settings = mapOf(
                                "threshold" to 0.6f,
                                "ratio" to 0.5f,
                                "attack" to 0.3f,
                                "release" to 0.6f
                            )
                        )
                    )
                    
                    // Tambahan efek untuk genre tertentu
                    if (genre.contains("trap", ignoreCase = true)) {
                        effects.add(
                            Effect(
                                name = "BassSaturation",
                                type = "saturation",
                                settings = mapOf(
                                    "drive" to 0.4f,
                                    "type" to 0.5f
                                )
                            )
                        )
                    }
                }
                
                track.name.contains("Melody", ignoreCase = true) -> {
                    // EQ untuk melodi
                    effects.add(
                        Effect(
                            name = "MelodyEQ",
                            type = "eq",
                            settings = mapOf(
                                "low_cut" to 0.4f,
                                "mid_boost" to 0.55f,
                                "high_boost" to 0.5f
                            )
                        )
                    )
                    
                    // Reverb untuk melodi
                    effects.add(
                        Effect(
                            name = "MelodyReverb",
                            type = "reverb",
                            settings = mapOf(
                                "size" to 0.4f,
                                "decay" to 0.5f,
                                "mix" to 0.3f
                            )
                        )
                    )
                    
                    // Delay untuk melodi
                    effects.add(
                        Effect(
                            name = "MelodyDelay",
                            type = "delay",
                            settings = mapOf(
                                "time" to 0.5f,
                                "feedback" to 0.4f,
                                "mix" to 0.25f
                            )
                        )
                    )
                }
                
                track.name.contains("FX", ignoreCase = true) -> {
                    // Reverb untuk FX
                    effects.add(
                        Effect(
                            name = "FXReverb",
                            type = "reverb",
                            settings = mapOf(
                                "size" to 0.6f,
                                "decay" to 0.7f,
                                "mix" to 0.5f
                            )
                        )
                    )
                }
                
                track.name.contains("Vocal", ignoreCase = true) -> {
                    // EQ untuk vocal
                    effects.add(
                        Effect(
                            name = "VocalEQ",
                            type = "eq",
                            settings = mapOf(
                                "low_cut" to 0.3f,
                                "mid_boost" to 0.6f,
                                "high_boost" to 0.5f
                            )
                        )
                    )
                    
                    // Compression untuk vocal
                    effects.add(
                        Effect(
                            name = "VocalComp",
                            type = "compressor",
                            settings = mapOf(
                                "threshold" to 0.7f,
                                "ratio" to 0.4f,
                                "attack" to 0.1f,
                                "release" to 0.3f
                            )
                        )
                    )
                    
                    // Reverb untuk vocal
                    effects.add(
                        Effect(
                            name = "VocalReverb",
                            type = "reverb",
                            settings = mapOf(
                                "size" to 0.4f,
                                "decay" to 0.5f,
                                "mix" to 0.25f
                            )
                        )
                    )
                }
                
                track.name.contains("Gamelan", ignoreCase = true) || 
                track.name.contains("Ethnic", ignoreCase = true) -> {
                    // EQ untuk ethnic instruments
                    effects.add(
                        Effect(
                            name = "EthnicEQ",
                            type = "eq",
                            settings = mapOf(
                                "low_mid_boost" to 0.55f,
                                "high_mid_boost" to 0.6f
                            )
                        )
                    )
                    
                    // Reverb untuk ethnic instruments
                    effects.add(
                        Effect(
                            name = "EthnicReverb",
                            type = "reverb",
                            settings = mapOf(
                                "size" to 0.5f,
                                "decay" to 0.6f,
                                "mix" to 0.3f
                            )
                        )
                    )
                }
            }
            
            // Automation untuk track volume pada buildups jika diperlukan
            val automations = mutableListOf<Automation>()
            
            track.copy(
                effects = effects,
                automations = automations
            )
        }
    }
    
    /**
     * Ambil pattern berdasarkan genre, jenis, dan tipe bagian
     */
    private fun getPatternForPart(genre: String, patternType: String, partType: PartType): IntArray {
        // Ambil patterns untuk genre tertentu jika tersedia
        val genrePatterns = GENRE_PATTERNS[genre] ?: GENRE_PATTERNS["DJ Bantengan"]!!
        
        // Ambil pattern list berdasarkan tipe pattern
        val patternKey = "${patternType}Patterns"
        val patterns = genrePatterns[patternKey] as? List<IntArray> ?: return IntArray(16) { 0 }
        
        // Pilih pattern berdasarkan tipe bagian
        val patternIndex = when (partType) {
            PartType.INTRO -> 0
            PartType.VERSE -> 0
            PartType.CHORUS -> 1
            PartType.DROP -> 2
            PartType.BUILD -> 1
            PartType.BREAKDOWN -> 0
            PartType.BRIDGE -> 1
            PartType.OUTRO -> 0
        } % patterns.size
        
        return patterns[patternIndex]
    }
    
    /**
     * Hasilkan sequence melodi berdasarkan skala, chord, dan genre
     */
    private fun generateMelodicSequence(
        scaleNotes: List<Int>,
        chordNotes: List<Int>,
        style: String,
        partType: PartType
    ): IntArray {
        val sequence = IntArray(16) { -1 } // -1 means no note
        
        // Tentukan pola berdasarkan style
        when (style) {
            "pelog" -> {
                // Pola melodi gamelan-inspired
                sequence[0] = chordNotes[0] // root
                sequence[2] = scaleNotes[2] // 3rd scale degree
                sequence[4] = chordNotes[0] // root
                sequence[7] = scaleNotes[4] // 5th scale degree
                sequence[8] = chordNotes[0] + 12 // root octave up
                sequence[10] = scaleNotes[6] // 7th scale degree
                sequence[12] = chordNotes[0] // root
                sequence[14] = scaleNotes[2] // 3rd scale degree
            }
            
            "nrotok" -> {
                // Pola melodi repetitif dan energik
                sequence[0] = chordNotes[0] // root
                sequence[1] = chordNotes[0] // root
                sequence[3] = scaleNotes[2] // 3rd scale degree
                sequence[4] = chordNotes[1] // 3rd chord
                sequence[6] = scaleNotes[4] // 5th scale degree
                sequence[8] = chordNotes[0] + 12 // root octave up
                sequence[10] = chordNotes[0] + 12 // root octave up
                sequence[12] = scaleNotes[6] // 7th scale degree
                sequence[14] = scaleNotes[4] // 5th scale degree
            }
            
            "trap" -> {
                // Pola melodi trap style
                sequence[0] = chordNotes[0] // root
                sequence[3] = scaleNotes[2] // 3rd scale degree
                sequence[6] = chordNotes[1] // 3rd chord
                sequence[9] = scaleNotes[4] // 5th scale degree
                sequence[12] = chordNotes[0] // root
                sequence[15] = scaleNotes[6] // 7th scale degree
            }
            
            else -> {
                // Pola melodi default
                sequence[0] = chordNotes[0] // root
                sequence[4] = scaleNotes[2] // 3rd scale degree
                sequence[8] = chordNotes[1] // 3rd chord
                sequence[12] = scaleNotes[4] // 5th scale degree
            }
        }
        
        // Untuk chorus dan drop, tambahkan nada untuk densitas yang lebih tinggi
        if (partType == PartType.CHORUS || partType == PartType.DROP) {
            for (i in 0 until 16) {
                if (sequence[i] == -1 && Random().nextFloat() > 0.7) {
                    // Tambahkan passing notes
                    sequence[i] = scaleNotes.random()
                }
            }
        }
        
        return sequence
    }
    
    /**
     * Konversi nama kunci ke MIDI note number
     */
    private fun keyNameToMidiNote(key: String): Int {
        val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
        val isMinor = key.endsWith("m")
        
        val rootName = if (isMinor) key.substring(0, key.length - 1) else key
        val rootIndex = noteNames.indexOf(rootName)
        
        return if (rootIndex >= 0) {
            rootIndex + 60 // Start from C3
        } else {
            60 // Default: C3
        }
    }
    
    /**
     * Dapatkan nada-nada dalam chord
     */
    private fun getChordNotes(chord: Chord, rootMidi: Int, scale: IntArray): List<Int> {
        val rootNote = (rootMidi + chord.rootNote) % 12 + 60 // adjust to C3 octave
        
        return when (chord.chordType) {
            ChordType.MAJOR -> listOf(rootNote, rootNote + 4, rootNote + 7)
            ChordType.MINOR -> listOf(rootNote, rootNote + 3, rootNote + 7)
            ChordType.DIMINISHED -> listOf(rootNote, rootNote + 3, rootNote + 6)
            ChordType.AUGMENTED -> listOf(rootNote, rootNote + 4, rootNote + 8)
            ChordType.DOMINANT7 -> listOf(rootNote, rootNote + 4, rootNote + 7, rootNote + 10)
            ChordType.MAJOR7 -> listOf(rootNote, rootNote + 4, rootNote + 7, rootNote + 11)
            ChordType.MINOR7 -> listOf(rootNote, rootNote + 3, rootNote + 7, rootNote + 10)
        }
    }
    
    /**
     * Dapatkan nada-nada dalam skala
     */
    private fun getScaleNotes(rootMidi: Int, scale: IntArray): List<Int> {
        val rootNote = rootMidi % 12 + 60 // adjust to C3 octave
        
        return scale.map { rootNote + it }
    }
    
    /**
     * Kalkulasi durasi proyek total
     */
    private fun calculateProjectDuration(tracks: List<Track>, tempo: Float): Float {
        // Konversi tempo ke detik per beat
        val secondsPerBeat = 60f / tempo
        
        // Cari clip audio atau pattern MIDI terakhir
        var maxEndTime = 0f
        
        for (track in tracks) {
            // Cek audio clips
            for (clip in track.audioClips) {
                val endTime = clip.startTime + clip.duration
                if (endTime > maxEndTime) {
                    maxEndTime = endTime
                }
            }
            
            // Cek MIDI patterns
            for (pattern in track.midiPatterns) {
                val endTime = pattern.startTime + pattern.duration * secondsPerBeat
                if (endTime > maxEndTime) {
                    maxEndTime = endTime
                }
            }
        }
        
        return maxEndTime
    }
    
    /**
     * Buat proyek sederhana (fallback jika AI gagal)
     */
    private fun createBasicProject(
        samples: List<AudioSampleExtractorAI.AudioSample>,
        genre: String,
        projectName: String
    ): Project {
        // Tentukan tempo berdasarkan genre
        val tempo = when {
            genre.contains("bantengan", ignoreCase = true) -> 100f
            genre.contains("nrotok", ignoreCase = true) -> 150f
            genre.contains("koplo", ignoreCase = true) -> 140f
            genre.contains("dangdut", ignoreCase = true) -> 120f
            genre.contains("trap", ignoreCase = true) -> 140f
            genre.contains("edm", ignoreCase = true) -> 128f
            else -> 120f
        }
        
        // Buat track sederhana
        val tracks = mutableListOf<Track>()
        
        // Track drum sederhana jika ada sampel perkusi
        val percussionSamples = samples.filter { it.category.equals("percussion", ignoreCase = true) }
        if (percussionSamples.isNotEmpty()) {
            val kickSample = percussionSamples.firstOrNull { it.name.contains("kick", ignoreCase = true) }
            val snareSample = percussionSamples.firstOrNull { it.name.contains("snare", ignoreCase = true) }
            val hihatSample = percussionSamples.firstOrNull { 
                it.name.contains("hat", ignoreCase = true) || it.name.contains("hi-hat", ignoreCase = true) 
            }
            
            val audioClips = mutableListOf<AudioClip>()
            
            // Basic 4/4 pattern
            if (kickSample != null) {
                for (bar in 0 until 4) {
                    for (beat in 0 until 4) {
                        if (beat == 0 || beat == 2) {
                            audioClips.add(
                                AudioClip(
                                    name = "Kick",
                                    filePath = kickSample.filePath,
                                    startTime = (bar * 4 + beat) * (60f / tempo),
                                    duration = kickSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
            }
            
            if (snareSample != null) {
                for (bar in 0 until 4) {
                    for (beat in 0 until 4) {
                        if (beat == 1 || beat == 3) {
                            audioClips.add(
                                AudioClip(
                                    name = "Snare",
                                    filePath = snareSample.filePath,
                                    startTime = (bar * 4 + beat) * (60f / tempo),
                                    duration = snareSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
            }
            
            if (hihatSample != null) {
                for (bar in 0 until 4) {
                    for (beat in 0 until 4) {
                        for (sixteenth in 0 until 4) {
                            audioClips.add(
                                AudioClip(
                                    name = "HiHat",
                                    filePath = hihatSample.filePath,
                                    startTime = (bar * 4 + beat + sixteenth * 0.25f) * (60f / tempo),
                                    duration = hihatSample.duration,
                                    isLooping = false
                                )
                            )
                        }
                    }
                }
            }
            
            tracks.add(
                Track(
                    name = "Drums",
                    audioClips = audioClips,
                    midiPatterns = emptyList(),
                    isDrumTrack = true
                )
            )
        }
        
        // Track bass sederhana jika ada sampel bass
        val bassSamples = samples.filter { it.category.equals("bass", ignoreCase = true) }
        if (bassSamples.isNotEmpty()) {
            val bassSample = bassSamples.first()
            
            val audioClips = mutableListOf<AudioClip>()
            
            // Basic bass pattern
            for (bar in 0 until 4) {
                audioClips.add(
                    AudioClip(
                        name = "Bass",
                        filePath = bassSample.filePath,
                        startTime = bar * 4 * (60f / tempo),
                        duration = bassSample.duration,
                        isLooping = false
                    )
                )
            }
            
            tracks.add(
                Track(
                    name = "Bass",
                    audioClips = audioClips,
                    midiPatterns = emptyList()
                )
            )
        }
        
        // Buat proyek
        return Project(
            name = projectName,
            tempo = tempo,
            timeSignatureNumerator = 4,
            timeSignatureDenominator = 4,
            tracks = tracks,
            duration = 16f // 16 beats = 4 bars
        )
    }
    
    /**
     * Jenis chord
     */
    enum class ChordType {
        MAJOR, MINOR, DIMINISHED, AUGMENTED, DOMINANT7, MAJOR7, MINOR7
    }
    
    /**
     * Data class untuk chord
     */
    data class Chord(
        val rootNote: Int, // 0 = C, 1 = C#, etc.
        val chordType: ChordType,
        val durationInBeats: Int = 4 // default 1 bar
    )
    
    /**
     * Tipe bagian dalam song structure
     */
    enum class PartType {
        INTRO, VERSE, CHORUS, DROP, BUILD, BREAKDOWN, BRIDGE, OUTRO
    }
    
    /**
     * Data class untuk bagian lagu
     */
    data class SongPart(
        val type: PartType,
        val lengthInBars: Int
    )
    
    /**
     * Data class untuk struktur lagu
     */
    data class SongStructure(
        val parts: List<SongPart>
    )
}