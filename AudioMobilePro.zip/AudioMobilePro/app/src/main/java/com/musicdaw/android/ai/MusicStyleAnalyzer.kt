package com.musicdaw.android.ai

import com.musicdaw.android.model.*
import java.util.*
import kotlin.math.abs
import kotlin.math.max

/**
 * Class untuk menganalisis gaya musik dari proyek pengguna
 * dan membangun profil musik pengguna untuk rekomendasi
 */
class MusicStyleAnalyzer {

    companion object {
        private const val RECENCY_WEIGHT = 0.7f // Bobot untuk proyek terbaru
        private const val GENRE_THRESHOLD = 0.1f // Threshold untuk menentukan genre favorit
        private const val KEY_THRESHOLD = 0.1f // Threshold untuk menentukan kunci favorit
        private const val TEMPO_RANGE = 10f // Range untuk mengelompokkan tempo serupa
    }
    
    /**
     * Menganalisis proyek untuk mendapatkan profil musik pengguna
     */
    fun analyzeProject(
        project: Project,
        currentProfile: UserMusicProfile? = null,
        userId: String = "user_" + UUID.randomUUID().toString()
    ): UserMusicProfile {
        // Jika sudah ada profil, gunakan sebagai basis, jika tidak buat baru
        val baseProfile = currentProfile ?: createEmptyProfile(userId)
        
        // Ekstrak fitur dari proyek
        val projectGenres = detectGenres(project)
        val projectKey = detectKey(project)
        val projectTempo = project.tempo
        val projectComplexity = calculateComplexity(project)
        val instruments = detectInstruments(project)
        val melodicTraits = analyzeMelodicTraits(project)
        val creationTimeOfDay = getCurrentTimeOfDay()
        
        // Perbarui profil musik berdasarkan proyek baru
        return updateProfile(
            baseProfile,
            projectGenres,
            projectKey,
            projectTempo,
            projectComplexity,
            instruments,
            melodicTraits,
            creationTimeOfDay
        )
    }
    
    /**
     * Buat profil musik kosong untuk pengguna baru
     */
    private fun createEmptyProfile(userId: String): UserMusicProfile {
        return UserMusicProfile(
            userId = userId,
            favoriteGenres = emptyMap(),
            favoriteKeys = emptyMap(),
            tempoPreference = TempoPreference(
                meanTempo = 120f,
                minTempo = 120f,
                maxTempo = 120f,
                favoriteTempoRanges = emptyList()
            ),
            rhythmComplexity = 0.5f,
            harmonicComplexity = 0.5f,
            melodicTraits = emptyList(),
            instrumentPreferences = emptyMap(),
            productionStyle = emptyMap(),
            creationTimestamps = emptyMap(),
            sessionDuration = 30f,
            musicalInfluences = emptyList(),
            experimentalness = 0.5f,
            consistencyScore = 0.5f
        )
    }
    
    /**
     * Perbarui profil musik dengan data dari proyek baru
     */
    private fun updateProfile(
        currentProfile: UserMusicProfile,
        genres: Map<String, Float>,
        key: String,
        tempo: Float,
        complexity: Pair<Float, Float>, // (rhythm, harmonic)
        instruments: Map<String, Float>,
        melodicTraits: List<String>,
        timeOfDay: TimeOfDay
    ): UserMusicProfile {
        // Perbarui genre favorit (gabungkan dengan bobot)
        val updatedGenres = updateWeightedMap(
            currentProfile.favoriteGenres,
            genres,
            RECENCY_WEIGHT
        )
        
        // Perbarui kunci favorit
        val updatedKeys = updateWeightedMap(
            currentProfile.favoriteKeys,
            mapOf(key to 1.0f),
            RECENCY_WEIGHT
        )
        
        // Perbarui preferensi tempo
        val updatedTempoPreference = updateTempoPreference(
            currentProfile.tempoPreference,
            tempo
        )
        
        // Perbarui preferensi instrumen
        val updatedInstruments = updateWeightedMap(
            currentProfile.instrumentPreferences,
            instruments,
            RECENCY_WEIGHT
        )
        
        // Perbarui timestamp pembuatan musik
        val updatedTimestamps = updateWeightedMap(
            currentProfile.creationTimestamps,
            mapOf(timeOfDay to 1.0f),
            RECENCY_WEIGHT
        )
        
        // Perbarui trait melodi
        val updatedMelodicTraits = updateTraits(
            currentProfile.melodicTraits,
            melodicTraits
        )
        
        // Hitung konsistensi dari profil yang diperbarui
        val consistencyScore = calculateConsistencyScore(
            updatedGenres,
            updatedKeys,
            updatedTempoPreference
        )
        
        // Kembalikan profil yang diperbarui
        return currentProfile.copy(
            favoriteGenres = updatedGenres,
            favoriteKeys = updatedKeys,
            tempoPreference = updatedTempoPreference,
            rhythmComplexity = (currentProfile.rhythmComplexity * (1 - RECENCY_WEIGHT) + 
                                complexity.first * RECENCY_WEIGHT),
            harmonicComplexity = (currentProfile.harmonicComplexity * (1 - RECENCY_WEIGHT) + 
                                  complexity.second * RECENCY_WEIGHT),
            melodicTraits = updatedMelodicTraits,
            instrumentPreferences = updatedInstruments,
            creationTimestamps = updatedTimestamps,
            lastUpdated = Date(),
            consistencyScore = consistencyScore
        )
    }
    
    /**
     * Deteksi genre proyek berdasarkan karakteristik musik
     */
    private fun detectGenres(project: Project): Map<String, Float> {
        // Dalam implementasi nyata, ini akan menggunakan analisis AI mendalam
        // Untuk sekarang, gunakan deteksi genre simpel berdasarkan karakteristik proyek
        
        val genreScores = mutableMapOf<String, Float>()
        
        // Cek apakah proyek mungkin adalah Electronic
        val hasElectronicCharacteristics = project.tracks.any { track ->
            track.type == TrackType.MIDI || 
            track.instrument?.type?.contains("synth", ignoreCase = true) == true
        }
        if (hasElectronicCharacteristics) {
            genreScores["Electronic"] = 0.8f
        }
        
        // Cek untuk Hip-Hop berdasarkan tempo dan track drum
        val hasHipHopCharacteristics = project.tempo in 85f..105f && 
            project.tracks.any { it.isDrumTrack }
        if (hasHipHopCharacteristics) {
            genreScores["Hip-Hop"] = 0.7f
        }
        
        // Cek untuk Rock berdasarkan instrumen
        val hasRockCharacteristics = project.tracks.any { track ->
            track.name.contains("guitar", ignoreCase = true) ||
            track.instrument?.name?.contains("guitar", ignoreCase = true) == true
        }
        if (hasRockCharacteristics) {
            genreScores["Rock"] = 0.7f
        }
        
        // Cek untuk Classical/Orchestral
        val hasOrchestralCharacteristics = project.tracks.any { track ->
            track.name.contains("strings", ignoreCase = true) ||
            track.name.contains("orchestra", ignoreCase = true) ||
            track.instrument?.name?.contains("piano", ignoreCase = true) == true
        }
        if (hasOrchestralCharacteristics) {
            genreScores["Classical"] = 0.6f
        }
        
        // Cek untuk Ambient berdasarkan tempo lambat dan efek
        val hasAmbientCharacteristics = project.tempo < 90f &&
            project.tracks.any { track ->
                track.effects.any { it.type.contains("reverb", ignoreCase = true) }
            }
        if (hasAmbientCharacteristics) {
            genreScores["Ambient"] = 0.7f
        }
        
        // Jika tidak ada genre yang terdeteksi, tambahkan genre default
        if (genreScores.isEmpty()) {
            genreScores["Electronic"] = 0.4f
            genreScores["Pop"] = 0.3f
        }
        
        return genreScores
    }
    
    /**
     * Deteksi kunci musik dari proyek
     */
    private fun detectKey(project: Project): String {
        // Dalam implementasi nyata, ini akan menggunakan analisis harmoni AI
        // Untuk prototype, kita gunakan kunci proyek atau default
        return project.key
    }
    
    /**
     * Hitung kompleksitas ritme dan harmoni proyek
     */
    private fun calculateComplexity(project: Project): Pair<Float, Float> {
        var rhythmComplexity = 0.5f
        var harmonicComplexity = 0.5f
        
        // Analisis track MIDI untuk kompleksitas
        val midiTracks = project.tracks.filter { it.type == TrackType.MIDI }
        if (midiTracks.isNotEmpty()) {
            // Kompleksitas ritme berdasarkan variasi nilai note
            val noteDurations = midiTracks.flatMap { track ->
                track.midiPatterns.flatMap { pattern ->
                    pattern.notes.map { it.duration }
                }
            }.distinct()
            
            // Lebih banyak variasi durasi note = lebih kompleks ritme
            rhythmComplexity = (noteDurations.size / 5f).coerceAtMost(1f)
            
            // Kompleksitas harmoni berdasarkan range note dan kepadatan chord
            val noteRange = midiTracks.flatMap { track ->
                track.midiPatterns.flatMap { pattern ->
                    pattern.notes.map { it.note }
                }
            }.let { notes ->
                if (notes.isEmpty()) 0 else notes.maxOrNull()!! - notes.minOrNull()!!
            }
            
            // Range note yang lebih luas & kepadatan note yang lebih tinggi = harmoni lebih kompleks
            harmonicComplexity = (noteRange / 48f).coerceAtMost(1f)
        }
        
        // Faktor tambahan: kompleksitas time signature
        if (project.timeSignatureNumerator > 4 || project.timeSignatureDenominator != 4) {
            rhythmComplexity = (rhythmComplexity + 0.2f).coerceAtMost(1f)
        }
        
        return Pair(rhythmComplexity, harmonicComplexity)
    }
    
    /**
     * Deteksi instrumen yang digunakan dalam proyek
     */
    private fun detectInstruments(project: Project): Map<String, Float> {
        val instruments = mutableMapOf<String, Float>()
        
        // Analisis track untuk mendeteksi instrumen
        project.tracks.forEach { track ->
            // Dari nama track
            val nameLower = track.name.lowercase()
            when {
                nameLower.contains("kick") || nameLower.contains("drum") -> 
                    instruments["Drums"] = (instruments["Drums"] ?: 0f) + 0.8f
                nameLower.contains("bass") -> 
                    instruments["Bass"] = (instruments["Bass"] ?: 0f) + 0.8f
                nameLower.contains("synth") -> 
                    instruments["Synthesizers"] = (instruments["Synthesizers"] ?: 0f) + 0.8f
                nameLower.contains("piano") -> 
                    instruments["Piano"] = (instruments["Piano"] ?: 0f) + 0.8f
                nameLower.contains("guitar") -> 
                    instruments["Guitar"] = (instruments["Guitar"] ?: 0f) + 0.8f
                nameLower.contains("strings") -> 
                    instruments["Strings"] = (instruments["Strings"] ?: 0f) + 0.8f
                nameLower.contains("vocal") || nameLower.contains("vox") || nameLower.contains("voice") -> 
                    instruments["Vocals"] = (instruments["Vocals"] ?: 0f) + 0.8f
            }
            
            // Dari nama instrumen
            track.instrument?.let { instrument ->
                val instrumentName = when {
                    instrument.name.contains("piano", ignoreCase = true) -> "Piano"
                    instrument.name.contains("synth", ignoreCase = true) -> "Synthesizers"
                    instrument.name.contains("bass", ignoreCase = true) -> "Bass"
                    instrument.name.contains("guitar", ignoreCase = true) -> "Guitar"
                    instrument.name.contains("drum", ignoreCase = true) -> "Drums"
                    instrument.name.contains("string", ignoreCase = true) -> "Strings"
                    instrument.name.contains("vocal", ignoreCase = true) -> "Vocals"
                    else -> instrument.name
                }
                
                instruments[instrumentName] = (instruments[instrumentName] ?: 0f) + 1.0f
            }
            
            // Track drum khusus
            if (track.isDrumTrack) {
                instruments["Drums"] = (instruments["Drums"] ?: 0f) + 1.0f
            }
        }
        
        // Normalisasi nilai ke range 0-1
        val maxValue = instruments.values.maxOrNull() ?: 1f
        return instruments.mapValues { it.value / maxValue }
    }
    
    /**
     * Analisis karakteristik melodi dalam proyek
     */
    private fun analyzeMelodicTraits(project: Project): List<String> {
        val traits = mutableListOf<String>()
        var hasArpeggios = false
        var hasStepwiseMotion = false
        var hasLargeIntervals = false
        var hasPentatonic = false
        var hasRepetitivePatterns = false
        
        // Analisis track MIDI untuk pola melodi
        project.tracks.filter { it.type == TrackType.MIDI && !it.isDrumTrack }.forEach { track ->
            track.midiPatterns.forEach { pattern ->
                val notes = pattern.notes.sortedBy { it.startTime }
                if (notes.size < 2) continue
                
                // Cek untuk gerakan stepwise (interval kecil antara note)
                var stepwiseCount = 0
                var largeIntervalCount = 0
                
                for (i in 0 until notes.size - 1) {
                    val interval = abs(notes[i+1].note - notes[i].note)
                    
                    if (interval <= 2) { // Maksimal interval sekunder
                        stepwiseCount++
                    } 
                    else if (interval >= 7) { // Interval kelima atau lebih
                        largeIntervalCount++
                    }
                }
                
                // Deteksi arpeggio (interval 3, 5, 7)
                val arpeggioIntervals = listOf(3, 4, 7)
                var arpeggioCount = 0
                for (i in 0 until notes.size - 1) {
                    val interval = abs(notes[i+1].note - notes[i].note)
                    if (interval in arpeggioIntervals) {
                        arpeggioCount++
                    }
                }
                
                // Deteksi skala pentatonik
                val pentatonicNotes = setOf(0, 2, 4, 7, 9) // C, D, E, G, A dalam C Major Pentatonic
                val normalizedNotes = notes.map { it.note % 12 }.toSet()
                val pentatonicMatchCount = normalizedNotes.intersect(pentatonicNotes).size
                
                // Deteksi pola berulang
                val patternSequences = mutableMapOf<List<Int>, Int>()
                for (i in 0 until notes.size - 3) {
                    val pattern = (0..2).map { notes[i + it].note - notes[i].note }
                    patternSequences[pattern] = (patternSequences[pattern] ?: 0) + 1
                }
                val hasRepeatedPatterns = patternSequences.values.any { it >= 2 }
                
                // Tetapkan ciri berdasarkan threshold
                if (stepwiseCount > notes.size * 0.5) hasStepwiseMotion = true
                if (largeIntervalCount > notes.size * 0.3) hasLargeIntervals = true
                if (arpeggioCount > notes.size * 0.4) hasArpeggios = true
                if (pentatonicMatchCount >= 4) hasPentatonic = true
                if (hasRepeatedPatterns) hasRepetitivePatterns = true
            }
        }
        
        // Tambahkan ciri yang terdeteksi
        if (hasStepwiseMotion) traits.add("Stepwise motion")
        if (hasLargeIntervals) traits.add("Large intervals")
        if (hasArpeggios) traits.add("Arpeggios")
        if (hasPentatonic) traits.add("Pentatonic scales")
        if (hasRepetitivePatterns) traits.add("Repetitive patterns")
        
        // Tambahkan ciri default jika tidak ada yang terdeteksi
        if (traits.isEmpty()) {
            traits.add("Basic melodic patterns")
        }
        
        return traits
    }
    
    /**
     * Dapatkan waktu hari ini untuk pelacakan sesi pembuatan
     */
    private fun getCurrentTimeOfDay(): TimeOfDay {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hour in 5..7 -> TimeOfDay.EARLY_MORNING
            hour in 8..10 -> TimeOfDay.MORNING
            hour in 11..13 -> TimeOfDay.MIDDAY
            hour in 14..16 -> TimeOfDay.AFTERNOON
            hour in 17..19 -> TimeOfDay.EVENING
            hour in 20..22 -> TimeOfDay.NIGHT
            else -> TimeOfDay.LATE_NIGHT
        }
    }
    
    /**
     * Perbarui map dengan bobot, memberi bobot lebih pada nilai baru
     */
    private fun updateWeightedMap(
        currentMap: Map<String, Float>,
        newMap: Map<String, Float>,
        recencyWeight: Float
    ): Map<String, Float> {
        val result = currentMap.toMutableMap()
        
        // Tambahkan entri baru dengan bobot recency
        newMap.forEach { (key, value) ->
            val currentValue = result[key] ?: 0f
            result[key] = currentValue * (1 - recencyWeight) + value * recencyWeight
        }
        
        // Normalisasi nilai jika diperlukan
        val maxValue = result.values.maxOrNull() ?: 1f
        return result.mapValues { it.value / maxValue }
    }
    
    /**
     * Perbarui preferensi tempo berdasarkan tempo proyek baru
     */
    private fun updateTempoPreference(
        current: TempoPreference,
        newTempo: Float
    ): TempoPreference {
        // Perbarui min/max tempo
        val minTempo = minOf(current.minTempo, newTempo)
        val maxTempo = maxOf(current.maxTempo, newTempo)
        
        // Hitung rata-rata baru dengan memberikan bobot pada nilai baru
        val meanTempo = current.meanTempo * (1 - RECENCY_WEIGHT) + newTempo * RECENCY_WEIGHT
        
        // Perbarui range tempo favorit
        val ranges = current.favoriteTempoRanges.toMutableList()
        var addedToRange = false
        
        // Cek apakah tempo baru masuk ke range yang ada
        for (i in ranges.indices) {
            val range = ranges[i]
            if (newTempo >= range.first - TEMPO_RANGE && newTempo <= range.second + TEMPO_RANGE) {
                // Perluas range yang ada
                val newStart = minOf(range.first, newTempo - TEMPO_RANGE / 2)
                val newEnd = maxOf(range.second, newTempo + TEMPO_RANGE / 2)
                ranges[i] = Pair(newStart, newEnd)
                addedToRange = true
                break
            }
        }
        
        // Tambahkan range baru jika tidak ada yang cocok
        if (!addedToRange) {
            ranges.add(Pair(newTempo - TEMPO_RANGE / 2, newTempo + TEMPO_RANGE / 2))
        }
        
        // Batasi jumlah range (jaga yang paling baru)
        val finalRanges = ranges.takeLast(3)
        
        return TempoPreference(
            meanTempo = meanTempo,
            minTempo = minTempo,
            maxTempo = maxTempo,
            favoriteTempoRanges = finalRanges
        )
    }
    
    /**
     * Perbarui daftar ciri dengan menambahkan ciri baru dan menjaga ukuran daftar
     */
    private fun updateTraits(
        currentTraits: List<String>,
        newTraits: List<String>
    ): List<String> {
        val maxTraits = 8
        val combined = (currentTraits + newTraits).distinct()
        
        // Jika daftar terlalu panjang, prioritaskan ciri baru
        return if (combined.size <= maxTraits) {
            combined
        } else {
            val oldTraitsToKeep = maxTraits - newTraits.size
            if (oldTraitsToKeep <= 0) {
                newTraits.take(maxTraits)
            } else {
                currentTraits.take(oldTraitsToKeep) + newTraits
            }
        }
    }
    
    /**
     * Hitung skor konsistensi berdasarkan stabilitas genre, kunci, dan tempo
     */
    private fun calculateConsistencyScore(
        genres: Map<String, Float>,
        keys: Map<String, Float>,
        tempoPreference: TempoPreference
    ): Float {
        // Skor konsistensi genre (berdasarkan dominasi genre teratas)
        val topGenres = genres.entries.sortedByDescending { it.value }.take(3)
        val genreConsistency = if (topGenres.isNotEmpty()) {
            topGenres.first().value / (topGenres.map { it.value }.sum() / topGenres.size)
        } else 0.5f
        
        // Skor konsistensi kunci (berdasarkan dominasi kunci teratas)
        val topKeys = keys.entries.sortedByDescending { it.value }.take(3)
        val keyConsistency = if (topKeys.isNotEmpty()) {
            topKeys.first().value / (topKeys.map { it.value }.sum() / topKeys.size)
        } else 0.5f
        
        // Skor konsistensi tempo (berdasarkan range tempo)
        val tempoRange = tempoPreference.maxTempo - tempoPreference.minTempo
        val tempoConsistency = 1f - (tempoRange / 100f).coerceAtMost(1f)
        
        // Gabungkan semua skor (berikan bobot lebih pada genre)
        return (genreConsistency * 0.5f + keyConsistency * 0.3f + tempoConsistency * 0.2f)
    }
    
    /**
     * Mendapatkan pengaruh musik berdasarkan analisis gaya
     */
    fun detectMusicalInfluences(
        genres: Map<String, Float>,
        melodicTraits: List<String>,
        harmonicComplexity: Float,
        rhythmComplexity: Float
    ): List<String> {
        val influences = mutableListOf<String>()
        
        // Deteksi berdasarkan genre
        val topGenre = genres.entries.maxByOrNull { it.value }?.key
        when (topGenre) {
            "Electronic" -> {
                if (melodicTraits.any { it.contains("Arpeggios", ignoreCase = true) }) {
                    influences.add("Daft Punk")
                }
                if (harmonicComplexity > 0.7f) {
                    influences.add("Aphex Twin")
                }
                if (melodicTraits.any { it.contains("Repetitive", ignoreCase = true) }) {
                    influences.add("Deadmau5")
                }
            }
            "Hip-Hop" -> {
                if (harmonicComplexity > 0.6f) {
                    influences.add("Kendrick Lamar")
                }
                if (rhythmComplexity > 0.7f) {
                    influences.add("J Dilla")
                }
            }
            "Rock" -> {
                if (harmonicComplexity > 0.7f) {
                    influences.add("Radiohead")
                } else {
                    influences.add("The Strokes")
                }
            }
            "Ambient" -> {
                influences.add("Brian Eno")
                if (melodicTraits.any { it.contains("Arpeggios", ignoreCase = true) }) {
                    influences.add("Tycho")
                }
            }
            "Classical" -> {
                if (harmonicComplexity > 0.8f) {
                    influences.add("Debussy")
                } else {
                    influences.add("Mozart")
                }
            }
        }
        
        // Tambahkan pengaruh default jika tidak ada yang terdeteksi
        if (influences.isEmpty()) {
            influences.add("Contemporary Artists")
        }
        
        return influences
    }
}