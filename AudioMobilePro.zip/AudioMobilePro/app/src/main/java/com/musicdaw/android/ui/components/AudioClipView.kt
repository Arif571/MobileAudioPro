package com.musicdaw.android.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.musicdaw.android.model.AudioClip

/**
 * Displays an audio clip in the editor timeline
 */
@Composable
fun AudioClipView(
    clip: AudioClip,
    trackColor: Color,
    zoomLevel: Float,
    onClick: (() -> Unit)? = null
) {
    // Calculate width based on duration and zoom level
    val widthDp = (clip.duration * 50 * zoomLevel).dp
    
    // Position is calculated based on startTime and zoom level in parent component
    
    Box(
        modifier = Modifier
            .width(widthDp)
            .fillMaxHeight()
            .padding(vertical = 2.dp, horizontal = 1.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(trackColor.copy(alpha = 0.7f))
            .then(onClick?.let { Modifier.clickable(onClick = it) } ?: Modifier),
        contentAlignment = Alignment.Center
    ) {
        // Clip name
        Text(
            text = clip.name,
            style = MaterialTheme.typography.bodySmall,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(4.dp)
        )
        
        // TODO: Add waveform visualization using clip.waveformData
    }
}