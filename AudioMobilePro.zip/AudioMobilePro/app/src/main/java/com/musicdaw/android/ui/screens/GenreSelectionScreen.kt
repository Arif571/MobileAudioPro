package com.musicdaw.android.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.musicdaw.android.ai.BassPattern
import com.musicdaw.android.ai.DrumPattern
import com.musicdaw.android.ai.GenreBasedGenerator
import com.musicdaw.android.ai.GenreSpecialistAI
import com.musicdaw.android.model.Project
import kotlinx.coroutines.launch

/**
 * Layar pemilihan genre dengan fokus pada genre lokal Indonesia
 */
@Composable
fun GenreSelectionScreen(
    onGenreSelected: (String, Project) -> Unit
) {
    val genreSpecialist = remember { GenreSpecialistAI() }
    val genreGenerator = remember { GenreBasedGenerator(genreSpecialist) }
    var selectedGenre by remember { mutableStateOf("") }
    var isCreatingProject by remember { mutableStateOf(false) }
    var showGenreDetails by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    
    val allGenres = remember {
        listOf(
            // Genre lokal Indonesia
            GenreInfo(
                name = "DJ Bantengan", 
                description = "Fusion genre menggabungkan irama gamelan tradisional Jawa dengan beat elektronik modern, dipengaruhi oleh musik jaranan dan reog, menciptakan nuansa mistis khas.",
                isLocalIndonesianGenre = true,
                tempo = "145-170 BPM",
                characteristics = "Bass yang dalam, suara gamelan, ketukan energetik, ornamen vokal tradisional"
            ),
            GenreInfo(
                name = "DJ Nrotok", 
                description = "Genre musik elektronik cepat dengan penekanan pada ritme perkusi repetitif dan sample vokal yang dipotong-potong, populer di wilayah Jawa Timur.",
                isLocalIndonesianGenre = true,
                tempo = "150-180 BPM",
                characteristics = "Beat cepat, bass drop berat, vocal chops yang diulang"
            ),
            GenreInfo(
                name = "Koplo", 
                description = "Genre musik dangdut modern dengan ritme kendang yang enerjik dan cepat, sangat populer untuk acara tari dan pertunjukan.",
                isLocalIndonesianGenre = true,
                tempo = "135-160 BPM",
                characteristics = "Pola kendang kompleks, ornamentasi melodi, suara ketipung"
            ),
            GenreInfo(
                name = "Dangdut", 
                description = "Genre musik populer Indonesia dengan pengaruh Melayu, Arab dan Hindustan, dengan ciri khas tabla/ketipung dan melodi melismatis.",
                isLocalIndonesianGenre = true,
                tempo = "110-130 BPM",
                characteristics = "Ritme tabla/ketipung, melodi ornamental, nuansa Timur Tengah"
            ),
            
            // Genre internasional
            GenreInfo(
                name = "Trap", 
                description = "Genre hip-hop dengan aksen pada hi-hat triplet, 808 bass berat, dan sub-bass yang kuat.",
                isLocalIndonesianGenre = false,
                tempo = "130-160 BPM",
                characteristics = "Hi-hat triplet, 808 bass yang berat, vocal chops"
            ),
            GenreInfo(
                name = "EDM", 
                description = "Electronic Dance Music - kategori musik elektronik untuk tarian dengan banyak sub-genre.",
                isLocalIndonesianGenre = false,
                tempo = "120-130 BPM",
                characteristics = "Kick four-on-the-floor, build-up dan drop, synth leads"
            ),
            GenreInfo(
                name = "House", 
                description = "Genre musik elektronik dengan beat four-on-the-floor yang konstan dan groove yang kental.",
                isLocalIndonesianGenre = false,
                tempo = "118-130 BPM",
                characteristics = "Kick four-on-the-floor, stab chords, vocal samples"
            ),
            GenreInfo(
                name = "Drum & Bass", 
                description = "Genre musik elektronik cepat dengan bassline berat dan pola breakbeat kompleks.",
                isLocalIndonesianGenre = false,
                tempo = "160-180 BPM",
                characteristics = "Breakbeats, bassline berat, atmosfer gelap/liquid"
            ),
            GenreInfo(
                name = "Hip-Hop", 
                description = "Genre musik dengan beat ritmis dan rhyming speech yang disebut rap.",
                isLocalIndonesianGenre = false,
                tempo = "85-105 BPM",
                characteristics = "Drum breaks, sampling, bass yang dalam"
            ),
            GenreInfo(
                name = "Dubstep", 
                description = "Genre musik elektronik dengan bass wobble yang kental dan sound design berat.",
                isLocalIndonesianGenre = false,
                tempo = "135-145 BPM",
                characteristics = "Wobble bass, half-step drum pattern, bass drops"
            )
        )
    }
    
    val indonesianGenres = remember { allGenres.filter { it.isLocalIndonesianGenre } }
    val internationalGenres = remember { allGenres.filter { !it.isLocalIndonesianGenre } }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Top bar
        TopAppBar(
            title = {
                Text("Pilih Genre")
            },
            backgroundColor = MaterialTheme.colors.primarySurface
        )
        
        // Filter by category
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            elevation = 4.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Cari Genre Berdasarkan Kategori",
                    style = MaterialTheme.typography.h6
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(onClick = { showGenreDetails = false }) {
                        Text("Semua")
                    }
                    
                    Button(
                        onClick = { showGenreDetails = true },
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = Color(0xFFFF5722)
                        )
                    ) {
                        Text("Lokal Indonesia")
                    }
                }
            }
        }
        
        // Information about genre selection
        if (!showGenreDetails) {
            // Genre list view
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 8.dp),
                elevation = 4.dp
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Genre Lokal Indonesia",
                        style = MaterialTheme.typography.h6,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    LazyColumn {
                        items(indonesianGenres) { genre ->
                            GenreCard(
                                genre = genre,
                                isSelected = selectedGenre == genre.name,
                                onClick = { 
                                    selectedGenre = genre.name 
                                },
                                onCreateClick = {
                                    selectedGenre = genre.name
                                    isCreatingProject = true
                                    
                                    coroutineScope.launch {
                                        // Buat proyek baru berdasarkan genre
                                        val project = genreGenerator.generateProject(
                                            genreName = genre.name,
                                            projectName = "New ${genre.name} Project"
                                        )
                                        
                                        isCreatingProject = false
                                        onGenreSelected(genre.name, project)
                                    }
                                }
                            )
                        }
                    }
                    
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    
                    Text(
                        text = "Genre Global",
                        style = MaterialTheme.typography.h6,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    LazyColumn {
                        items(internationalGenres) { genre ->
                            GenreCard(
                                genre = genre,
                                isSelected = selectedGenre == genre.name,
                                onClick = { 
                                    selectedGenre = genre.name 
                                },
                                onCreateClick = {
                                    selectedGenre = genre.name
                                    isCreatingProject = true
                                    
                                    coroutineScope.launch {
                                        // Buat proyek baru berdasarkan genre
                                        val project = genreGenerator.generateProject(
                                            genreName = genre.name,
                                            projectName = "New ${genre.name} Project"
                                        )
                                        
                                        isCreatingProject = false
                                        onGenreSelected(genre.name, project)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        } else {
            // Genre detail view for Indonesian local genres
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 8.dp),
                elevation = 4.dp
            ) {
                LazyColumn(
                    modifier = Modifier.padding(16.dp)
                ) {
                    items(indonesianGenres) { genre ->
                        GenreDetailCard(
                            genre = genre,
                            isSelected = selectedGenre == genre.name,
                            onClick = { selectedGenre = genre.name },
                            onCreateClick = {
                                selectedGenre = genre.name
                                isCreatingProject = true
                                
                                coroutineScope.launch {
                                    // Buat proyek baru berdasarkan genre
                                    val project = genreGenerator.generateProject(
                                        genreName = genre.name,
                                        projectName = "New ${genre.name} Project"
                                    )
                                    
                                    isCreatingProject = false
                                    onGenreSelected(genre.name, project)
                                }
                            }
                        )
                        
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
        
        // Loading indicator
        if (isCreatingProject) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .width(300.dp)
                        .padding(16.dp),
                    elevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Text(
                            text = "Membuat proyek ${selectedGenre}...",
                            style = MaterialTheme.typography.body1,
                            textAlign = TextAlign.Center
                        )
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Text(
                            text = "AI sedang menyiapkan elemen musik yang sesuai",
                            style = MaterialTheme.typography.caption,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

/**
 * Card untuk menampilkan genre dalam format ringkas
 */
@Composable
fun GenreCard(
    genre: GenreInfo,
    isSelected: Boolean,
    onClick: () -> Unit,
    onCreateClick: () -> Unit
) {
    val backgroundColor = if (isSelected) {
        MaterialTheme.colors.primary.copy(alpha = 0.2f)
    } else {
        MaterialTheme.colors.surface
    }
    
    val borderColor = if (isSelected) {
        MaterialTheme.colors.primary
    } else {
        Color.LightGray
    }
    
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .background(backgroundColor)
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = genre.name,
                style = MaterialTheme.typography.h6,
                fontWeight = FontWeight.Bold,
                color = if (genre.isLocalIndonesianGenre) Color(0xFFFF5722) else MaterialTheme.colors.onSurface
            )
            
            Button(
                onClick = onCreateClick,
                colors = ButtonDefaults.buttonColors(
                    backgroundColor = if (genre.isLocalIndonesianGenre) Color(0xFFFF5722) else MaterialTheme.colors.primary
                )
            ) {
                Text("Buat")
            }
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        Text(
            text = "Tempo: ${genre.tempo}",
            style = MaterialTheme.typography.caption
        )
        
        Text(
            text = genre.description,
            style = MaterialTheme.typography.body2,
            maxLines = 2,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
        )
    }
}

/**
 * Card untuk menampilkan detail lengkap genre Indonesia
 */
@Composable
fun GenreDetailCard(
    genre: GenreInfo,
    isSelected: Boolean,
    onClick: () -> Unit,
    onCreateClick: () -> Unit
) {
    val backgroundColor = if (isSelected) {
        MaterialTheme.colors.primary.copy(alpha = 0.2f)
    } else {
        MaterialTheme.colors.surface
    }
    
    val borderColor = if (isSelected) {
        MaterialTheme.colors.primary
    } else {
        Color.LightGray
    }
    
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .background(backgroundColor)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Text(
            text = genre.name,
            style = MaterialTheme.typography.h5,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFFF5722)
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Speed,
                contentDescription = "Tempo",
                tint = Color.Gray
            )
            
            Spacer(modifier = Modifier.width(4.dp))
            
            Text(
                text = "Tempo: ${genre.tempo}",
                style = MaterialTheme.typography.body2,
                fontWeight = FontWeight.Medium
            )
        }
        
        Spacer(modifier = Modifier.height(12.dp))
        
        Text(
            text = "Deskripsi",
            style = MaterialTheme.typography.subtitle1,
            fontWeight = FontWeight.Bold
        )
        
        Text(
            text = genre.description,
            style = MaterialTheme.typography.body1
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        Text(
            text = "Karakteristik Utama",
            style = MaterialTheme.typography.subtitle1,
            fontWeight = FontWeight.Bold
        )
        
        Text(
            text = genre.characteristics,
            style = MaterialTheme.typography.body1
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Sample recommendations
        Text(
            text = "Sample yang Direkomendasikan",
            style = MaterialTheme.typography.subtitle1,
            fontWeight = FontWeight.Bold
        )
        
        genreSampleRecommendations(genre.name).forEach { sample ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = Color(0xFFFF5722)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = sample,
                    style = MaterialTheme.typography.body2
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(
            onClick = onCreateClick,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                backgroundColor = Color(0xFFFF5722)
            )
        ) {
            Text(
                text = "Buat Proyek ${genre.name}",
                color = Color.White
            )
        }
    }
}

/**
 * Informasi tentang genre musik
 */
data class GenreInfo(
    val name: String,
    val description: String,
    val isLocalIndonesianGenre: Boolean,
    val tempo: String,
    val characteristics: String
)

/**
 * Mendapatkan rekomendasi sampel untuk genre tertentu
 */
fun genreSampleRecommendations(genre: String): List<String> {
    return when (genre) {
        "DJ Bantengan" -> listOf(
            "Gong Ageng",
            "Kenong Jawa",
            "Kempul Mistis",
            "Perkusi Jaranan",
            "Ritme Barongan",
            "Vocal Chant Bantengan"
        )
        
        "DJ Nrotok" -> listOf(
            "Pola Drum Nrotok",
            "Ketukan Kentongan",
            "Vokal Timur",
            "Bedug Bass",
            "Nrotok Lead Synth",
            "Loop Vokal Nrotok"
        )
        
        "Koplo" -> listOf(
            "Pola Kendang Koplo",
            "Ketukan Kenong",
            "Loop Ketipung Koplo",
            "Fill Jaipong",
            "Bass Dangdut",
            "Sample Vokal Koplo"
        )
        
        "Dangdut" -> listOf(
            "Loop Tabla",
            "Pola Ketipung",
            "Melodi Suling",
            "Ornamen Vokal Dangdut",
            "Riff Mandolin",
            "Bass Line Dangdut"
        )
        
        else -> listOf(
            "Kick Dasar",
            "Snare Standar",
            "Hi-hat Tertutup",
            "Clap Reverb",
            "Bass Dalam",
            "Pad Synth"
        )
    }
}