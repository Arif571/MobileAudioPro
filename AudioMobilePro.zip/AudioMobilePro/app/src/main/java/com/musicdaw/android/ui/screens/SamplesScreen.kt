package com.musicdaw.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.musicdaw.android.model.Sample
import com.musicdaw.android.model.SampleCategory
import kotlinx.coroutines.launch
import java.util.*

@Composable
fun SamplesScreen() {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<SampleCategory?>(null) }
    var showCategoryFilter by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }
    var selectedSample by remember { mutableStateOf<Sample?>(null) }
    
    // Mock samples for demonstration
    val mockSamples = remember {
        listOf(
            Sample(
                name = "808 Kick",
                filePath = "/samples/kicks/808_kick.wav",
                category = SampleCategory.DRUM,
                tags = listOf("kick", "808", "hip-hop"),
                durationMs = 750,
                waveformData = List(100) { (Math.sin(it * 0.2) * 0.5 + 0.5).toFloat() },
                dateAdded = Date(),
                isFavorite = true
            ),
            Sample(
                name = "Clap Reverb",
                filePath = "/samples/claps/clap_reverb.wav",
                category = SampleCategory.DRUM,
                tags = listOf("clap", "reverb", "electronic"),
                durationMs = 1200,
                waveformData = List(100) { (Math.random() * 0.8 + 0.2).toFloat() },
                dateAdded = Date()
            ),
            Sample(
                name = "Piano C Major",
                filePath = "/samples/piano/piano_c_major.wav",
                category = SampleCategory.INSTRUMENT,
                tags = listOf("piano", "chord", "c major"),
                durationMs = 3000,
                waveformData = List(100) { (Math.sin(it * 0.1) * 0.6 + 0.4).toFloat() },
                dateAdded = Date()
            ),
            Sample(
                name = "Synth Lead",
                filePath = "/samples/synths/synth_lead.wav",
                category = SampleCategory.INSTRUMENT,
                tags = listOf("synth", "lead", "electronic"),
                durationMs = 2500,
                waveformData = List(100) { (Math.cos(it * 0.15) * 0.7 + 0.3).toFloat() },
                dateAdded = Date(),
                isFavorite = true
            ),
            Sample(
                name = "Vocal Chop",
                filePath = "/samples/vocals/vocal_chop.wav",
                category = SampleCategory.VOCAL,
                tags = listOf("vocal", "chop", "effect"),
                durationMs = 1800,
                waveformData = List(100) { (Math.random() * 0.7 + 0.3).toFloat() },
                dateAdded = Date()
            ),
            Sample(
                name = "Lo-Fi Drum Loop",
                filePath = "/samples/loops/lofi_drum_loop.wav",
                category = SampleCategory.LOOP,
                tags = listOf("loop", "drum", "lo-fi"),
                durationMs = 4000,
                waveformData = List(100) { (Math.sin(it * 0.12) * 0.5 + 0.5).toFloat() },
                dateAdded = Date()
            ),
            Sample(
                name = "Bass Wobble",
                filePath = "/samples/bass/bass_wobble.wav",
                category = SampleCategory.INSTRUMENT,
                tags = listOf("bass", "wobble", "dubstep"),
                durationMs = 3500,
                waveformData = List(100) { (Math.sin(it * 0.05) * 0.8 + 0.2).toFloat() },
                dateAdded = Date()
            ),
            Sample(
                name = "Guitar Riff",
                filePath = "/samples/guitar/guitar_riff.wav",
                category = SampleCategory.INSTRUMENT,
                tags = listOf("guitar", "riff", "rock"),
                durationMs = 5000,
                waveformData = List(100) { (Math.random() * 0.6 + 0.4).toFloat() },
                dateAdded = Date()
            )
        )
    }
    
    // Filter samples based on search query and selected category
    val filteredSamples = mockSamples.filter { sample ->
        (searchQuery.isEmpty() || sample.name.contains(searchQuery, ignoreCase = true) || 
                sample.tags.any { it.contains(searchQuery, ignoreCase = true) }) &&
        (selectedCategory == null || sample.category == selectedCategory)
    }
    
    val coroutineScope = rememberCoroutineScope()
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Top app bar
        TopAppBar(
            title = {
                Text(
                    text = "Sample Library",
                    fontWeight = FontWeight.Bold
                )
            },
            backgroundColor = MaterialTheme.colors.primarySurface,
            actions = {
                // Import button
                IconButton(onClick = { showImportDialog = true }) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Import Sample"
                    )
                }
                
                // Filter button
                IconButton(onClick = { showCategoryFilter = true }) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = "Filter"
                    )
                }
            }
        )
        
        // Search bar
        TextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            placeholder = { Text("Search samples...") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search"
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear"
                        )
                    }
                }
            },
            singleLine = true,
            colors = TextFieldDefaults.textFieldColors(
                backgroundColor = MaterialTheme.colors.surface
            )
        )
        
        // Selected category chip (if any)
        if (selectedCategory != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Category:",
                    fontSize = 14.sp,
                    modifier = Modifier.padding(end = 8.dp)
                )
                
                Chip(
                    modifier = Modifier.padding(end = 8.dp),
                    onClick = { selectedCategory = null }
                ) {
                    Text(selectedCategory!!.displayName)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear",
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
        }
        
        // Sample grid
        if (filteredSamples.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No samples found",
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 160.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(filteredSamples) { sample ->
                    SampleItem(
                        sample = sample,
                        onClick = { selectedSample = sample },
                        onFavoriteToggle = { /* Toggle favorite */ }
                    )
                }
            }
        }
    }
    
    // Category filter dialog
    if (showCategoryFilter) {
        AlertDialog(
            onDismissRequest = { showCategoryFilter = false },
            title = { Text("Filter by Category") },
            text = {
                Column {
                    SampleCategory.values().forEach { category ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedCategory = category
                                    showCategoryFilter = false
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedCategory == category,
                                onClick = {
                                    selectedCategory = category
                                    showCategoryFilter = false
                                }
                            )
                            
                            Spacer(modifier = Modifier.width(8.dp))
                            
                            Text(category.displayName)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCategoryFilter = false }) {
                    Text("Cancel")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        selectedCategory = null
                        showCategoryFilter = false
                    }
                ) {
                    Text("Clear Filter")
                }
            }
        )
    }
    
    // Import dialog
    if (showImportDialog) {
        ImportSampleDialog(
            onDismiss = { showImportDialog = false },
            onImport = { name, category, tags ->
                // Import sample logic would go here
                showImportDialog = false
            }
        )
    }
    
    // Sample details dialog
    selectedSample?.let { sample ->
        SampleDetailsDialog(
            sample = sample,
            onDismiss = { selectedSample = null },
            onAddToProject = {
                // Add to project logic would go here
                selectedSample = null
            }
        )
    }
}

@Composable
fun SampleItem(
    sample: Sample,
    onClick: () -> Unit,
    onFavoriteToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clickable(onClick = onClick),
        elevation = 4.dp
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Waveform visualization
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .background(MaterialTheme.colors.primary.copy(alpha = 0.1f))
            ) {
                // Simplified waveform rendering
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 4.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    sample.waveformData.forEach { amplitude ->
                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .fillMaxHeight(amplitude)
                                .background(MaterialTheme.colors.primary)
                        )
                    }
                }
                
                // Category label
                Text(
                    text = sample.category.displayName,
                    color = Color.White,
                    fontSize = 10.sp,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .background(
                            MaterialTheme.colors.primary,
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            
            // Sample information
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = sample.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    
                    IconButton(
                        onClick = onFavoriteToggle,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (sample.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (sample.isFavorite) Color.Red else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(2.dp))
                
                // Duration text
                Text(
                    text = formatDuration(sample.durationMs),
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                // Tags
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    sample.tags.take(3).forEach { tag ->
                        Text(
                            text = tag,
                            fontSize = 10.sp,
                            color = MaterialTheme.colors.primary,
                            modifier = Modifier
                                .background(
                                    MaterialTheme.colors.primary.copy(alpha = 0.1f),
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                    
                    if (sample.tags.size > 3) {
                        Text(
                            text = "+${sample.tags.size - 3}",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ImportSampleDialog(
    onDismiss: () -> Unit,
    onImport: (name: String, category: SampleCategory, tags: List<String>) -> Unit
) {
    var sampleName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(SampleCategory.DRUM) }
    var tagsText by remember { mutableStateOf("") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import Sample") },
        text = {
            Column {
                // Name input
                TextField(
                    value = sampleName,
                    onValueChange = { sampleName = it },
                    label = { Text("Sample Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Category dropdown
                Text("Category:", fontWeight = FontWeight.Bold)
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Column {
                    SampleCategory.values().forEach { category ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedCategory = category }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedCategory == category,
                                onClick = { selectedCategory = category }
                            )
                            
                            Spacer(modifier = Modifier.width(8.dp))
                            
                            Text(category.displayName)
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Tags input
                TextField(
                    value = tagsText,
                    onValueChange = { tagsText = it },
                    label = { Text("Tags (comma separated)") },
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // File selection would be a button here in a real implementation
                Button(
                    onClick = { /* Open file picker */ },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Select Audio File")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (sampleName.isNotBlank()) {
                        onImport(
                            sampleName,
                            selectedCategory,
                            tagsText.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                        )
                    }
                },
                enabled = sampleName.isNotBlank()
            ) {
                Text("Import")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun SampleDetailsDialog(
    sample: Sample,
    onDismiss: () -> Unit,
    onAddToProject: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(false) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(sample.name) },
        text = {
            Column {
                // Waveform visualization
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colors.primary.copy(alpha = 0.1f))
                ) {
                    // Simplified waveform rendering
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 8.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        sample.waveformData.forEach { amplitude ->
                            Box(
                                modifier = Modifier
                                    .width(2.dp)
                                    .fillMaxHeight(amplitude)
                                    .background(MaterialTheme.colors.primary)
                            )
                        }
                    }
                    
                    // Play button overlay
                    IconButton(
                        onClick = { isPlaying = !isPlaying },
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(56.dp)
                            .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(28.dp))
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Sample info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Category:", fontWeight = FontWeight.Bold)
                        Text(sample.category.displayName)
                    }
                    
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Duration:", fontWeight = FontWeight.Bold)
                        Text(formatDuration(sample.durationMs))
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Tags
                Text("Tags:", fontWeight = FontWeight.Bold)
                
                Spacer(modifier = Modifier.height(4.dp))
                
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    sample.tags.forEach { tag ->
                        Text(
                            text = tag,
                            fontSize = 12.sp,
                            color = MaterialTheme.colors.primary,
                            modifier = Modifier
                                .background(
                                    MaterialTheme.colors.primary.copy(alpha = 0.1f),
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // File info
                Text("File Path:", fontWeight = FontWeight.Bold)
                Text(
                    text = sample.filePath,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text("Date Added:", fontWeight = FontWeight.Bold)
                Text(
                    text = android.text.format.DateFormat.format("MMM dd, yyyy", sample.dateAdded).toString(),
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            Button(onClick = onAddToProject) {
                Text("Add to Project")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

// Helper for flow layout of tags
@Composable
fun FlowRow(
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    content: @Composable () -> Unit
) {
    Layout(
        content = content,
        measurePolicy = flowRowMeasurePolicy(horizontalArrangement, verticalArrangement)
    )
}

private fun flowRowMeasurePolicy(
    horizontalArrangement: Arrangement.Horizontal,
    verticalArrangement: Arrangement.Vertical
) = { measurables, constraints ->
    val rows = mutableListOf<List<androidx.compose.ui.layout.Placeable>>()
    val rowWidths = mutableListOf<Int>()
    
    var currentRow = mutableListOf<androidx.compose.ui.layout.Placeable>()
    var currentRowWidth = 0
    
    measurables.forEach { measurable ->
        val placeable = measurable.measure(constraints.copy(minWidth = 0))
        
        if (currentRowWidth + placeable.width > constraints.maxWidth) {
            rows.add(currentRow)
            rowWidths.add(currentRowWidth)
            currentRow = mutableListOf()
            currentRowWidth = 0
        }
        
        currentRow.add(placeable)
        currentRowWidth += placeable.width
    }
    
    if (currentRow.isNotEmpty()) {
        rows.add(currentRow)
        rowWidths.add(currentRowWidth)
    }
    
    val width = rowWidths.maxOrNull() ?: 0
    val height = rows.sumOf { row -> row.maxOfOrNull { it.height } ?: 0 }
    
    layout(width, height) {
        var y = 0
        rows.forEachIndexed { i, row ->
            val rowWidth = rowWidths[i]
            val spacing = if (row.size > 1) {
                when (horizontalArrangement) {
                    Arrangement.SpaceBetween -> (width - rowWidth) / (row.size - 1)
                    Arrangement.SpaceEvenly -> (width - rowWidth) / (row.size + 1)
                    Arrangement.SpaceAround -> (width - rowWidth) / (row.size * 2)
                    else -> 0
                }
            } else 0
            
            var x = when (horizontalArrangement) {
                Arrangement.Center -> (width - rowWidth) / 2
                Arrangement.End -> width - rowWidth
                Arrangement.SpaceEvenly -> spacing
                else -> 0
            }
            
            row.forEach { placeable ->
                placeable.placeRelative(x, y)
                x += placeable.width + spacing
            }
            
            y += row.maxOfOrNull { it.height } ?: 0
        }
    }
}

// Helper to format milliseconds to mm:ss
fun formatDuration(durationMs: Int): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%d:%02d", minutes, seconds)
}

// A simple Chip component
@Composable
fun Chip(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    content: @Composable RowScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colors.primary.copy(alpha = 0.1f),
        contentColor = MaterialTheme.colors.primary
    ) {
        Row(
            modifier = Modifier
                .clickable(onClick = onClick)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}