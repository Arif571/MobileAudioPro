package com.musicdaw.android.ai

import com.musicdaw.android.model.*
import com.musicdaw.android.ai.AudioSampleExtractorAI.AudioSample
import com.musicdaw.android.ai.MixingMasteringAI.MasteringCharacter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.*

/**
 * Controller untuk alur kerja AI dari ekstraksi sampel hingga produksi akhir
 * Menghubungkan semua komponen AI dalam satu alur kerja terintegrasi
 */
class AIProductionController {

    private val sampleExtractor = AudioSampleExtractorAI()
    private val patternComposer = PatternComposerAI()
    private val mixingMasteringAI = MixingMasteringAI()
    private val genreAI = MusicGenreAI()
    
    /**
     * Status proses produksi AI
     */
    enum class ProductionStatus {
        ANALYZING,
        EXTRACTING_SAMPLES,
        GENERATING_PATTERNS,
        MIXING,
        MASTERING,
        COMPLETED,
        ERROR
    }

    /**
     * Data hasil proses produksi
     */
    data class ProductionResult(
        val status: ProductionStatus,
        val project: Project? = null,
        val extractedSamples: List<AudioSample> = emptyList(),
        val detectedGenre: String = "",
        val statusMessage: String = "",
        val progressPercent: Int = 0,
        val errorMessage: String? = null
    )
    
    /**
     * Memproses file audio referensi dan menghasilkan proyek musik yang sudah selesai
     * @param referenceAudioPath Path ke file audio referensi
     * @param targetGenre Genre yang ingin dihasilkan, null untuk deteksi otomatis
     * @param projectName Nama proyek yang akan dihasilkan
     * @param productionOptions Opsi produksi tambahan
     * @param progressCallback Callback untuk melaporkan progres
     * @return Proyek yang telah diproduksi lengkap dengan campuran dan mastering
     */
    suspend fun processReferenceAudio(
        referenceAudioPath: String,
        targetGenre: String? = null,
        projectName: String,
        productionOptions: ProductionOptions = ProductionOptions(),
        progressCallback: (ProductionResult) -> Unit
    ): Project = withContext(Dispatchers.IO) {
        try {
            // Langkah 1: Analisis awal file audio referensi
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.ANALYZING,
                    statusMessage = "Menganalisis audio referensi...",
                    progressPercent = 5
                )
            )
            
            // Deteksi genre jika tidak ditentukan
            val detectedGenre = targetGenre ?: detectGenreFromReference(referenceAudioPath)
            
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.ANALYZING,
                    statusMessage = "Terdeteksi genre: $detectedGenre",
                    detectedGenre = detectedGenre,
                    progressPercent = 10
                )
            )
            
            // Langkah 2: Ekstrak sampel dari audio referensi
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.EXTRACTING_SAMPLES,
                    statusMessage = "Mengekstrak sampel audio...",
                    detectedGenre = detectedGenre,
                    progressPercent = 15
                )
            )
            
            val extractedSamples = sampleExtractor.extractSamplesFromReference(
                referenceAudioPath,
                detectedGenre
            )
            
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.EXTRACTING_SAMPLES,
                    statusMessage = "Diekstrak ${extractedSamples.size} sampel berkualitas tinggi",
                    extractedSamples = extractedSamples,
                    detectedGenre = detectedGenre,
                    progressPercent = 30
                )
            )
            
            // Langkah 3: Hasilkan pola musik berdasarkan sampel dan genre
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.GENERATING_PATTERNS,
                    statusMessage = "Menyusun pola musik $detectedGenre...",
                    extractedSamples = extractedSamples,
                    detectedGenre = detectedGenre,
                    progressPercent = 35
                )
            )
            
            var project = patternComposer.composeFullProject(
                samples = extractedSamples,
                genre = detectedGenre,
                projectName = projectName
            )
            
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.GENERATING_PATTERNS,
                    project = project,
                    extractedSamples = extractedSamples,
                    detectedGenre = detectedGenre,
                    statusMessage = "Berhasil membuat pola untuk semua instrumen",
                    progressPercent = 50
                )
            )
            
            // Langkah 4: Proses mixing
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.MIXING,
                    project = project,
                    extractedSamples = extractedSamples,
                    detectedGenre = detectedGenre,
                    statusMessage = "Melakukan mixing profesional...",
                    progressPercent = 55
                )
            )
            
            project = mixingMasteringAI.mixProject(project, detectedGenre)
            
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.MIXING,
                    project = project,
                    extractedSamples = extractedSamples,
                    detectedGenre = detectedGenre,
                    statusMessage = "Mixing selesai dengan balance dan kejelasan optimal",
                    progressPercent = 75
                )
            )
            
            // Langkah 5: Proses mastering
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.MASTERING,
                    project = project,
                    extractedSamples = extractedSamples,
                    detectedGenre = detectedGenre,
                    statusMessage = "Melakukan mastering kualitas studio...",
                    progressPercent = 80
                )
            )
            
            val masteringCharacter = getPreferredMasteringCharacter(
                detectedGenre,
                productionOptions.masteringStyle
            )
            
            project = mixingMasteringAI.masterProject(
                project = project,
                targetGenre = detectedGenre,
                masteringCharacter = masteringCharacter
            )
            
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.COMPLETED,
                    project = project,
                    extractedSamples = extractedSamples,
                    detectedGenre = detectedGenre,
                    statusMessage = "Proses produksi selesai! Musik $detectedGenre siap digunakan",
                    progressPercent = 100
                )
            )
            
            return@withContext project
            
        } catch (e: Exception) {
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.ERROR,
                    statusMessage = "Terjadi kesalahan: ${e.message}",
                    errorMessage = e.message,
                    progressPercent = 0
                )
            )
            
            // Kembalikan project kosong jika terjadi kesalahan
            return@withContext Project(
                name = projectName,
                tempo = 120f,
                timeSignatureNumerator = 4,
                timeSignatureDenominator = 4
            )
        }
    }
    
    /**
     * Mengoptimalkan track dalam proyek musik yang ada
     * @param project Proyek yang akan dioptimalkan
     * @param trackIndex Indeks track yang akan dioptimalkan, null untuk semua track
     * @param targetGenre Genre yang diinginkan, null untuk mempertahankan genre asli
     * @param masteringOptions Opsi mastering tambahan 
     * @param progressCallback Callback untuk melaporkan progres
     * @return Proyek yang telah dioptimalkan
     */
    suspend fun optimizeProject(
        project: Project,
        trackIndex: Int? = null,
        targetGenre: String? = null,
        masteringOptions: MasteringOptions = MasteringOptions(),
        progressCallback: (ProductionResult) -> Unit
    ): Project = withContext(Dispatchers.IO) {
        try {
            // Deteksi genre dari proyek jika tidak ditentukan
            val detectedGenre = targetGenre ?: genreAI.analyzeProjectGenre(project).entries
                .maxByOrNull { it.value }?.key ?: "Unknown"
            
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.ANALYZING,
                    project = project,
                    detectedGenre = detectedGenre,
                    statusMessage = "Menganalisis proyek dengan genre $detectedGenre...",
                    progressPercent = 10
                )
            )
            
            // Proses optimasi track tertentu atau seluruh proyek
            val optimizedProject = if (trackIndex != null) {
                // Optimasi single track
                val track = project.tracks[trackIndex]
                
                progressCallback(
                    ProductionResult(
                        status = ProductionStatus.MIXING,
                        project = project,
                        detectedGenre = detectedGenre,
                        statusMessage = "Mengoptimalkan track: ${track.name}...",
                        progressPercent = 30
                    )
                )
                
                // Buat efek yang optimal untuk track ini
                val optimizedTrack = optimizeTrack(track, detectedGenre)
                
                // Perbarui track dalam proyek
                val updatedTracks = project.tracks.toMutableList()
                updatedTracks[trackIndex] = optimizedTrack
                
                project.copy(tracks = updatedTracks)
            } else {
                // Optimasi seluruh proyek
                progressCallback(
                    ProductionResult(
                        status = ProductionStatus.MIXING,
                        project = project,
                        detectedGenre = detectedGenre,
                        statusMessage = "Mengoptimalkan mixing seluruh proyek...",
                        progressPercent = 30
                    )
                )
                
                // Lakukan proses mixing
                mixingMasteringAI.mixProject(project, detectedGenre)
            }
            
            // Proses mastering jika dibutuhkan
            val finalProject = if (masteringOptions.applyMastering) {
                progressCallback(
                    ProductionResult(
                        status = ProductionStatus.MASTERING,
                        project = optimizedProject,
                        detectedGenre = detectedGenre,
                        statusMessage = "Menerapkan mastering dengan karakter: ${masteringOptions.masteringCharacter}...",
                        progressPercent = 70
                    )
                )
                
                mixingMasteringAI.masterProject(
                    project = optimizedProject,
                    targetGenre = detectedGenre,
                    masteringCharacter = masteringOptions.masteringCharacter
                )
            } else {
                optimizedProject
            }
            
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.COMPLETED,
                    project = finalProject,
                    detectedGenre = detectedGenre,
                    statusMessage = "Optimasi proyek selesai!",
                    progressPercent = 100
                )
            )
            
            return@withContext finalProject
            
        } catch (e: Exception) {
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.ERROR,
                    project = project,
                    statusMessage = "Terjadi kesalahan saat optimasi: ${e.message}",
                    errorMessage = e.message,
                    progressPercent = 0
                )
            )
            
            return@withContext project
        }
    }
    
    /**
     * Mengkonversi proyek ke genre yang berbeda
     * @param project Proyek yang akan dikonversi
     * @param targetGenre Genre target
     * @param preserveOriginalElements True untuk mempertahankan elemen musik asli sebanyak mungkin
     * @param progressCallback Callback untuk melaporkan progres
     * @return Proyek yang telah dikonversi ke genre target
     */
    suspend fun convertProjectToGenre(
        project: Project,
        targetGenre: String,
        preserveOriginalElements: Boolean = true,
        progressCallback: (ProductionResult) -> Unit
    ): Project = withContext(Dispatchers.IO) {
        try {
            // Langkah 1: Analisis proyek awal
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.ANALYZING,
                    project = project,
                    statusMessage = "Menganalisis proyek awal...",
                    progressPercent = 10
                )
            )
            
            // Deteksi genre asli
            val sourceGenre = genreAI.analyzeProjectGenre(project).entries
                .maxByOrNull { it.value }?.key ?: "Unknown"
            
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.ANALYZING,
                    project = project,
                    detectedGenre = sourceGenre,
                    statusMessage = "Konversi dari $sourceGenre ke $targetGenre...",
                    progressPercent = 20
                )
            )
            
            // Langkah 2: Transformasi proyek ke genre target
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.GENERATING_PATTERNS,
                    project = project,
                    statusMessage = "Mentransformasi pola musik ke $targetGenre...",
                    progressPercent = 30
                )
            )
            
            val transformedProject = genreAI.transformProjectToGenre(project, targetGenre)
            
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.GENERATING_PATTERNS,
                    project = transformedProject,
                    statusMessage = "Berhasil mentransformasi proyek",
                    progressPercent = 50
                )
            )
            
            // Langkah 3: Mixing proyek transformasi
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.MIXING,
                    project = transformedProject,
                    statusMessage = "Melakukan mixing untuk genre $targetGenre...",
                    progressPercent = 60
                )
            )
            
            val mixedProject = mixingMasteringAI.mixProject(transformedProject, targetGenre)
            
            // Langkah 4: Mastering proyek transformasi
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.MASTERING,
                    project = mixedProject,
                    statusMessage = "Menerapkan mastering sesuai dengan genre $targetGenre...",
                    progressPercent = 80
                )
            )
            
            val finalProject = mixingMasteringAI.masterProject(
                project = mixedProject,
                targetGenre = targetGenre,
                masteringCharacter = getPreferredMasteringCharacter(targetGenre)
            )
            
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.COMPLETED,
                    project = finalProject,
                    statusMessage = "Konversi genre selesai! Proyek sekarang dalam genre $targetGenre",
                    progressPercent = 100
                )
            )
            
            return@withContext finalProject
            
        } catch (e: Exception) {
            progressCallback(
                ProductionResult(
                    status = ProductionStatus.ERROR,
                    project = project,
                    statusMessage = "Terjadi kesalahan saat konversi: ${e.message}",
                    errorMessage = e.message,
                    progressPercent = 0
                )
            )
            
            return@withContext project
        }
    }
    
    /**
     * Mendapatkan sampel dari audio rekaman dengan memisahkan dan mengekstrak suara
     * @param audioPath Path ke file audio yang akan diproses
     * @param sampleCategories Kategori sampel yang ingin diekstrak
     * @param maxSamples Jumlah maksimal sampel yang akan dihasilkan
     * @param progressCallback Callback untuk melaporkan progres
     * @return Daftar sampel yang diekstrak
     */
    suspend fun extractSamples(
        audioPath: String,
        sampleCategories: List<AudioSampleExtractorAI.SampleCategory> = AudioSampleExtractorAI.SampleCategory.values().toList(),
        maxSamples: Int = 20,
        progressCallback: (Float, String) -> Unit
    ): List<AudioSample> = withContext(Dispatchers.IO) {
        try {
            progressCallback(0.1f, "Menganalisis audio input...")
            
            // Deteksi genre untuk ekstraksi yang tepat
            val detectedGenre = detectGenreFromReference(audioPath)
            progressCallback(0.2f, "Terdeteksi genre: $detectedGenre")
            
            progressCallback(0.3f, "Memisahkan komponen audio...")
            
            // Ekstrak sampel dengan AudioSampleExtractorAI
            val allSamples = sampleExtractor.extractSamplesFromReference(audioPath, detectedGenre)
            progressCallback(0.7f, "Berhasil mengekstrak ${allSamples.size} sampel")
            
            // Filter sampel berdasarkan kategori dan batasi jumlah
            val filteredSamples = allSamples
                .filter { sample -> sampleCategories.any { it.name.lowercase() == sample.category.lowercase() } }
                .take(maxSamples)
            
            progressCallback(1.0f, "Ekstraksi selesai. Dihasilkan ${filteredSamples.size} sampel berkualitas tinggi")
            
            return@withContext filteredSamples
            
        } catch (e: Exception) {
            progressCallback(0f, "Terjadi kesalahan: ${e.message}")
            return@withContext emptyList()
        }
    }
    
    /**
     * Mengoptimalkan track dengan efek yang sesuai genre
     */
    private fun optimizeTrack(track: Track, genre: String): Track {
        // Tentukan peran track
        val role = determineTrackRole(track)
        
        // Buat EQ optimal
        val eqEffect = createOptimalEQ(track, role, genre)
        
        // Buat kompressor optimal
        val compressorEffect = createOptimalCompressor(track, role, genre)
        
        // Buat efek tambahan yang sesuai genre dan peran
        val additionalEffects = createOptimalAdditionalEffects(track, role, genre)
        
        // Filter efek yang sudah ada untuk mempertahankan automation dan pengaturan lain
        val existingEffects = track.effects.filter { 
            it.type != "eq" && it.type != "compressor" && 
            !additionalEffects.any { newEffect -> newEffect.type == it.type }
        }
        
        // Gabungkan semua efek
        val finalEffects = listOf(eqEffect, compressorEffect) + additionalEffects + existingEffects
        
        // Kembalikan track dengan efek baru
        return track.copy(effects = finalEffects)
    }
    
    /**
     * Tentukan peran track berdasarkan nama dan konten
     */
    private fun determineTrackRole(track: Track): MixingMasteringAI.TrackRole {
        return when {
            track.isDrumTrack -> MixingMasteringAI.TrackRole.DRUMS
            track.name.contains("kick", ignoreCase = true) -> MixingMasteringAI.TrackRole.KICK
            track.name.contains("snare", ignoreCase = true) -> MixingMasteringAI.TrackRole.SNARE
            track.name.contains("hat", ignoreCase = true) -> MixingMasteringAI.TrackRole.HIHAT
            track.name.contains("bass", ignoreCase = true) -> MixingMasteringAI.TrackRole.BASS
            track.name.contains("vocal", ignoreCase = true) -> MixingMasteringAI.TrackRole.VOCAL
            track.name.contains("lead", ignoreCase = true) -> MixingMasteringAI.TrackRole.LEAD
            track.name.contains("melody", ignoreCase = true) -> MixingMasteringAI.TrackRole.MELODY
            track.name.contains("pad", ignoreCase = true) -> MixingMasteringAI.TrackRole.PAD
            track.name.contains("fx", ignoreCase = true) -> MixingMasteringAI.TrackRole.FX
            track.name.contains("gamelan", ignoreCase = true) -> MixingMasteringAI.TrackRole.ETHNIC
            track.name.contains("gong", ignoreCase = true) -> MixingMasteringAI.TrackRole.ETHNIC
            track.name.contains("kendang", ignoreCase = true) -> MixingMasteringAI.TrackRole.ETHNIC_PERCUSSION
            else -> MixingMasteringAI.TrackRole.OTHER
        }
    }
    
    /**
     * Buat EQ optimal berdasarkan jenis track dan genre
     */
    private fun createOptimalEQ(
        track: Track, 
        role: MixingMasteringAI.TrackRole, 
        genre: String
    ): Effect {
        // Pengaturan EQ default berdasarkan peran track
        val settings = when (role) {
            MixingMasteringAI.TrackRole.KICK -> mapOf(
                "high_pass" to 0.1f, // ~30Hz
                "low_boost" to 0.55f, // Boost di 80-100Hz
                "low_boost_freq" to 0.09f, // ~80-100Hz
                "low_boost_q" to 0.5f, // Medium Q
                "low_mid_cut" to 0.45f, // Cut di 300-400Hz
                "low_mid_cut_freq" to 0.18f, // ~300-400Hz
                "low_mid_cut_q" to 0.6f, // Medium Q
                "high_cut" to 0.65f // ~5kHz
            )
            
            MixingMasteringAI.TrackRole.BASS -> mapOf(
                "high_pass" to 0.08f, // ~25Hz
                "low_boost" to 0.56f, // Boost di 80-100Hz
                "low_boost_freq" to 0.08f, // ~80Hz
                "low_boost_q" to 0.5f, // Medium Q
                "low_mid_cut" to 0.45f, // Cut di 300Hz
                "low_mid_cut_freq" to 0.18f, // ~300Hz
                "low_mid_cut_q" to 0.6f, // Medium Q
                "high_cut" to 0.5f // ~2kHz
            )
            
            MixingMasteringAI.TrackRole.DRUMS -> mapOf(
                "high_pass" to 0.12f, // ~80Hz
                "low_boost" to 0.53f, // Boost di 100Hz
                "low_boost_freq" to 0.1f, // ~100Hz
                "low_boost_q" to 0.5f, // Medium Q
                "low_mid_cut" to 0.46f, // Cut di 300-400Hz
                "low_mid_cut_freq" to 0.18f, // ~300-400Hz
                "low_mid_cut_q" to 0.6f, // Medium Q
                "high_mid_boost" to 0.54f, // Boost di 3-5kHz
                "high_mid_boost_freq" to 0.6f, // ~3-5kHz
                "high_mid_boost_q" to 0.6f // Medium Q
            )
            
            MixingMasteringAI.TrackRole.VOCAL -> mapOf(
                "high_pass" to 0.15f, // ~120Hz
                "low_mid_cut" to 0.47f, // Cut di 300Hz
                "low_mid_cut_freq" to 0.18f, // ~300Hz
                "low_mid_cut_q" to 0.6f, // Medium Q
                "mid_boost" to 0.53f, // Boost di 1kHz
                "mid_boost_freq" to 0.35f, // ~1kHz
                "mid_boost_q" to 0.6f, // Medium Q
                "high_mid_boost" to 0.54f, // Boost di 3-5kHz
                "high_mid_boost_freq" to 0.6f, // ~3-5kHz
                "high_mid_boost_q" to 0.7f, // Medium Q
                "high_boost" to 0.53f, // Boost di 10kHz
                "high_boost_freq" to 0.85f, // ~10kHz
                "high_boost_q" to 0.6f // Medium Q
            )
            
            else -> mapOf(
                "high_pass" to 0.15f, // ~120Hz
                "low_mid_cut" to 0.48f, // Cut di 300-400Hz
                "low_mid_cut_freq" to 0.18f, // ~300-400Hz
                "low_mid_cut_q" to 0.6f // Medium Q
            )
        }
        
        // Modifikasi pengaturan berdasarkan genre
        val finalSettings = when {
            genre.contains("bantengan", ignoreCase = true) && 
            (role == MixingMasteringAI.TrackRole.ETHNIC || role == MixingMasteringAI.TrackRole.ETHNIC_PERCUSSION) -> {
                // Pengaturan khusus untuk instrumen gamelan di DJ Bantengan
                settings + mapOf(
                    "low_mid_boost" to 0.54f, // Boost karakteristik gamelan
                    "low_mid_boost_freq" to 0.25f, // ~500Hz
                    "low_mid_boost_q" to 0.6f // Medium Q
                )
            }
            
            genre.contains("nrotok", ignoreCase = true) && role == MixingMasteringAI.TrackRole.DRUMS -> {
                // Pengaturan khusus untuk drum di DJ Nrotok
                settings + mapOf(
                    "high_mid_boost" to 0.56f, // Lebih banyak presence
                    "high_boost" to 0.55f // Lebih banyak air
                )
            }
            
            genre.contains("trap", ignoreCase = true) && role == MixingMasteringAI.TrackRole.BASS -> {
                // Pengaturan khusus untuk bass trap/808
                settings + mapOf(
                    "low_boost" to 0.58f, // Lebih banyak sub
                    "low_boost_freq" to 0.06f // ~60Hz
                )
            }
            
            else -> settings
        }
        
        return Effect(
            name = "${track.name} EQ",
            type = "eq",
            settings = finalSettings
        )
    }
    
    /**
     * Buat kompressor optimal berdasarkan jenis track dan genre
     */
    private fun createOptimalCompressor(
        track: Track, 
        role: MixingMasteringAI.TrackRole, 
        genre: String
    ): Effect {
        // Pengaturan kompressor default berdasarkan peran track
        val settings = when (role) {
            MixingMasteringAI.TrackRole.KICK -> mapOf(
                "threshold" to 0.7f,
                "ratio" to 0.5f, // 4:1
                "attack" to 0.15f, // Fast
                "release" to 0.3f,
                "knee" to 0.4f,
                "gain" to 0.6f
            )
            
            MixingMasteringAI.TrackRole.BASS -> mapOf(
                "threshold" to 0.65f,
                "ratio" to 0.5f, // 4:1
                "attack" to 0.25f,
                "release" to 0.4f,
                "knee" to 0.5f,
                "gain" to 0.6f
            )
            
            MixingMasteringAI.TrackRole.DRUMS -> mapOf(
                "threshold" to 0.65f,
                "ratio" to 0.45f, // 3.5:1
                "attack" to 0.2f,
                "release" to 0.4f,
                "knee" to 0.5f,
                "gain" to 0.6f,
                "mix" to 0.8f // Parallel compression
            )
            
            MixingMasteringAI.TrackRole.VOCAL -> mapOf(
                "threshold" to 0.7f,
                "ratio" to 0.35f, // 2.5:1
                "attack" to 0.2f,
                "release" to 0.4f,
                "knee" to 0.6f,
                "gain" to 0.55f
            )
            
            else -> mapOf(
                "threshold" to 0.75f,
                "ratio" to 0.3f, // 2:1
                "attack" to 0.25f,
                "release" to 0.4f,
                "knee" to 0.5f,
                "gain" to 0.55f
            )
        }
        
        // Modifikasi pengaturan berdasarkan genre
        val finalSettings = when {
            genre.contains("nrotok", ignoreCase = true) -> {
                // Kompresi lebih agresif untuk DJ Nrotok
                settings + mapOf(
                    "threshold" to settings["threshold"]!!.minus(0.05f),
                    "ratio" to settings["ratio"]!!.plus(0.05f),
                    "attack" to settings["attack"]!!.minus(0.05f), // Lebih cepat
                    "release" to settings["release"]!!.minus(0.05f) // Lebih cepat
                )
            }
            
            genre.contains("trap", ignoreCase = true) && role == MixingMasteringAI.TrackRole.BASS -> {
                // Kompresi khusus untuk 808 trap
                settings + mapOf(
                    "threshold" to settings["threshold"]!!.minus(0.1f),
                    "attack" to settings["attack"]!!.plus(0.05f), // Lebih lambat untuk preservasi transient
                    "release" to settings["release"]!!.minus(0.1f) // Lebih cepat
                )
            }
            
            genre.contains("bantengan", ignoreCase = true) && 
            (role == MixingMasteringAI.TrackRole.ETHNIC || role == MixingMasteringAI.TrackRole.ETHNIC_PERCUSSION) -> {
                // Kompresi lebih lembut untuk instrumen tradisional
                settings + mapOf(
                    "threshold" to settings["threshold"]!!.plus(0.05f),
                    "ratio" to settings["ratio"]!!.minus(0.1f),
                    "knee" to settings["knee"]!!.plus(0.1f) // Lebih soft knee
                )
            }
            
            else -> settings
        }
        
        return Effect(
            name = "${track.name} Compressor",
            type = "compressor",
            settings = finalSettings
        )
    }
    
    /**
     * Buat efek tambahan optimal berdasarkan jenis track dan genre
     */
    private fun createOptimalAdditionalEffects(
        track: Track, 
        role: MixingMasteringAI.TrackRole, 
        genre: String
    ): List<Effect> {
        val effects = mutableListOf<Effect>()
        
        // Efek berdasarkan peran
        when (role) {
            MixingMasteringAI.TrackRole.KICK -> {
                // Transient designer untuk kick
                effects.add(
                    Effect(
                        name = "Kick Transient",
                        type = "transient",
                        settings = mapOf(
                            "attack" to 0.6f, // Enhance attack
                            "sustain" to 0.45f, // Reduce sustain slightly
                            "mix" to 0.8f
                        )
                    )
                )
            }
            
            MixingMasteringAI.TrackRole.BASS -> {
                // Saturasi untuk bass
                effects.add(
                    Effect(
                        name = "Bass Saturation",
                        type = "saturation",
                        settings = mapOf(
                            "drive" to 0.4f,
                            "type" to 0.3f, // Warm harmonics
                            "mix" to 0.7f
                        )
                    )
                )
            }
            
            MixingMasteringAI.TrackRole.VOCAL -> {
                // De-esser untuk vokal
                effects.add(
                    Effect(
                        name = "De-esser",
                        type = "de-esser",
                        settings = mapOf(
                            "threshold" to 0.7f,
                            "frequency" to 0.7f, // ~7kHz
                            "range" to 0.5f,
                            "knee" to 0.6f
                        )
                    )
                )
                
                // Reverb untuk vokal
                effects.add(
                    Effect(
                        name = "Vocal Reverb",
                        type = "reverb",
                        settings = mapOf(
                            "decay" to 0.5f,
                            "size" to 0.5f,
                            "damping" to 0.5f,
                            "mix" to 0.3f,
                            "predelay" to 0.1f
                        )
                    )
                )
            }
            
            MixingMasteringAI.TrackRole.ETHNIC, MixingMasteringAI.TrackRole.ETHNIC_PERCUSSION -> {
                // Reverb untuk instrumen tradisional
                effects.add(
                    Effect(
                        name = "Ethnic Reverb",
                        type = "reverb",
                        settings = mapOf(
                            "decay" to 0.6f,
                            "size" to 0.7f,
                            "damping" to 0.4f,
                            "mix" to 0.35f,
                            "predelay" to 0.1f
                        )
                    )
                )
            }
            
            MixingMasteringAI.TrackRole.LEAD, MixingMasteringAI.TrackRole.MELODY -> {
                // Delay untuk lead/melody
                effects.add(
                    Effect(
                        name = "Melodic Delay",
                        type = "delay",
                        settings = mapOf(
                            "time" to 0.375f, // Dotted 1/8
                            "feedback" to 0.4f,
                            "mix" to 0.3f,
                            "high_cut" to 0.7f,
                            "low_cut" to 0.2f,
                            "ping_pong" to 0.7f
                        )
                    )
                )
                
                // Reverb untuk lead/melody
                effects.add(
                    Effect(
                        name = "Melodic Reverb",
                        type = "reverb",
                        settings = mapOf(
                            "decay" to 0.6f,
                            "size" to 0.6f,
                            "damping" to 0.5f,
                            "mix" to 0.3f,
                            "predelay" to 0.1f
                        )
                    )
                )
            }
            
            else -> { }
        }
        
        // Tambahan efek berdasarkan genre
        when {
            genre.contains("bantengan", ignoreCase = true) && 
            (role == MixingMasteringAI.TrackRole.ETHNIC || role == MixingMasteringAI.TrackRole.ETHNIC_PERCUSSION) -> {
                // Reverb khusus untuk instrumen gamelan di DJ Bantengan
                effects.add(
                    Effect(
                        name = "Mystical Reverb",
                        type = "reverb",
                        settings = mapOf(
                            "decay" to 0.8f, // Long decay
                            "size" to 0.8f, // Large space
                            "damping" to 0.3f, // Less damping
                            "mix" to 0.4f,
                            "predelay" to 0.15f
                        )
                    )
                )
            }
            
            genre.contains("nrotok", ignoreCase = true) && role == MixingMasteringAI.TrackRole.DRUMS -> {
                // Distortion untuk drum di DJ Nrotok
                effects.add(
                    Effect(
                        name = "Drum Drive",
                        type = "distortion",
                        settings = mapOf(
                            "drive" to 0.3f,
                            "tone" to 0.6f,
                            "mix" to 0.3f
                        )
                    )
                )
            }
            
            genre.contains("trap", ignoreCase = true) && role == MixingMasteringAI.TrackRole.HIHAT -> {
                // Stereo width untuk hi-hat di trap
                effects.add(
                    Effect(
                        name = "Hat Widener",
                        type = "stereo",
                        settings = mapOf(
                            "width" to 0.7f,
                            "low_cut" to 0.2f
                        )
                    )
                )
            }
        }
        
        return effects
    }
    
    /**
     * Deteksi genre dari file audio referensi
     */
    private fun detectGenreFromReference(referenceAudioPath: String): String {
        // Dalam implementasi nyata, ini akan menggunakan model AI untuk deteksi
        
        // Untuk simulasi, deteksi dari nama file
        return when {
            referenceAudioPath.contains("bantengan", ignoreCase = true) -> "DJ Bantengan"
            referenceAudioPath.contains("nrotok", ignoreCase = true) -> "DJ Nrotok"
            referenceAudioPath.contains("koplo", ignoreCase = true) -> "Koplo"
            referenceAudioPath.contains("dangdut", ignoreCase = true) -> "Dangdut"
            referenceAudioPath.contains("trap", ignoreCase = true) -> "Trap"
            referenceAudioPath.contains("edm", ignoreCase = true) -> "EDM"
            else -> "Unknown"
        }
    }
    
    /**
     * Dapatkan karakter mastering yang sesuai untuk genre
     */
    private fun getPreferredMasteringCharacter(
        genre: String,
        preferredStyle: String? = null
    ): MasteringCharacter {
        // Jika ada preferensi yang ditentukan, prioritaskan itu
        if (preferredStyle != null) {
            when (preferredStyle.toLowerCase()) {
                "warm", "analog", "warm_analog" -> return MasteringCharacter.WARM_ANALOG
                "clean", "digital", "clean_digital" -> return MasteringCharacter.CLEAN_DIGITAL
                "punchy", "dynamic", "punchy_dynamic" -> return MasteringCharacter.PUNCHY_DYNAMIC
                "loud", "commercial", "loud_commercial" -> return MasteringCharacter.LOUD_COMMERCIAL
                "transparent" -> return MasteringCharacter.TRANSPARENT
            }
        }
        
        // Tentukan berdasarkan genre
        return when {
            genre.contains("bantengan", ignoreCase = true) -> MasteringCharacter.PUNCHY_DYNAMIC
            genre.contains("nrotok", ignoreCase = true) -> MasteringCharacter.LOUD_COMMERCIAL
            genre.contains("koplo", ignoreCase = true) -> MasteringCharacter.WARM_ANALOG
            genre.contains("dangdut", ignoreCase = true) -> MasteringCharacter.WARM_ANALOG
            genre.contains("trap", ignoreCase = true) -> MasteringCharacter.LOUD_COMMERCIAL
            genre.contains("edm", ignoreCase = true) -> MasteringCharacter.LOUD_COMMERCIAL
            genre.contains("rock", ignoreCase = true) -> MasteringCharacter.PUNCHY_DYNAMIC
            genre.contains("pop", ignoreCase = true) -> MasteringCharacter.CLEAN_DIGITAL
            genre.contains("jazz", ignoreCase = true) -> MasteringCharacter.TRANSPARENT
            genre.contains("classical", ignoreCase = true) -> MasteringCharacter.TRANSPARENT
            else -> MasteringCharacter.SPECIAL_GENRE
        }
    }
    
    /**
     * Opsi untuk proses produksi musik
     */
    data class ProductionOptions(
        val maintainOriginalStructure: Boolean = true,
        val masteringStyle: String? = null,
        val targetLoudness: Float? = null,
        val preserveTransients: Boolean = true,
        val enhanceStereWidth: Boolean = true
    )
    
    /**
     * Opsi untuk proses mastering
     */
    data class MasteringOptions(
        val applyMastering: Boolean = true,
        val masteringCharacter: MasteringCharacter = MasteringCharacter.SPECIAL_GENRE,
        val targetLUFS: Float? = null,
        val maximizeLoudness: Boolean = false,
        val enhanceStereoImage: Boolean = true
    )
}