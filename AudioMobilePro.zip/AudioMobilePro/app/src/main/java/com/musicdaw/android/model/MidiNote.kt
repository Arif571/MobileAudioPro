package com.musicdaw.android.model

import java.util.*
import kotlin.math.roundToInt

/**
 * Represents a MIDI note in a MIDI track or pattern
 */
data class MidiNote(
    val id: String = UUID.randomUUID().toString(),
    val note: Int, // MIDI note number (0-127, where 60 is middle C)
    val startTime: Float, // Start time in seconds
    val duration: Float, // Duration in seconds
    val velocity: Int = 100, // MIDI velocity (1-127)
    val channel: Int = 0, // MIDI channel (0-15)
    val isSelected: Boolean = false,
    val pitchBend: Int = 0, // MIDI pitch bend value (-8192 to 8191)
    val modulation: Int = 0, // MIDI modulation value (0-127)
    val expression: Int = 127, // MIDI expression value (0-127)
    val pan: Int = 64 // MIDI pan value (0-127, where 64 is center)
) {

    /**
     * Calculates the end time of this note
     */
    fun endTime(): Float {
        return startTime + duration
    }

    /**
     * Returns a copy of this note with the selection state toggled
     */
    fun toggleSelected(): MidiNote {
        return this.copy(isSelected = !isSelected)
    }

    /**
     * Returns a copy of this note with a new start time
     */
    fun withStartTime(newStartTime: Float): MidiNote {
        return this.copy(startTime = newStartTime)
    }

    /**
     * Returns a copy of this note with a new duration
     */
    fun withDuration(newDuration: Float): MidiNote {
        if (newDuration <= 0) {
            return this
        }
        return this.copy(duration = newDuration)
    }

    /**
     * Returns a copy of this note with a new velocity
     */
    fun withVelocity(newVelocity: Int): MidiNote {
        val clampedVelocity = newVelocity.coerceIn(1, 127)
        return this.copy(velocity = clampedVelocity)
    }

    /**
     * Returns a copy of this note transposed by the specified number of semitones
     */
    fun transpose(semitones: Int): MidiNote {
        val newNote = (note + semitones).coerceIn(0, 127)
        return this.copy(note = newNote)
    }

    /**
     * Returns a copy of this note quantized to the nearest grid division
     */
    fun quantize(gridDivision: Float): MidiNote {
        // Round start time to nearest grid division
        val quantizedStart = (startTime / gridDivision).roundToInt() * gridDivision
        
        // Round duration to nearest grid division, ensuring at least one grid division
        val quantizedDuration = maxOf(
            gridDivision,
            (duration / gridDivision).roundToInt() * gridDivision
        )
        
        return this.copy(
            startTime = quantizedStart,
            duration = quantizedDuration
        )
    }

    /**
     * Returns true if this note overlaps with the specified time range
     */
    fun overlapsTimeRange(rangeStartTime: Float, rangeEndTime: Float): Boolean {
        return !(this.endTime() <= rangeStartTime || this.startTime >= rangeEndTime)
    }

    /**
     * Returns a copy of this note with a new pitch bend value
     */
    fun withPitchBend(newPitchBend: Int): MidiNote {
        val clampedPitchBend = newPitchBend.coerceIn(-8192, 8191)
        return this.copy(pitchBend = clampedPitchBend)
    }

    /**
     * Returns a copy of this note with a new modulation value
     */
    fun withModulation(newModulation: Int): MidiNote {
        val clampedModulation = newModulation.coerceIn(0, 127)
        return this.copy(modulation = clampedModulation)
    }
    
    companion object {
        /**
         * Returns the note name (like C4, F#3) for a MIDI note number
         */
        fun getNoteName(noteNumber: Int): String {
            val octave = (noteNumber / 12) - 1
            val noteName = when (noteNumber % 12) {
                0 -> "C"
                1 -> "C#"
                2 -> "D"
                3 -> "D#"
                4 -> "E"
                5 -> "F"
                6 -> "F#"
                7 -> "G"
                8 -> "G#"
                9 -> "A"
                10 -> "A#"
                11 -> "B"
                else -> "?"
            }
            return "$noteName$octave"
        }
        
        /**
         * Converts a MIDI note number to a frequency in Hz
         */
        fun noteToFrequency(noteNumber: Int): Float {
            // A4 (MIDI note 69) is 440 Hz
            return 440f * Math.pow(2.0, (noteNumber - 69) / 12.0).toFloat()
        }
    }
}