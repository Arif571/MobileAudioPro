package com.musicdaw.android.model

import java.util.*

/**
 * Represents an audio sample that can be used in the DAW
 */
data class Sample(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val filePath: String,
    val category: SampleCategory,
    val tags: List<String> = emptyList(),
    val durationMs: Int,
    val sampleRate: Int = 44100,
    val bitDepth: Int = 16,
    val channels: Int = 2,
    val waveformData: List<Float> = emptyList(),
    val dateAdded: Date = Date(),
    val dateModified: Date = Date(),
    val isFavorite: Boolean = false,
    val isEdited: Boolean = false,
    val originalFilePath: String? = null,
    val notes: String = "",
    val bpm: Float? = null,
    val rootNote: Int? = null, // MIDI note number (e.g., 60 for C4)
    val key: String? = null, // e.g., "C Major"
    val author: String? = null,
    val source: String? = null,
    val size: Long = 0 // File size in bytes
)

/**
 * Categories for organizing samples
 */
enum class SampleCategory(val displayName: String) {
    DRUM("Drum"),
    PERCUSSION("Percussion"),
    LOOP("Loop"),
    FX("Effect"),
    VOCAL("Vocal"),
    INSTRUMENT("Instrument"),
    AMBIENT("Ambient"),
    FOLEY("Foley"),
    SYNTH("Synth"),
    OTHER("Other")
}

/**
 * Represents a collection or pack of related samples
 */
data class SamplePack(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String = "",
    val samples: List<Sample> = emptyList(),
    val coverImagePath: String? = null,
    val author: String? = null,
    val dateAdded: Date = Date(),
    val tags: List<String> = emptyList(),
    val website: String? = null
)

/**
 * Utility functions for working with samples
 */
object SampleUtils {
    /**
     * Calculate the size of a sample in megabytes (approximate based on typical audio parameters)
     */
    fun calculateSizeInMb(durationMs: Int, sampleRate: Int = 44100, bitDepth: Int = 16, channels: Int = 2): Float {
        val bytesPerSample = bitDepth / 8
        val durationSec = durationMs / 1000f
        val bytesPerSecond = sampleRate * bytesPerSample * channels
        val totalBytes = bytesPerSecond * durationSec
        return totalBytes / (1024f * 1024f) // Convert to MB
    }
    
    /**
     * Generate a simple waveform representation from audio data
     * In a real implementation, this would analyze the actual audio
     */
    fun generateWaveform(audioData: ByteArray, numPoints: Int = 100): List<Float> {
        // This is a placeholder implementation that generates random waveform data
        // In a real app, you would analyze the actual audio data to create a waveform
        return List(numPoints) { (Math.random() * 0.8 + 0.2).toFloat() }
    }
    
    /**
     * Format the duration of a sample in mm:ss format
     */
    fun formatDuration(durationMs: Int): String {
        val totalSeconds = durationMs / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%d:%02d", minutes, seconds)
    }
    
    /**
     * Gets a color for a sample category
     */
    fun getCategoryColor(category: SampleCategory): Int {
        return when(category) {
            SampleCategory.DRUM -> 0xFFE91E63.toInt() // Pink
            SampleCategory.PERCUSSION -> 0xFFFF5722.toInt() // Deep Orange
            SampleCategory.LOOP -> 0xFF9C27B0.toInt() // Purple
            SampleCategory.FX -> 0xFF673AB7.toInt() // Deep Purple
            SampleCategory.VOCAL -> 0xFF3F51B5.toInt() // Indigo
            SampleCategory.INSTRUMENT -> 0xFF2196F3.toInt() // Blue
            SampleCategory.AMBIENT -> 0xFF00BCD4.toInt() // Cyan
            SampleCategory.FOLEY -> 0xFF009688.toInt() // Teal
            SampleCategory.SYNTH -> 0xFF4CAF50.toInt() // Green
            SampleCategory.OTHER -> 0xFF9E9E9E.toInt() // Grey
        }
    }
}