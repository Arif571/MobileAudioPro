package com.musicdaw.android.ui.theme

import androidx.compose.ui.graphics.Color

// Dark theme colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

// Light theme colors
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Additional application colors
val TrackColor1 = Color(0xFF9C27B0) // Purple
val TrackColor2 = Color(0xFF2196F3) // Blue
val TrackColor3 = Color(0xFFFF5722) // Orange
val TrackColor4 = Color(0xFF4CAF50) // Green
val TrackColor5 = Color(0xFFE91E63) // Pink
val TrackColor6 = Color(0xFF009688) // Teal
val TrackColor7 = Color(0xFFFF9800) // Amber
val TrackColor8 = Color(0xFF795548) // Brown

// Waveform colors
val WaveformBackground = Color(0xFF121212)
val WaveformForeground = Color(0xFF64B5F6)
val WaveformPlayhead = Color(0xFFFFFFFF)

// Mixer colors
val FaderBackground = Color(0xFF303030)
val FaderHandle = Color(0xFFEEEEEE)
val MeterGreen = Color(0xFF4CAF50)
val MeterYellow = Color(0xFFFFEB3B)
val MeterRed = Color(0xFFF44336)

// Piano roll colors
val PianoRollBackground = Color(0xFF121212)
val PianoRollGrid = Color(0xFF2A2A2A)
val PianoRollGridAccent = Color(0xFF3A3A3A)
val PianoRollWhiteKey = Color(0xFFEEEEEE)
val PianoRollBlackKey = Color(0xFF222222)