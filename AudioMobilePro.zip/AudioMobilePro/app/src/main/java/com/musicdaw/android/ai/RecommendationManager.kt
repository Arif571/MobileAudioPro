package com.musicdaw.android.ai

import com.musicdaw.android.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.*

/**
 * Manajer untuk menghasilkan rekomendasi musik berdasarkan profil musik pengguna
 */
class RecommendationManager(
    private val styleAnalyzer: MusicStyleAnalyzer = MusicStyleAnalyzer(),
    private val repository: MusicRecommendationRepository = MusicRecommendationRepository()
) {
    // Caching profile dan rekomendasi untuk efisiensi
    private var cachedUserProfile: UserMusicProfile? = null
    private var cachedRecommendations: List<MusicRecommendation> = emptyList()
    private var lastRefreshTime: Date? = null
    
    /**
     * Menganalisis proyek pengguna dan memperbarui profil musik
     */
    suspend fun analyzeUserProject(
        project: Project,
        userId: String
    ): UserMusicProfile = withContext(Dispatchers.Default) {
        val updatedProfile = styleAnalyzer.analyzeProject(
            project = project,
            currentProfile = cachedUserProfile,
            userId = userId
        )
        
        // Update cache
        cachedUserProfile = updatedProfile
        
        return@withContext updatedProfile
    }
    
    /**
     * Mendapatkan rekomendasi musik berdasarkan profil pengguna
     */
    suspend fun getRecommendations(
        count: Int = 10,
        types: List<RecommendationType>? = null,
        forceRefresh: Boolean = false
    ): List<MusicRecommendation> = withContext(Dispatchers.Default) {
        // Cek apakah perlu refresh
        val needsRefresh = forceRefresh || 
                           lastRefreshTime == null || 
                           cachedRecommendations.isEmpty() ||
                           Date().time - (lastRefreshTime?.time ?: 0) > REFRESH_INTERVAL_MS
        
        if (needsRefresh) {
            val userProfile = cachedUserProfile ?: return@withContext emptyList()
            
            // Dapatkan rekomendasi dari repository
            cachedRecommendations = repository.getRecommendations(
                userProfile = userProfile,
                count = count,
                types = types
            )
            
            lastRefreshTime = Date()
        }
        
        // Jika types diberikan, filter rekomendasi yang sudah ada
        val filteredRecommendations = if (types != null) {
            cachedRecommendations.filter { it.recommendation in types }
        } else {
            cachedRecommendations
        }
        
        return@withContext filteredRecommendations.take(count)
    }
    
    /**
     * Menyimpan rating/feedback pengguna untuk rekomendasi
     */
    suspend fun submitFeedback(
        recommendationId: String,
        rating: Int,
        listenedDuration: Int? = null
    ) = withContext(Dispatchers.IO) {
        repository.trackInteraction(
            recommendationId = recommendationId,
            interactionType = "rating",
            rating = rating
        )
    }
    
    /**
     * Mendapatkan profil musik pengguna saat ini
     */
    fun getCurrentUserProfile(): UserMusicProfile? {
        return cachedUserProfile
    }
    
    /**
     * Mencoba meningkatkan rekomendasi berdasarkan feedback pengguna
     */
    suspend fun improveRecommendations(
        likedGenres: List<String>? = null,
        dislikedGenres: List<String>? = null,
        favoriteTempo: Float? = null,
        preferredInfluences: List<String>? = null
    ): Boolean = withContext(Dispatchers.Default) {
        val profile = cachedUserProfile ?: return@withContext false
        
        var updatedProfile = profile
        
        // Update genre preferences berdasarkan feedback
        if (likedGenres != null && likedGenres.isNotEmpty()) {
            val genreWeights = likedGenres.associateWith { 0.9f }
            updatedProfile = updatedProfile.copy(
                favoriteGenres = updatedProfile.favoriteGenres.toMutableMap().apply {
                    genreWeights.forEach { (genre, weight) ->
                        this[genre] = weight
                    }
                }
            )
        }
        
        // Kurangi bobot genre yang tidak disukai
        if (dislikedGenres != null && dislikedGenres.isNotEmpty()) {
            updatedProfile = updatedProfile.copy(
                favoriteGenres = updatedProfile.favoriteGenres.toMutableMap().apply {
                    dislikedGenres.forEach { genre ->
                        this.remove(genre)
                    }
                }
            )
        }
        
        // Update preferensi tempo
        if (favoriteTempo != null) {
            updatedProfile = updatedProfile.copy(
                tempoPreference = updatedProfile.tempoPreference.copy(
                    meanTempo = favoriteTempo
                )
            )
        }
        
        // Update pengaruh musik
        if (preferredInfluences != null && preferredInfluences.isNotEmpty()) {
            updatedProfile = updatedProfile.copy(
                musicalInfluences = preferredInfluences
            )
        }
        
        // Cache profil yang diperbarui
        cachedUserProfile = updatedProfile
        
        // Reset rekomendasi untuk memaksa refresh
        cachedRecommendations = emptyList()
        lastRefreshTime = null
        
        return@withContext true
    }
    
    /**
     * Menyimpan profil pengguna dan riwayat rekomendasi (untuk implementasi lengkap)
     */
    suspend fun saveUserData() = withContext(Dispatchers.IO) {
        // Simpan ke penyimpanan lokal atau cloud
        // Tidak diimplementasikan untuk prototype
    }
    
    /**
     * Memuat profil pengguna yang disimpan (untuk implementasi lengkap)
     */
    suspend fun loadUserData(userId: String) = withContext(Dispatchers.IO) {
        // Muat dari penyimpanan lokal atau cloud
        // Tidak diimplementasikan untuk prototype
    }
    
    companion object {
        private const val REFRESH_INTERVAL_MS = 24 * 60 * 60 * 1000L // 24 jam
    }
}