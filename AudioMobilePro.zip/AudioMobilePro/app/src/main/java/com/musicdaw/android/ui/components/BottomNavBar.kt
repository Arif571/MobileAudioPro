package com.musicdaw.android.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.navigation.NavController
import com.musicdaw.android.R

@Composable
fun BottomNavBar(
    navController: NavController,
    currentRoute: String?
) {
    val navItems = listOf(
        NavItem("home", "Home", R.drawable.ic_home),
        NavItem("editor", "Editor", R.drawable.ic_editor),
        NavItem("mixer", "Mixer", R.drawable.ic_mixer),
        NavItem("samples", "Samples", R.drawable.ic_samples),
        NavItem("ai", "AI", R.drawable.ic_ai_processing)
    )
    
    var isVisible by remember { mutableStateOf(true) }
    
    // Hide bottom bar in certain screens if needed
    isVisible = currentRoute?.let { route ->
        // Add conditions here if you need to hide the bar on specific screens
        true
    } ?: true
    
    AnimatedVisibility(
        visible = isVisible,
        enter = slideInVertically(initialOffsetY = { it }),
        exit = slideOutVertically(targetOffsetY = { it })
    ) {
        NavigationBar(
            modifier = Modifier.navigationBarsPadding(),
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ) {
            navItems.forEach { item ->
                NavigationBarItem(
                    icon = {
                        Icon(
                            imageVector = ImageVector.vectorResource(id = item.iconResId),
                            contentDescription = item.label
                        )
                    },
                    label = { Text(item.label) },
                    selected = currentRoute == item.route,
                    onClick = {
                        if (currentRoute != item.route) {
                            navController.navigate(item.route) {
                                // Pop up to the start destination of the graph to
                                // avoid building up a large stack of destinations
                                popUpTo(navController.graph.startDestinationId) {
                                    saveState = true
                                }
                                // Avoid multiple copies of the same destination
                                launchSingleTop = true
                                // Restore state when reselecting a previously selected item
                                restoreState = true
                            }
                        }
                    }
                )
            }
        }
    }
}

data class NavItem(
    val route: String,
    val label: String,
    val iconResId: Int
)
